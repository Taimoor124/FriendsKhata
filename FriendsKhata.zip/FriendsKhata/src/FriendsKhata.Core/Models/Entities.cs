using FriendsKhata.Core.Common;

namespace FriendsKhata.Core.Models;

// Entity classes map 1:1 to SQLite rows. Storage-friendly primitives are used on purpose:
//   * Ids are GUID strings (TEXT primary keys)
//   * Money is long paisa (INTEGER)          -> exact arithmetic, no floating point
//   * Dates are "yyyy-MM-dd" strings (TEXT)  -> correct ordering and range queries
// Read-only helper properties expose friendly types (decimal, DateTime, enums) to the rest of the app.

public sealed class FriendGroup
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public string CreatedAt { get; set; } = "";
    public long IsArchived { get; set; }
}

public sealed class Friend
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Phone { get; set; }
    public string? Notes { get; set; }
    public string CreatedAt { get; set; } = "";
}

/// <summary>A friend's membership in one group. Joining date and status are per group.</summary>
public sealed class GroupMember
{
    public string Id { get; set; } = "";
    public string GroupId { get; set; } = "";
    public string FriendId { get; set; } = "";
    public string JoiningDate { get; set; } = "";
    public long Status { get; set; } = (long)MemberStatus.Active;
    public string CreatedAt { get; set; } = "";
}

/// <summary>Joined row: GroupMembers + Friends.</summary>
public sealed class Member
{
    public string MemberId { get; set; } = "";
    public string GroupId { get; set; } = "";
    public string FriendId { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Phone { get; set; }
    public string JoiningDate { get; set; } = "";
    public long Status { get; set; }

    public bool IsActive => Status == (long)MemberStatus.Active;
    public string FriendCode => Ids.Short(FriendId);
    public DateTime Joined => DbDate.FromDb(JoiningDate);
}

public sealed class Category
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Icon { get; set; } = "";
    public long IsSystem { get; set; }
    public long SortOrder { get; set; }
    public string CreatedAt { get; set; } = "";
}

public sealed class Expense
{
    public string Id { get; set; } = "";
    public string GroupId { get; set; } = "";
    public string Title { get; set; } = "";
    public long AmountPaisa { get; set; }
    public string CategoryId { get; set; } = "";
    public string ExpenseDate { get; set; } = "";
    /// <summary>Required for personal payments. Optional (who handled the cash) for fund payments.</summary>
    public string? PaidByFriendId { get; set; }
    public long PaymentSource { get; set; }
    public long SplitMethod { get; set; }
    public string? Notes { get; set; }
    public string CreatedAt { get; set; } = "";
    public string UpdatedAt { get; set; } = "";

    public PaymentSource Source => (PaymentSource)PaymentSource;
    public SplitMethod Split => (SplitMethod)SplitMethod;
    public DateTime Date => DbDate.FromDb(ExpenseDate);
    public bool IsFundExpense => Source == Models.PaymentSource.GroupFund;
}

public sealed class ExpenseParticipant
{
    public string Id { get; set; } = "";
    public string ExpenseId { get; set; } = "";
    public string FriendId { get; set; } = "";
    public long ShareAmountPaisa { get; set; }
    /// <summary>Percentage in basis points (33.33% = 3333). Only set for percentage splits.</summary>
    public long? SharePercentBp { get; set; }
}

public sealed class FundContribution
{
    public string Id { get; set; } = "";
    public string GroupId { get; set; } = "";
    public string FriendId { get; set; } = "";
    public long AmountPaisa { get; set; }
    public string ContributionDate { get; set; } = "";
    public string? Notes { get; set; }
    public string CreatedAt { get; set; } = "";
    public string UpdatedAt { get; set; } = "";

    public DateTime Date => DbDate.FromDb(ContributionDate);
}

/// <summary>
/// The fund ledger. Every movement of fund money is exactly one row here:
/// the fund balance is always SUM(AmountPaisa). Positive = money into the fund.
/// Contribution and Expense rows are linked 1:1 (UNIQUE) to their source record,
/// which makes a duplicate deduction impossible at database level.
/// </summary>
public sealed class FundTransaction
{
    public string Id { get; set; } = "";
    public string GroupId { get; set; } = "";
    public long Type { get; set; }
    public long AmountPaisa { get; set; }
    public string TransactionDate { get; set; } = "";
    public string? FriendId { get; set; }
    public string? ContributionId { get; set; }
    public string? ExpenseId { get; set; }
    public string? Notes { get; set; }
    public string CreatedAt { get; set; } = "";
    public string UpdatedAt { get; set; } = "";

    public FundTransactionType Kind => (FundTransactionType)Type;
    public DateTime Date => DbDate.FromDb(TransactionDate);
}

public sealed class Settlement
{
    public string Id { get; set; } = "";
    public string GroupId { get; set; } = "";
    public string FromFriendId { get; set; } = "";
    public string ToFriendId { get; set; } = "";
    public long AmountPaisa { get; set; }
    public string SettlementDate { get; set; } = "";
    public string? Notes { get; set; }
    public string CreatedAt { get; set; } = "";
    public string UpdatedAt { get; set; } = "";

    public DateTime Date => DbDate.FromDb(SettlementDate);
}
