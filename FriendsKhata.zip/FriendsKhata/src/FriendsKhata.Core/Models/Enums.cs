namespace FriendsKhata.Core.Models;

public enum PaymentSource
{
    /// <summary>A friend paid from their own pocket. Creates recoverable amounts between friends.</summary>
    Personal = 1,
    /// <summary>Paid from the common group fund. Reduces the fund balance, not personal balances.</summary>
    GroupFund = 2
}

public enum SplitMethod
{
    /// <summary>Equal split among the selected participants (all members or specific friends).</summary>
    Equal = 1,
    /// <summary>Custom rupee amount per friend. Must add up to the expense amount.</summary>
    CustomAmount = 2,
    /// <summary>Custom percentage per friend. Must add up to exactly 100%.</summary>
    Percentage = 3
}

public enum FundTransactionType
{
    Contribution = 1,
    Expense = 2,
    /// <summary>Money returned from the fund to a friend (e.g. leftover fund paid back).</summary>
    Refund = 3,
    /// <summary>Manual correction of the fund balance (e.g. cash count difference, bank charges).</summary>
    Adjustment = 4
}

public enum MemberStatus
{
    Inactive = 0,
    Active = 1
}

public enum TransactionKind
{
    PersonalExpense,
    FundExpense,
    Contribution,
    Settlement,
    FundRefund,
    FundAdjustment
}
