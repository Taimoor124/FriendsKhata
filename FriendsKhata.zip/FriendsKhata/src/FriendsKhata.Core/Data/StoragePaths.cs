namespace FriendsKhata.Core.Data;

/// <summary>File locations, supplied by the app at startup (MAUI: FileSystem.AppDataDirectory / CacheDirectory).</summary>
public sealed class StoragePaths
{
    public required string DatabasePath { get; init; }
    /// <summary>Temporary files (backup exports, CSV) before the user saves them somewhere.</summary>
    public required string TempDirectory { get; init; }
    /// <summary>Automatic safety copies made before every restore.</summary>
    public required string SafetyBackupDirectory { get; init; }

    public static StoragePaths ForAppData(string appDataDirectory, string cacheDirectory) => new()
    {
        DatabasePath = Path.Combine(appDataDirectory, "friendskhata.db3"),
        TempDirectory = cacheDirectory,
        SafetyBackupDirectory = Path.Combine(appDataDirectory, "SafetyBackups")
    };
}
