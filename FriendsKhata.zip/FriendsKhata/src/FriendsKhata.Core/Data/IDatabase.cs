namespace FriendsKhata.Core.Data;

/// <summary>
/// Thin abstraction over SQLite. SQL uses positional '?' parameters.
/// Only string, long, int and null are passed as parameters, so every SQLite
/// driver binds them identically.
/// </summary>
public interface IDatabase
{
    string DatabasePath { get; }

    Task<List<T>> QueryAsync<T>(string sql, params object?[] args) where T : new();

    Task<int> ExecuteAsync(string sql, params object?[] args);

    Task<T> ScalarAsync<T>(string sql, params object?[] args);

    /// <summary>
    /// Runs <paramref name="work"/> inside a single SQLite transaction.
    /// If the delegate throws, every change is rolled back.
    /// All financial writes go through this method.
    /// </summary>
    Task RunInTransactionAsync(Action<IDbSession> work);

    /// <summary>Copies the live database into a new file using SQLite's "VACUUM INTO".</summary>
    Task BackupToAsync(string destinationPath);

    /// <summary>Closes the connection (needed before the database file is replaced during restore).</summary>
    Task CloseAsync();
}

/// <summary>Synchronous view of the database used inside a transaction.</summary>
public interface IDbSession
{
    List<T> Query<T>(string sql, params object?[] args) where T : new();

    int Execute(string sql, params object?[] args);

    T Scalar<T>(string sql, params object?[] args);
}
