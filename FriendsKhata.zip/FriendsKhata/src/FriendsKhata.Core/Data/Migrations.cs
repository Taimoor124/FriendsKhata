namespace FriendsKhata.Core.Data;

/// <summary>
/// Versioned schema migrations.
///
/// Strategy:
///   * The table SchemaVersion records every applied migration.
///   * On every app start the runner applies, in order, each migration whose version is higher
///     than the current one, all inside one transaction (all-or-nothing).
///   * To change the schema in a future release, ADD a new Migration with the next version number.
///     Never edit a migration that has already shipped.
/// </summary>
public static class Migrations
{
    public const string AppMarkerKey = "app";
    public const string AppMarkerValue = "FriendsKhata";

    public sealed record Migration(int Version, string Description, string[] Statements);

    public static readonly IReadOnlyList<Migration> All = new[]
    {
        new Migration(1, "Initial schema", new[]
        {
            """
            CREATE TABLE IF NOT EXISTS AppMeta (
                Key   TEXT NOT NULL PRIMARY KEY,
                Value TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE Groups (
                Id          TEXT NOT NULL PRIMARY KEY,
                Name        TEXT NOT NULL COLLATE NOCASE UNIQUE CHECK (length(trim(Name)) > 0),
                Description TEXT NULL,
                CreatedAt   TEXT NOT NULL,
                IsArchived  INTEGER NOT NULL DEFAULT 0 CHECK (IsArchived IN (0, 1))
            )
            """,
            """
            CREATE TABLE Friends (
                Id        TEXT NOT NULL PRIMARY KEY,
                Name      TEXT NOT NULL CHECK (length(trim(Name)) > 0),
                Phone     TEXT NULL,
                Notes     TEXT NULL,
                CreatedAt TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE GroupMembers (
                Id          TEXT NOT NULL PRIMARY KEY,
                GroupId     TEXT NOT NULL REFERENCES Groups(Id) ON DELETE CASCADE,
                FriendId    TEXT NOT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                JoiningDate TEXT NOT NULL,
                Status      INTEGER NOT NULL DEFAULT 1 CHECK (Status IN (0, 1)),
                CreatedAt   TEXT NOT NULL,
                UNIQUE (GroupId, FriendId)
            )
            """,
            """
            CREATE TABLE Categories (
                Id        TEXT NOT NULL PRIMARY KEY,
                Name      TEXT NOT NULL COLLATE NOCASE UNIQUE CHECK (length(trim(Name)) > 0),
                Icon      TEXT NOT NULL DEFAULT '',
                IsSystem  INTEGER NOT NULL DEFAULT 0 CHECK (IsSystem IN (0, 1)),
                SortOrder INTEGER NOT NULL DEFAULT 100,
                CreatedAt TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE Expenses (
                Id             TEXT NOT NULL PRIMARY KEY,
                GroupId        TEXT NOT NULL REFERENCES Groups(Id) ON DELETE CASCADE,
                Title          TEXT NOT NULL CHECK (length(trim(Title)) > 0),
                AmountPaisa    INTEGER NOT NULL CHECK (AmountPaisa > 0),
                CategoryId     TEXT NOT NULL REFERENCES Categories(Id) ON DELETE RESTRICT,
                ExpenseDate    TEXT NOT NULL,
                PaidByFriendId TEXT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                PaymentSource  INTEGER NOT NULL CHECK (PaymentSource IN (1, 2)),
                SplitMethod    INTEGER NOT NULL CHECK (SplitMethod IN (1, 2, 3)),
                Notes          TEXT NULL,
                CreatedAt      TEXT NOT NULL,
                UpdatedAt      TEXT NOT NULL,
                CHECK (PaymentSource = 2 OR PaidByFriendId IS NOT NULL)
            )
            """,
            """
            CREATE TABLE ExpenseParticipants (
                Id               TEXT NOT NULL PRIMARY KEY,
                ExpenseId        TEXT NOT NULL REFERENCES Expenses(Id) ON DELETE CASCADE,
                FriendId         TEXT NOT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                ShareAmountPaisa INTEGER NOT NULL CHECK (ShareAmountPaisa >= 0),
                SharePercentBp   INTEGER NULL CHECK (SharePercentBp IS NULL OR (SharePercentBp >= 0 AND SharePercentBp <= 10000)),
                UNIQUE (ExpenseId, FriendId)
            )
            """,
            """
            CREATE TABLE FundContributions (
                Id               TEXT NOT NULL PRIMARY KEY,
                GroupId          TEXT NOT NULL REFERENCES Groups(Id) ON DELETE CASCADE,
                FriendId         TEXT NOT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                AmountPaisa      INTEGER NOT NULL CHECK (AmountPaisa > 0),
                ContributionDate TEXT NOT NULL,
                Notes            TEXT NULL,
                CreatedAt        TEXT NOT NULL,
                UpdatedAt        TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE FundTransactions (
                Id              TEXT NOT NULL PRIMARY KEY,
                GroupId         TEXT NOT NULL REFERENCES Groups(Id) ON DELETE CASCADE,
                Type            INTEGER NOT NULL CHECK (Type IN (1, 2, 3, 4)),
                AmountPaisa     INTEGER NOT NULL CHECK (AmountPaisa <> 0),
                TransactionDate TEXT NOT NULL,
                FriendId        TEXT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                ContributionId  TEXT NULL UNIQUE REFERENCES FundContributions(Id) ON DELETE CASCADE,
                ExpenseId       TEXT NULL UNIQUE REFERENCES Expenses(Id) ON DELETE CASCADE,
                Notes           TEXT NULL,
                CreatedAt       TEXT NOT NULL,
                UpdatedAt       TEXT NOT NULL,
                CHECK (
                    (Type = 1 AND ContributionId IS NOT NULL AND ExpenseId IS NULL AND AmountPaisa > 0 AND FriendId IS NOT NULL) OR
                    (Type = 2 AND ExpenseId IS NOT NULL AND ContributionId IS NULL AND AmountPaisa < 0) OR
                    (Type = 3 AND ExpenseId IS NULL AND ContributionId IS NULL AND AmountPaisa < 0 AND FriendId IS NOT NULL) OR
                    (Type = 4 AND ExpenseId IS NULL AND ContributionId IS NULL)
                )
            )
            """,
            """
            CREATE TABLE Settlements (
                Id             TEXT NOT NULL PRIMARY KEY,
                GroupId        TEXT NOT NULL REFERENCES Groups(Id) ON DELETE CASCADE,
                FromFriendId   TEXT NOT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                ToFriendId     TEXT NOT NULL REFERENCES Friends(Id) ON DELETE RESTRICT,
                AmountPaisa    INTEGER NOT NULL CHECK (AmountPaisa > 0),
                SettlementDate TEXT NOT NULL,
                Notes          TEXT NULL,
                CreatedAt      TEXT NOT NULL,
                UpdatedAt      TEXT NOT NULL,
                CHECK (FromFriendId <> ToFriendId)
            )
            """,
            "CREATE INDEX IX_GroupMembers_Friend ON GroupMembers(FriendId)",
            "CREATE INDEX IX_Expenses_Group_Date ON Expenses(GroupId, ExpenseDate)",
            "CREATE INDEX IX_Expenses_Category ON Expenses(CategoryId)",
            "CREATE INDEX IX_Expenses_PaidBy ON Expenses(PaidByFriendId)",
            "CREATE INDEX IX_ExpenseParticipants_Friend ON ExpenseParticipants(FriendId)",
            "CREATE INDEX IX_FundContributions_Group_Date ON FundContributions(GroupId, ContributionDate)",
            "CREATE INDEX IX_FundContributions_Friend ON FundContributions(FriendId)",
            "CREATE INDEX IX_FundTransactions_Group_Date ON FundTransactions(GroupId, TransactionDate)",
            "CREATE INDEX IX_FundTransactions_Friend ON FundTransactions(FriendId)",
            "CREATE INDEX IX_Settlements_Group_Date ON Settlements(GroupId, SettlementDate)",
            "CREATE INDEX IX_Settlements_From ON Settlements(FromFriendId)",
            "CREATE INDEX IX_Settlements_To ON Settlements(ToFriendId)",
            // Default expense categories (reference data, not sample data). Users can add their own.
            """
            INSERT INTO Categories (Id, Name, Icon, IsSystem, SortOrder, CreatedAt) VALUES
              ('6f1d2c10-0001-4a5e-9a01-000000000001', 'Food & Dining', '🍽️', 1, 1, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000002', 'Groceries',     '🛒', 1, 2, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000003', 'Petrol',        '⛽', 1, 3, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000004', 'Tea & Snacks',  '☕', 1, 4, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000005', 'Transport',     '🚗', 1, 5, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000006', 'Bills & Rent',  '🧾', 1, 6, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000007', 'Shopping',      '🛍️', 1, 7, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000008', 'Entertainment', '🎬', 1, 8, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000009', 'Travel',        '🧳', 1, 9, datetime('now','localtime')),
              ('6f1d2c10-0001-4a5e-9a01-000000000010', 'Other',         '📦', 1, 99, datetime('now','localtime'))
            """
        }),
    };

    public static int LatestVersion => All.Max(m => m.Version);
}

public sealed class SchemaVersionRow
{
    public long Version { get; set; }
}

public static class MigrationRunner
{
    /// <summary>
    /// Applies pending migrations. Must be called inside a transaction
    /// (see <see cref="IDatabase.RunInTransactionAsync"/>) so a failure leaves the database untouched.
    /// Returns the schema version after migration.
    /// </summary>
    public static int Migrate(IDbSession session)
    {
        session.Execute("""
            CREATE TABLE IF NOT EXISTS SchemaVersion (
                Version     INTEGER NOT NULL PRIMARY KEY,
                Description TEXT NOT NULL,
                AppliedAt   TEXT NOT NULL
            )
            """);

        var current = session.Scalar<long>("SELECT COALESCE(MAX(Version), 0) FROM SchemaVersion");

        if (current > Migrations.LatestVersion)
            throw new InvalidOperationException(
                $"This database was created by a newer version of Friends Khata (schema {current}). Please update the app.");

        foreach (var migration in Migrations.All.Where(m => m.Version > current).OrderBy(m => m.Version))
        {
            foreach (var statement in migration.Statements)
                session.Execute(statement);

            session.Execute(
                "INSERT INTO SchemaVersion (Version, Description, AppliedAt) VALUES (?, ?, datetime('now','localtime'))",
                (long)migration.Version, migration.Description);
        }

        session.Execute("INSERT OR REPLACE INTO AppMeta (Key, Value) VALUES (?, ?)",
            Migrations.AppMarkerKey, Migrations.AppMarkerValue);

        return Migrations.LatestVersion;
    }
}
