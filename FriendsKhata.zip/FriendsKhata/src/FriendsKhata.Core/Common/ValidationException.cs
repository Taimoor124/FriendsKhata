namespace FriendsKhata.Core.Common;

/// <summary>
/// Thrown by services when user input breaks a business rule.
/// The message is always written for the end user and can be shown directly in the UI.
/// </summary>
public sealed class ValidationException : Exception
{
    public ValidationException(string message) : base(message) { }
}

public static class Guard
{
    public static void Require(bool condition, string message)
    {
        if (!condition) throw new ValidationException(message);
    }
}
