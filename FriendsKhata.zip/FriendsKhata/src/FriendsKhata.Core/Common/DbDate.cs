using System.Globalization;

namespace FriendsKhata.Core.Common;

/// <summary>
/// Dates are stored as ISO text ("yyyy-MM-dd") so that they sort and compare correctly in SQL
/// and are readable in any SQLite browser. Timestamps use "yyyy-MM-ddTHH:mm:ss".
/// </summary>
public static class DbDate
{
    public const string DateFormat = "yyyy-MM-dd";
    public const string TimestampFormat = "yyyy-MM-ddTHH:mm:ss";

    public static string ToDb(DateTime date) => date.Date.ToString(DateFormat, CultureInfo.InvariantCulture);

    public static DateTime FromDb(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return DateTime.MinValue;
        if (DateTime.TryParseExact(value, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
            return d;
        if (DateTime.TryParseExact(value, TimestampFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out d))
            return d;
        return DateTime.Parse(value, CultureInfo.InvariantCulture);
    }

    public static string Now() => DateTime.Now.ToString(TimestampFormat, CultureInfo.InvariantCulture);

    public static string Display(DateTime date) => date.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);

    public static string Display(string? dbDate) => Display(FromDb(dbDate));
}

public static class Ids
{
    public static string New() => Guid.NewGuid().ToString("D");

    /// <summary>Short human friendly code shown as "Friend ID" in the UI (first 8 chars of the GUID).</summary>
    public static string Short(string id) => string.IsNullOrEmpty(id) ? "" : id[..Math.Min(8, id.Length)].ToUpperInvariant();
}
