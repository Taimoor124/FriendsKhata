using System.Globalization;

namespace FriendsKhata.Core.Common;

/// <summary>
/// All money is stored and calculated as whole paisa (long, 1 Rs = 100 paisa).
/// This avoids floating point errors completely and keeps SQL SUM() exact.
/// </summary>
public static class Money
{
    private static readonly CultureInfo Culture = CultureInfo.InvariantCulture;

    public static long ToPaisa(decimal rupees)
        => (long)decimal.Round(rupees * 100m, 0, MidpointRounding.AwayFromZero);

    public static decimal ToRupees(long paisa) => paisa / 100m;

    /// <summary>Formats as "Rs. 5,000" or "Rs. 5,000.50". Negative values become "-Rs. 500".</summary>
    public static string Format(long paisa)
    {
        var abs = Math.Abs(paisa);
        var rupees = abs / 100m;
        var text = abs % 100 == 0
            ? rupees.ToString("#,##0", Culture)
            : rupees.ToString("#,##0.00", Culture);
        return (paisa < 0 ? "-Rs. " : "Rs. ") + text;
    }

    /// <summary>Plain number used to pre-fill edit boxes, e.g. "5000" or "5000.5".</summary>
    public static string ToInput(long paisa)
        => ToRupees(paisa).ToString("0.##", Culture);

    /// <summary>
    /// Parses user input like "5000", "5,000", "1250.75" or "Rs. 300".
    /// Rejects negative numbers and more than 2 decimal places.
    /// </summary>
    public static bool TryParse(string? text, out long paisa, out string? error)
    {
        paisa = 0;
        error = null;
        if (string.IsNullOrWhiteSpace(text))
        {
            error = "Please enter an amount.";
            return false;
        }

        var cleaned = text.Trim()
            .Replace("Rs.", "", StringComparison.OrdinalIgnoreCase)
            .Replace("Rs", "", StringComparison.OrdinalIgnoreCase)
            .Replace(",", "")
            .Trim();

        if (!decimal.TryParse(cleaned, NumberStyles.AllowDecimalPoint, Culture, out var value))
        {
            error = "Please enter a valid amount, for example 1500 or 1250.50.";
            return false;
        }

        if (decimal.Round(value, 2) != value)
        {
            error = "Amount can have at most 2 decimal places.";
            return false;
        }

        if (value > 1_000_000_000m)
        {
            error = "Amount is too large.";
            return false;
        }

        paisa = ToPaisa(value);
        return true;
    }
}
