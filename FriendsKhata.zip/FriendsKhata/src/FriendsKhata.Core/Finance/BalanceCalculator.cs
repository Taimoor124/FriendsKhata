using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Finance;

/// <summary>
/// Personal (pocket-money) position of one friend.
/// Net &gt; 0 : the group owes this friend (recoverable).
/// Net &lt; 0 : this friend owes the group (outstanding).
/// </summary>
public sealed class FriendBalance
{
    public required string FriendId { get; init; }
    public required string Name { get; init; }
    public bool IsActive { get; init; } = true;

    /// <summary>Total this friend paid personally for shared expenses.</summary>
    public long PaidPersonalPaisa { get; set; }
    /// <summary>This friend's own share of personally-paid expenses.</summary>
    public long SharePersonalPaisa { get; set; }
    /// <summary>Settlement money this friend paid to others.</summary>
    public long SettlementsPaidPaisa { get; set; }
    /// <summary>Settlement money this friend received from others.</summary>
    public long SettlementsReceivedPaisa { get; set; }

    public long NetPaisa => PaidPersonalPaisa - SharePersonalPaisa + SettlementsPaidPaisa - SettlementsReceivedPaisa;
}

/// <summary>
/// Calculates who owes whom from personal expenses and settlements.
/// Fund expenses and contributions are deliberately ignored here: they belong to the fund ledger
/// (rule: personal payments and group fund payments are treated separately).
/// </summary>
public static class BalanceCalculator
{
    public static IReadOnlyList<FriendBalance> Calculate(GroupLedger ledger)
    {
        var map = new Dictionary<string, FriendBalance>();

        FriendBalance Get(string friendId)
        {
            if (!map.TryGetValue(friendId, out var b))
            {
                var member = ledger.Members.FirstOrDefault(m => m.FriendId == friendId);
                b = new FriendBalance
                {
                    FriendId = friendId,
                    Name = member?.Name ?? ledger.FriendName(friendId),
                    IsActive = member?.IsActive ?? false
                };
                map[friendId] = b;
            }
            return b;
        }

        foreach (var m in ledger.Members) Get(m.FriendId);

        foreach (var expense in ledger.Expenses.Where(e => e.Source == PaymentSource.Personal))
        {
            Get(expense.PaidByFriendId!).PaidPersonalPaisa += expense.AmountPaisa;
            foreach (var p in ledger.ParticipantsByExpense[expense.Id])
                Get(p.FriendId).SharePersonalPaisa += p.ShareAmountPaisa;
        }

        foreach (var s in ledger.Settlements)
        {
            Get(s.FromFriendId).SettlementsPaidPaisa += s.AmountPaisa;
            Get(s.ToFriendId).SettlementsReceivedPaisa += s.AmountPaisa;
        }

        return map.Values.OrderBy(b => b.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }
}
