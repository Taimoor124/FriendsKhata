namespace FriendsKhata.Core.Finance;

public sealed record SettlementSuggestion(string FromFriendId, string FromName, string ToFriendId, string ToName, long AmountPaisa);

/// <summary>
/// Suggests who should pay whom so that all personal balances become zero
/// with the minimum number of payments.
///
/// Algorithm: the minimum number of payments equals (number of people with a non-zero balance)
/// minus (the maximum number of groups they can be split into where each group sums to zero).
/// For up to 16 people this is solved exactly with a bitmask dynamic programme;
/// each zero-sum group is then settled greedily (largest debtor pays largest creditor),
/// which needs exactly (group size - 1) payments. Above 16 people a greedy method is used.
/// </summary>
public static class SettlementOptimizer
{
    private const int ExactLimit = 16;

    public static IReadOnlyList<SettlementSuggestion> Suggest(IEnumerable<FriendBalance> balances)
    {
        var people = balances
            .Where(b => b.NetPaisa != 0)
            .OrderBy(b => b.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(b => b.FriendId, StringComparer.Ordinal)
            .Select(b => new Person(b.FriendId, b.Name, b.NetPaisa))
            .ToList();

        if (people.Count == 0) return Array.Empty<SettlementSuggestion>();
        if (people.Sum(p => p.Net) != 0)
            throw new InvalidOperationException("Balances do not add up to zero; ledger is inconsistent.");

        var groups = people.Count <= ExactLimit ? SplitIntoZeroSumGroups(people) : new List<List<Person>> { people };

        var result = new List<SettlementSuggestion>();
        foreach (var g in groups) result.AddRange(Greedy(g));
        return result
            .OrderByDescending(s => s.AmountPaisa)
            .ThenBy(s => s.FromName, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private sealed record Person(string Id, string Name, long Net);

    private static List<List<Person>> SplitIntoZeroSumGroups(List<Person> people)
    {
        var n = people.Count;
        var full = (1 << n) - 1;
        var sum = new long[1 << n];
        var dp = new int[1 << n];

        for (var mask = 1; mask <= full; mask++)
        {
            var low = System.Numerics.BitOperations.TrailingZeroCount(mask);
            sum[mask] = sum[mask & (mask - 1)] + people[low].Net;

            var best = 0;
            for (var i = 0; i < n; i++)
                if ((mask & (1 << i)) != 0 && dp[mask ^ (1 << i)] > best)
                    best = dp[mask ^ (1 << i)];
            dp[mask] = best + (sum[mask] == 0 ? 1 : 0);
        }

        // Reconstruct an ordering of people whose prefix sums hit zero dp[full] times.
        var order = new List<int>(n);
        var m = full;
        while (m != 0)
        {
            var target = dp[m] - (sum[m] == 0 ? 1 : 0);
            for (var i = 0; i < n; i++)
            {
                if ((m & (1 << i)) != 0 && dp[m ^ (1 << i)] == target)
                {
                    order.Add(i);
                    m ^= 1 << i;
                    break;
                }
            }
        }
        order.Reverse();

        var groups = new List<List<Person>>();
        var current = new List<Person>();
        long running = 0;
        foreach (var i in order)
        {
            current.Add(people[i]);
            running += people[i].Net;
            if (running == 0)
            {
                groups.Add(current);
                current = new List<Person>();
            }
        }
        if (current.Count > 0) groups.Add(current); // cannot happen when total is zero, kept for safety
        return groups;
    }

    private static IEnumerable<SettlementSuggestion> Greedy(List<Person> group)
    {
        var creditors = group.Where(p => p.Net > 0).Select(p => (p, amt: p.Net)).ToList();
        var debtors = group.Where(p => p.Net < 0).Select(p => (p, amt: -p.Net)).ToList();

        while (creditors.Count > 0 && debtors.Count > 0)
        {
            creditors.Sort((a, b) => b.amt.CompareTo(a.amt) != 0 ? b.amt.CompareTo(a.amt) : string.Compare(a.p.Name, b.p.Name, StringComparison.OrdinalIgnoreCase));
            debtors.Sort((a, b) => b.amt.CompareTo(a.amt) != 0 ? b.amt.CompareTo(a.amt) : string.Compare(a.p.Name, b.p.Name, StringComparison.OrdinalIgnoreCase));

            var c = creditors[0];
            var d = debtors[0];
            var pay = Math.Min(c.amt, d.amt);
            yield return new SettlementSuggestion(d.p.Id, d.p.Name, c.p.Id, c.p.Name, pay);

            if (c.amt == pay) creditors.RemoveAt(0); else creditors[0] = (c.p, c.amt - pay);
            if (d.amt == pay) debtors.RemoveAt(0); else debtors[0] = (d.p, d.amt - pay);
        }
    }
}
