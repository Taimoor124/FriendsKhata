using FriendsKhata.Core.Common;
using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Finance;

public sealed class FriendPeriodRow
{
    public required string FriendId { get; init; }
    public required string Name { get; init; }
    /// <summary>Paid personally for group expenses within the period.</summary>
    public long PaidPersonalPaisa { get; set; }
    /// <summary>Own share of personal expenses within the period.</summary>
    public long PersonalSharePaisa { get; set; }
    /// <summary>Own share of fund expenses within the period.</summary>
    public long FundSharePaisa { get; set; }
    public long TotalSharePaisa => PersonalSharePaisa + FundSharePaisa;
    public long ContributedPaisa { get; set; }
    public long SettlementsPaidPaisa { get; set; }
    public long SettlementsReceivedPaisa { get; set; }
    /// <summary>Personal net balance at the end of the period (all history up to End).</summary>
    public long OutstandingAtEndPaisa { get; set; }
}

public sealed class CategoryRow
{
    public required string CategoryId { get; init; }
    public required string Name { get; init; }
    public required string Icon { get; init; }
    public long AmountPaisa { get; set; }
    public int Count { get; set; }
    public double Fraction { get; set; }
}

public sealed class FinancialReport
{
    public required ReportPeriod Period { get; init; }
    public long TotalExpensesPaisa { get; init; }
    public long PersonalPaymentsPaisa { get; init; }
    public long FundSpendingPaisa { get; init; }
    public long ContributionsPaisa { get; init; }
    public long FundRefundsPaisa { get; init; }
    public long FundAdjustmentsPaisa { get; init; }
    public int ExpenseCount { get; init; }
    public long OpeningFundBalancePaisa { get; init; }
    public long ClosingFundBalancePaisa { get; init; }
    public long SettlementsTotalPaisa { get; init; }
    public int SettlementCount { get; init; }
    public required IReadOnlyList<FriendPeriodRow> Friends { get; init; }
    public required IReadOnlyList<CategoryRow> Categories { get; init; }
    public required IReadOnlyList<TransactionItem> Settlements { get; init; }
    public required IReadOnlyList<FriendBalance> OutstandingAtEnd { get; init; }
    public long TotalOutstandingAtEndPaisa => OutstandingAtEnd.Where(b => b.NetPaisa > 0).Sum(b => b.NetPaisa);
}

/// <summary>Builds weekly / monthly / custom reports purely from the ledger snapshot.</summary>
public static class ReportBuilder
{
    public static FinancialReport Build(GroupLedger ledger, ReportPeriod period)
    {
        var expenses = ledger.Expenses.Where(e => period.Contains(e.Date)).ToList();
        var fundTx = ledger.FundTransactions.Where(t => period.Contains(t.Date)).ToList();
        var settlements = ledger.Settlements.Where(s => period.Contains(s.Date)).ToList();

        var opening = ledger.FundTransactions.Where(t => t.Date < period.Start).Sum(t => t.AmountPaisa);
        var closing = ledger.FundTransactions.Where(t => t.Date <= period.End).Sum(t => t.AmountPaisa);

        // Friend-wise rows
        var rows = ledger.Members.ToDictionary(m => m.FriendId, m => new FriendPeriodRow { FriendId = m.FriendId, Name = m.Name });
        FriendPeriodRow Row(string id)
        {
            if (!rows.TryGetValue(id, out var r)) rows[id] = r = new FriendPeriodRow { FriendId = id, Name = ledger.FriendName(id) };
            return r;
        }

        foreach (var e in expenses)
        {
            if (e.Source == PaymentSource.Personal) Row(e.PaidByFriendId!).PaidPersonalPaisa += e.AmountPaisa;
            foreach (var p in ledger.ParticipantsByExpense[e.Id])
            {
                if (e.Source == PaymentSource.Personal) Row(p.FriendId).PersonalSharePaisa += p.ShareAmountPaisa;
                else Row(p.FriendId).FundSharePaisa += p.ShareAmountPaisa;
            }
        }
        foreach (var t in fundTx.Where(t => t.Kind == FundTransactionType.Contribution))
            Row(t.FriendId!).ContributedPaisa += t.AmountPaisa;
        foreach (var s in settlements)
        {
            Row(s.FromFriendId).SettlementsPaidPaisa += s.AmountPaisa;
            Row(s.ToFriendId).SettlementsReceivedPaisa += s.AmountPaisa;
        }

        var balancesAtEnd = BalanceCalculator.Calculate(ledger.AsOf(period.End));
        foreach (var b in balancesAtEnd) Row(b.FriendId).OutstandingAtEndPaisa = b.NetPaisa;

        var total = expenses.Sum(e => e.AmountPaisa);

        var categories = expenses
            .GroupBy(e => e.CategoryId)
            .Select(g =>
            {
                var c = ledger.Category(g.Key);
                var amount = g.Sum(e => e.AmountPaisa);
                return new CategoryRow
                {
                    CategoryId = g.Key,
                    Name = c?.Name ?? "Uncategorised",
                    Icon = c?.Icon ?? "📦",
                    AmountPaisa = amount,
                    Count = g.Count(),
                    Fraction = total == 0 ? 0 : (double)amount / total
                };
            })
            .OrderByDescending(c => c.AmountPaisa)
            .ToList();

        return new FinancialReport
        {
            Period = period,
            TotalExpensesPaisa = total,
            PersonalPaymentsPaisa = expenses.Where(e => e.Source == PaymentSource.Personal).Sum(e => e.AmountPaisa),
            FundSpendingPaisa = expenses.Where(e => e.Source == PaymentSource.GroupFund).Sum(e => e.AmountPaisa),
            ContributionsPaisa = fundTx.Where(t => t.Kind == FundTransactionType.Contribution).Sum(t => t.AmountPaisa),
            FundRefundsPaisa = -fundTx.Where(t => t.Kind == FundTransactionType.Refund).Sum(t => t.AmountPaisa),
            FundAdjustmentsPaisa = fundTx.Where(t => t.Kind == FundTransactionType.Adjustment).Sum(t => t.AmountPaisa),
            ExpenseCount = expenses.Count,
            OpeningFundBalancePaisa = opening,
            ClosingFundBalancePaisa = closing,
            SettlementsTotalPaisa = settlements.Sum(s => s.AmountPaisa),
            SettlementCount = settlements.Count,
            Friends = rows.Values.OrderBy(r => r.Name, StringComparer.OrdinalIgnoreCase).ToList(),
            Categories = categories,
            Settlements = TransactionHistoryBuilder.Build(ledger)
                .Where(t => t.Kind == TransactionKind.Settlement && period.Contains(t.Date)).ToList(),
            OutstandingAtEnd = balancesAtEnd
        };
    }
}

/// <summary>One line of the unified transaction history.</summary>
public sealed class TransactionItem
{
    public required string Id { get; init; }
    public required TransactionKind Kind { get; init; }
    public required string Title { get; init; }
    /// <summary>Always positive; the direction is given by <see cref="Kind"/>.</summary>
    public required long AmountPaisa { get; init; }
    public required DateTime Date { get; init; }
    public required string RelatedFriend { get; init; }
    public required string PaymentSource { get; init; }
    public string? Description { get; init; }
    public string Icon { get; init; } = "";
    public string CreatedAt { get; init; } = "";
    /// <summary>Id of the record to open for editing (expense, contribution, settlement or fund transaction).</summary>
    public required string SourceId { get; init; }

    public string KindText => Kind switch
    {
        TransactionKind.PersonalExpense => "Personal expense",
        TransactionKind.FundExpense => "Fund expense",
        TransactionKind.Contribution => "Fund contribution",
        TransactionKind.Settlement => "Settlement",
        TransactionKind.FundRefund => "Fund refund",
        TransactionKind.FundAdjustment => "Fund adjustment",
        _ => Kind.ToString()
    };
}

public static class TransactionHistoryBuilder
{
    public static IReadOnlyList<TransactionItem> Build(GroupLedger ledger)
    {
        var list = new List<TransactionItem>();

        foreach (var e in ledger.Expenses)
        {
            var cat = ledger.Category(e.CategoryId);
            var isFund = e.Source == Models.PaymentSource.GroupFund;
            list.Add(new TransactionItem
            {
                Id = "E:" + e.Id,
                SourceId = e.Id,
                Kind = isFund ? TransactionKind.FundExpense : TransactionKind.PersonalExpense,
                Title = e.Title,
                AmountPaisa = e.AmountPaisa,
                Date = e.Date,
                RelatedFriend = isFund
                    ? (e.PaidByFriendId is null ? "Group Fund" : $"Fund (handled by {ledger.FriendName(e.PaidByFriendId)})")
                    : $"Paid by {ledger.FriendName(e.PaidByFriendId)}",
                PaymentSource = isFund ? "Group Fund" : "Personal",
                Description = e.Notes,
                Icon = cat?.Icon ?? "📦",
                CreatedAt = e.CreatedAt
            });
        }

        foreach (var c in ledger.Contributions)
        {
            list.Add(new TransactionItem
            {
                Id = "C:" + c.Id,
                SourceId = c.Id,
                Kind = TransactionKind.Contribution,
                Title = "Fund contribution",
                AmountPaisa = c.AmountPaisa,
                Date = c.Date,
                RelatedFriend = ledger.FriendName(c.FriendId),
                PaymentSource = "Into Group Fund",
                Description = c.Notes,
                Icon = "💰",
                CreatedAt = c.CreatedAt
            });
        }

        foreach (var s in ledger.Settlements)
        {
            list.Add(new TransactionItem
            {
                Id = "S:" + s.Id,
                SourceId = s.Id,
                Kind = TransactionKind.Settlement,
                Title = $"{ledger.FriendName(s.FromFriendId)} paid {ledger.FriendName(s.ToFriendId)}",
                AmountPaisa = s.AmountPaisa,
                Date = s.Date,
                RelatedFriend = $"{ledger.FriendName(s.FromFriendId)} → {ledger.FriendName(s.ToFriendId)}",
                PaymentSource = "Personal",
                Description = s.Notes,
                Icon = "🤝",
                CreatedAt = s.CreatedAt
            });
        }

        foreach (var t in ledger.FundTransactions.Where(t => t.Kind is FundTransactionType.Refund or FundTransactionType.Adjustment))
        {
            var isRefund = t.Kind == FundTransactionType.Refund;
            list.Add(new TransactionItem
            {
                Id = "F:" + t.Id,
                SourceId = t.Id,
                Kind = isRefund ? TransactionKind.FundRefund : TransactionKind.FundAdjustment,
                Title = isRefund
                    ? $"Refund to {ledger.FriendName(t.FriendId)}"
                    : (t.AmountPaisa > 0 ? "Fund adjustment (+)" : "Fund adjustment (−)"),
                AmountPaisa = Math.Abs(t.AmountPaisa),
                Date = t.Date,
                RelatedFriend = t.FriendId is null ? "—" : ledger.FriendName(t.FriendId),
                PaymentSource = isRefund ? "From Group Fund" : (t.AmountPaisa > 0 ? "Into Group Fund" : "From Group Fund"),
                Description = t.Notes,
                Icon = isRefund ? "↩️" : "⚖️",
                CreatedAt = t.CreatedAt
            });
        }

        return list
            .OrderByDescending(t => t.Date)
            .ThenByDescending(t => t.CreatedAt, StringComparer.Ordinal)
            .ToList();
    }
}

public sealed class DashboardData
{
    public string GroupName { get; init; } = "";
    public int MemberCount { get; init; }
    public long TotalExpensesPaisa { get; init; }
    public long TotalPersonalPaymentsPaisa { get; init; }
    public long TotalFundExpensesPaisa { get; init; }
    public long TotalContributionsPaisa { get; init; }
    public long FundBalancePaisa { get; init; }
    /// <summary>Sum of all positive personal balances = total money waiting to be recovered.</summary>
    public long OutstandingPaisa { get; init; }
    public long CurrentMonthExpensesPaisa { get; init; }
    public long CurrentWeekExpensesPaisa { get; init; }
    public required IReadOnlyList<TransactionItem> RecentTransactions { get; init; }
    public required IReadOnlyList<TransactionItem> RecentExpenses { get; init; }
    public required IReadOnlyList<FriendBalance> Balances { get; init; }
    public required IReadOnlyList<CategoryRow> CategoryBreakdown { get; init; }
}

public static class DashboardBuilder
{
    public static DashboardData Build(GroupLedger ledger, string groupName, DateTime today)
    {
        var balances = BalanceCalculator.Calculate(ledger);
        var fund = FundCalculator.Calculate(ledger);
        var month = ReportPeriod.MonthOf(today);
        var week = ReportPeriod.WeekOf(today);
        var history = TransactionHistoryBuilder.Build(ledger);
        var monthReport = ReportBuilder.Build(ledger, month);

        return new DashboardData
        {
            GroupName = groupName,
            MemberCount = ledger.Members.Count(m => m.IsActive),
            TotalExpensesPaisa = ledger.Expenses.Sum(e => e.AmountPaisa),
            TotalPersonalPaymentsPaisa = ledger.Expenses.Where(e => e.Source == PaymentSource.Personal).Sum(e => e.AmountPaisa),
            TotalFundExpensesPaisa = ledger.Expenses.Where(e => e.Source == PaymentSource.GroupFund).Sum(e => e.AmountPaisa),
            TotalContributionsPaisa = fund.TotalCollectedPaisa,
            FundBalancePaisa = fund.BalancePaisa,
            OutstandingPaisa = balances.Where(b => b.NetPaisa > 0).Sum(b => b.NetPaisa),
            CurrentMonthExpensesPaisa = ledger.Expenses.Where(e => month.Contains(e.Date)).Sum(e => e.AmountPaisa),
            CurrentWeekExpensesPaisa = ledger.Expenses.Where(e => week.Contains(e.Date)).Sum(e => e.AmountPaisa),
            RecentTransactions = history.Take(8).ToList(),
            RecentExpenses = history.Where(h => h.Kind is TransactionKind.PersonalExpense or TransactionKind.FundExpense).Take(5).ToList(),
            Balances = balances.Where(b => b.IsActive || b.NetPaisa != 0).ToList(),
            CategoryBreakdown = monthReport.Categories
        };
    }
}
