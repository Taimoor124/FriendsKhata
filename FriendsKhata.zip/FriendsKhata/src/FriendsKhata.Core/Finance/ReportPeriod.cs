using System.Globalization;
using FriendsKhata.Core.Common;

namespace FriendsKhata.Core.Finance;

public enum PeriodKind { Week, Month, Custom }

/// <summary>
/// An inclusive date range [Start, End] at day precision.
/// Weeks run Monday to Sunday. Months run from the 1st to the last day of the month.
/// </summary>
public sealed record ReportPeriod(PeriodKind Kind, DateTime Start, DateTime End)
{
    public static ReportPeriod WeekOf(DateTime anyDay)
    {
        var day = anyDay.Date;
        var offset = ((int)day.DayOfWeek + 6) % 7; // Monday = 0 ... Sunday = 6
        var start = day.AddDays(-offset);
        return new ReportPeriod(PeriodKind.Week, start, start.AddDays(6));
    }

    public static ReportPeriod MonthOf(DateTime anyDay)
    {
        var start = new DateTime(anyDay.Year, anyDay.Month, 1);
        return new ReportPeriod(PeriodKind.Month, start, start.AddMonths(1).AddDays(-1));
    }

    public static ReportPeriod Custom(DateTime from, DateTime to)
    {
        Guard.Require(from.Date <= to.Date, "The start date must be on or before the end date.");
        return new ReportPeriod(PeriodKind.Custom, from.Date, to.Date);
    }

    public bool Contains(DateTime date) => date.Date >= Start && date.Date <= End;

    public ReportPeriod Previous() => Kind switch
    {
        PeriodKind.Week => WeekOf(Start.AddDays(-7)),
        PeriodKind.Month => MonthOf(Start.AddMonths(-1)),
        _ => new ReportPeriod(PeriodKind.Custom, Start.AddDays(-Days), Start.AddDays(-1))
    };

    public ReportPeriod Next() => Kind switch
    {
        PeriodKind.Week => WeekOf(Start.AddDays(7)),
        PeriodKind.Month => MonthOf(Start.AddMonths(1)),
        _ => new ReportPeriod(PeriodKind.Custom, End.AddDays(1), End.AddDays(Days))
    };

    public int Days => (End - Start).Days + 1;

    public string Title => Kind switch
    {
        PeriodKind.Week => $"Week: {Start.ToString("dd MMM", CultureInfo.InvariantCulture)} – {End.ToString("dd MMM yyyy", CultureInfo.InvariantCulture)}",
        PeriodKind.Month => Start.ToString("MMMM yyyy", CultureInfo.InvariantCulture),
        _ => $"{DbDate.Display(Start)} – {DbDate.Display(End)}"
    };
}
