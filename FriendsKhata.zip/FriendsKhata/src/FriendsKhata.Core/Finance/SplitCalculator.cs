using FriendsKhata.Core.Common;
using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Finance;

/// <summary>One participant as entered by the user.</summary>
/// <param name="FriendId">Participating friend.</param>
/// <param name="AmountPaisa">Custom amount (CustomAmount split only).</param>
/// <param name="Percent">Custom percentage, e.g. 33.33 (Percentage split only).</param>
public sealed record SplitInput(string FriendId, long? AmountPaisa = null, decimal? Percent = null);

public sealed record ShareResult(string FriendId, long SharePaisa, long? PercentBp);

/// <summary>
/// Calculates each participant's share of an expense, in whole paisa.
/// Guarantees: the shares always add up to EXACTLY the expense amount, and
/// no paisa is ever lost or invented by rounding.
/// </summary>
public static class SplitCalculator
{
    public static IReadOnlyList<ShareResult> Calculate(long totalPaisa, SplitMethod method, IReadOnlyList<SplitInput> participants)
    {
        Guard.Require(totalPaisa > 0, "Amount must be greater than zero.");
        Guard.Require(participants is { Count: > 0 }, "Select at least one friend who shared this expense.");

        var duplicate = participants.GroupBy(p => p.FriendId).FirstOrDefault(g => g.Count() > 1);
        Guard.Require(duplicate is null, "A friend was selected more than once.");

        return method switch
        {
            SplitMethod.Equal => Equal(totalPaisa, participants),
            SplitMethod.CustomAmount => CustomAmounts(totalPaisa, participants),
            SplitMethod.Percentage => Percentages(totalPaisa, participants),
            _ => throw new ValidationException("Please choose how the expense is shared.")
        };
    }

    /// <summary>
    /// Equal split. Remainder paisa (when the amount does not divide evenly) are given one each
    /// to the first participants in the list, so Rs. 100 among 3 = 33.34 + 33.33 + 33.33.
    /// </summary>
    private static IReadOnlyList<ShareResult> Equal(long total, IReadOnlyList<SplitInput> participants)
    {
        var n = participants.Count;
        var baseShare = total / n;
        var remainder = total % n;
        return participants
            .Select((p, i) => new ShareResult(p.FriendId, baseShare + (i < remainder ? 1 : 0), null))
            .ToList();
    }

    private static IReadOnlyList<ShareResult> CustomAmounts(long total, IReadOnlyList<SplitInput> participants)
    {
        foreach (var p in participants)
        {
            Guard.Require(p.AmountPaisa.HasValue, "Enter an amount for every selected friend.");
            Guard.Require(p.AmountPaisa!.Value >= 0, "Share amounts cannot be negative.");
        }

        var used = participants.Where(p => p.AmountPaisa!.Value > 0).ToList();
        Guard.Require(used.Count > 0, "At least one friend must have a share greater than zero.");

        var sum = used.Sum(p => p.AmountPaisa!.Value);
        Guard.Require(sum == total,
            $"Custom amounts add up to {Money.Format(sum)} but the expense is {Money.Format(total)}. " +
            $"Difference: {Money.Format(total - sum)}.");

        return used.Select(p => new ShareResult(p.FriendId, p.AmountPaisa!.Value, null)).ToList();
    }

    /// <summary>
    /// Percentage split using the largest-remainder method: everyone gets the rounded-down
    /// share, then leftover paisa go to the participants with the largest fractional parts.
    /// </summary>
    private static IReadOnlyList<ShareResult> Percentages(long total, IReadOnlyList<SplitInput> participants)
    {
        foreach (var p in participants)
        {
            Guard.Require(p.Percent.HasValue, "Enter a percentage for every selected friend.");
            var pct = p.Percent!.Value;
            Guard.Require(pct >= 0 && pct <= 100, "Each percentage must be between 0 and 100.");
            Guard.Require(decimal.Round(pct, 2) == pct, "Percentages can have at most 2 decimal places.");
        }

        var used = participants.Where(p => p.Percent!.Value > 0).ToList();
        Guard.Require(used.Count > 0, "At least one friend must have a percentage greater than zero.");

        var sumPct = used.Sum(p => p.Percent!.Value);
        Guard.Require(sumPct == 100m,
            $"Percentages add up to {sumPct:0.##}% but must total exactly 100%.");

        var rows = used.Select((p, index) =>
        {
            var bp = (long)(p.Percent!.Value * 100m);       // basis points, exact (2 decimals max)
            var numerator = total * bp;                     // share = total * bp / 10000
            return new { p.FriendId, Bp = bp, Floor = numerator / 10000, Fraction = numerator % 10000, Index = index };
        }).ToList();

        var leftover = total - rows.Sum(r => r.Floor);
        var bonus = rows
            .OrderByDescending(r => r.Fraction)
            .ThenBy(r => r.Index)
            .Take((int)leftover)
            .Select(r => r.Index)
            .ToHashSet();

        return rows
            .Select(r => new ShareResult(r.FriendId, r.Floor + (bonus.Contains(r.Index) ? 1 : 0), r.Bp))
            .ToList();
    }
}
