using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Finance;

/// <summary>
/// An in-memory snapshot of every financial record of one group.
/// All balances, reports and dashboards are recalculated from this snapshot,
/// so the stored transactions are always the single source of truth.
/// </summary>
public sealed class GroupLedger
{
    public required string GroupId { get; init; }
    public required IReadOnlyList<Member> Members { get; init; }
    public required IReadOnlyList<Expense> Expenses { get; init; }
    public required IReadOnlyList<ExpenseParticipant> Participants { get; init; }
    public required IReadOnlyList<FundContribution> Contributions { get; init; }
    public required IReadOnlyList<FundTransaction> FundTransactions { get; init; }
    public required IReadOnlyList<Settlement> Settlements { get; init; }
    public required IReadOnlyList<Category> Categories { get; init; }

    private ILookup<string, ExpenseParticipant>? _participantsByExpense;
    private Dictionary<string, Member>? _membersByFriend;

    public ILookup<string, ExpenseParticipant> ParticipantsByExpense
        => _participantsByExpense ??= Participants.ToLookup(p => p.ExpenseId);

    public string FriendName(string? friendId)
    {
        if (friendId is null) return "Group Fund";
        _membersByFriend ??= Members.ToDictionary(m => m.FriendId);
        return _membersByFriend.TryGetValue(friendId, out var m) ? m.Name : "(removed friend)";
    }

    public Category? Category(string id) => Categories.FirstOrDefault(c => c.Id == id);

    /// <summary>Returns a ledger containing only records dated on or before <paramref name="asOf"/>.</summary>
    public GroupLedger AsOf(DateTime asOf)
    {
        var expenses = Expenses.Where(e => e.Date <= asOf.Date).ToList();
        var ids = expenses.Select(e => e.Id).ToHashSet();
        return new GroupLedger
        {
            GroupId = GroupId,
            Members = Members,
            Categories = Categories,
            Expenses = expenses,
            Participants = Participants.Where(p => ids.Contains(p.ExpenseId)).ToList(),
            Contributions = Contributions.Where(c => c.Date <= asOf.Date).ToList(),
            FundTransactions = FundTransactions.Where(f => f.Date <= asOf.Date).ToList(),
            Settlements = Settlements.Where(s => s.Date <= asOf.Date).ToList(),
        };
    }
}
