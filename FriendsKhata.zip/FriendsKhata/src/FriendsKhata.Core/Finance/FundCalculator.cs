using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Finance;

/// <summary>One friend's position in the group fund.</summary>
public sealed class FriendFundPosition
{
    public required string FriendId { get; init; }
    public required string Name { get; init; }
    public long ContributedPaisa { get; set; }
    /// <summary>This friend's share of expenses that were paid from the fund.</summary>
    public long FundShareConsumedPaisa { get; set; }
    /// <summary>Money returned to this friend from the fund (stored as a positive number).</summary>
    public long RefundedPaisa { get; set; }
    public long AdjustmentsPaisa { get; set; }

    /// <summary>
    /// The part of the remaining fund that belongs to this friend.
    /// Negative means the friend has used more of the fund than they put in.
    /// </summary>
    public long EquityPaisa => ContributedPaisa - FundShareConsumedPaisa - RefundedPaisa + AdjustmentsPaisa;
}

public sealed class FundSummary
{
    public long TotalCollectedPaisa { get; init; }
    public long TotalSpentPaisa { get; init; }
    public long TotalRefundedPaisa { get; init; }
    public long TotalAdjustmentsPaisa { get; init; }
    /// <summary>Adjustments not linked to any friend.</summary>
    public long UnallocatedAdjustmentsPaisa { get; init; }
    public long BalancePaisa { get; init; }
    public int ContributionCount { get; init; }
    public int FundExpenseCount { get; init; }
    public required IReadOnlyList<FriendFundPosition> Friends { get; init; }
}

/// <summary>
/// Calculates the fund balance strictly from the FundTransactions ledger.
/// Invariant (checked in tests): sum of all friends' equity + unallocated adjustments == fund balance.
/// </summary>
public static class FundCalculator
{
    public static long Balance(IEnumerable<FundTransaction> transactions) => transactions.Sum(t => t.AmountPaisa);

    public static FundSummary Calculate(GroupLedger ledger)
    {
        var map = ledger.Members.ToDictionary(
            m => m.FriendId,
            m => new FriendFundPosition { FriendId = m.FriendId, Name = m.Name });

        FriendFundPosition Get(string friendId)
        {
            if (!map.TryGetValue(friendId, out var p))
                map[friendId] = p = new FriendFundPosition { FriendId = friendId, Name = ledger.FriendName(friendId) };
            return p;
        }

        long collected = 0, spent = 0, refunded = 0, adjustments = 0, unallocated = 0;
        int contributions = 0, fundExpenses = 0;

        foreach (var t in ledger.FundTransactions)
        {
            switch (t.Kind)
            {
                case FundTransactionType.Contribution:
                    collected += t.AmountPaisa;
                    contributions++;
                    Get(t.FriendId!).ContributedPaisa += t.AmountPaisa;
                    break;

                case FundTransactionType.Expense:
                    spent += -t.AmountPaisa;
                    fundExpenses++;
                    foreach (var p in ledger.ParticipantsByExpense[t.ExpenseId!])
                        Get(p.FriendId).FundShareConsumedPaisa += p.ShareAmountPaisa;
                    break;

                case FundTransactionType.Refund:
                    refunded += -t.AmountPaisa;
                    Get(t.FriendId!).RefundedPaisa += -t.AmountPaisa;
                    break;

                case FundTransactionType.Adjustment:
                    adjustments += t.AmountPaisa;
                    if (t.FriendId is null) unallocated += t.AmountPaisa;
                    else Get(t.FriendId).AdjustmentsPaisa += t.AmountPaisa;
                    break;
            }
        }

        return new FundSummary
        {
            TotalCollectedPaisa = collected,
            TotalSpentPaisa = spent,
            TotalRefundedPaisa = refunded,
            TotalAdjustmentsPaisa = adjustments,
            UnallocatedAdjustmentsPaisa = unallocated,
            BalancePaisa = Balance(ledger.FundTransactions),
            ContributionCount = contributions,
            FundExpenseCount = fundExpenses,
            Friends = map.Values.OrderBy(f => f.Name, StringComparer.OrdinalIgnoreCase).ToList()
        };
    }
}
