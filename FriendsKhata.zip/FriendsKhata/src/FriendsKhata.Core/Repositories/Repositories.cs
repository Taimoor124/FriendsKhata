using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Repositories;

// Repositories own all SQL. Read methods are async and use IDatabase.
// Write methods take an IDbSession so services can combine several writes in ONE transaction.

public sealed class GroupRepository
{
    private const string Cols = "Id, Name, Description, CreatedAt, IsArchived";
    private readonly IDatabase _db;
    public GroupRepository(IDatabase db) => _db = db;

    public Task<List<FriendGroup>> GetAllAsync()
        => _db.QueryAsync<FriendGroup>($"SELECT {Cols} FROM Groups ORDER BY Name COLLATE NOCASE");

    public async Task<FriendGroup?> GetAsync(string id)
        => (await _db.QueryAsync<FriendGroup>($"SELECT {Cols} FROM Groups WHERE Id = ?", id)).FirstOrDefault();

    public bool NameExists(IDbSession s, string name, string? exceptId)
        => s.Scalar<long>("SELECT COUNT(*) FROM Groups WHERE Name = ? COLLATE NOCASE AND Id <> ?", name, exceptId ?? "") > 0;

    public void Insert(IDbSession s, FriendGroup g)
        => s.Execute($"INSERT INTO Groups ({Cols}) VALUES (?, ?, ?, ?, ?)", g.Id, g.Name, g.Description, g.CreatedAt, g.IsArchived);

    public void Update(IDbSession s, FriendGroup g)
        => s.Execute("UPDATE Groups SET Name = ?, Description = ?, IsArchived = ? WHERE Id = ?", g.Name, g.Description, g.IsArchived, g.Id);

    public void Delete(IDbSession s, string id) => s.Execute("DELETE FROM Groups WHERE Id = ?", id);
}

public sealed class FriendRepository
{
    private const string MemberSelect = """
        SELECT gm.Id AS MemberId, gm.GroupId, gm.FriendId, f.Name, f.Phone, gm.JoiningDate, gm.Status
        FROM GroupMembers gm
        JOIN Friends f ON f.Id = gm.FriendId
        """;

    private readonly IDatabase _db;
    public FriendRepository(IDatabase db) => _db = db;

    public Task<List<Member>> GetMembersAsync(string groupId)
        => _db.QueryAsync<Member>($"{MemberSelect} WHERE gm.GroupId = ? ORDER BY f.Name COLLATE NOCASE", groupId);

    public List<Member> GetMembers(IDbSession s, string groupId)
        => s.Query<Member>($"{MemberSelect} WHERE gm.GroupId = ?", groupId);

    public async Task<Member?> GetMemberAsync(string groupId, string friendId)
        => (await _db.QueryAsync<Member>($"{MemberSelect} WHERE gm.GroupId = ? AND gm.FriendId = ?", groupId, friendId)).FirstOrDefault();

    public Member? GetMember(IDbSession s, string groupId, string friendId)
        => s.Query<Member>($"{MemberSelect} WHERE gm.GroupId = ? AND gm.FriendId = ?", groupId, friendId).FirstOrDefault();

    /// <summary>Friends that exist in other groups but are not members of this group.</summary>
    public Task<List<Friend>> GetFriendsNotInGroupAsync(string groupId)
        => _db.QueryAsync<Friend>("""
            SELECT Id, Name, Phone, Notes, CreatedAt FROM Friends
            WHERE Id NOT IN (SELECT FriendId FROM GroupMembers WHERE GroupId = ?)
            ORDER BY Name COLLATE NOCASE
            """, groupId);

    public Friend? GetFriend(IDbSession s, string friendId)
        => s.Query<Friend>("SELECT Id, Name, Phone, Notes, CreatedAt FROM Friends WHERE Id = ?", friendId).FirstOrDefault();

    public bool MemberNameExists(IDbSession s, string groupId, string name, string? exceptFriendId)
        => s.Scalar<long>("""
            SELECT COUNT(*) FROM GroupMembers gm JOIN Friends f ON f.Id = gm.FriendId
            WHERE gm.GroupId = ? AND f.Name = ? COLLATE NOCASE AND f.Id <> ?
            """, groupId, name, exceptFriendId ?? "") > 0;

    public void InsertFriend(IDbSession s, Friend f)
        => s.Execute("INSERT INTO Friends (Id, Name, Phone, Notes, CreatedAt) VALUES (?, ?, ?, ?, ?)",
            f.Id, f.Name, f.Phone, f.Notes, f.CreatedAt);

    public void UpdateFriend(IDbSession s, Friend f)
        => s.Execute("UPDATE Friends SET Name = ?, Phone = ?, Notes = ? WHERE Id = ?", f.Name, f.Phone, f.Notes, f.Id);

    public void InsertMember(IDbSession s, GroupMember m)
        => s.Execute("INSERT INTO GroupMembers (Id, GroupId, FriendId, JoiningDate, Status, CreatedAt) VALUES (?, ?, ?, ?, ?, ?)",
            m.Id, m.GroupId, m.FriendId, m.JoiningDate, m.Status, m.CreatedAt);

    public void UpdateMember(IDbSession s, string groupId, string friendId, string joiningDate, long status)
        => s.Execute("UPDATE GroupMembers SET JoiningDate = ?, Status = ? WHERE GroupId = ? AND FriendId = ?",
            joiningDate, status, groupId, friendId);

    public void DeleteMember(IDbSession s, string groupId, string friendId)
        => s.Execute("DELETE FROM GroupMembers WHERE GroupId = ? AND FriendId = ?", groupId, friendId);

    public void DeleteFriend(IDbSession s, string friendId) => s.Execute("DELETE FROM Friends WHERE Id = ?", friendId);

    public long CountMemberships(IDbSession s, string friendId)
        => s.Scalar<long>("SELECT COUNT(*) FROM GroupMembers WHERE FriendId = ?", friendId);

    /// <summary>Number of financial records in the group that mention this friend.</summary>
    public long CountFinancialRecords(IDbSession s, string groupId, string friendId)
        => s.Scalar<long>("""
            SELECT
              (SELECT COUNT(*) FROM Expenses WHERE GroupId = ?1 AND PaidByFriendId = ?2) +
              (SELECT COUNT(*) FROM ExpenseParticipants ep JOIN Expenses e ON e.Id = ep.ExpenseId WHERE e.GroupId = ?1 AND ep.FriendId = ?2) +
              (SELECT COUNT(*) FROM FundContributions WHERE GroupId = ?1 AND FriendId = ?2) +
              (SELECT COUNT(*) FROM FundTransactions WHERE GroupId = ?1 AND FriendId = ?2) +
              (SELECT COUNT(*) FROM Settlements WHERE GroupId = ?1 AND (FromFriendId = ?2 OR ToFriendId = ?2))
            """, groupId, friendId);
}

public sealed class CategoryRepository
{
    private const string Cols = "Id, Name, Icon, IsSystem, SortOrder, CreatedAt";
    private readonly IDatabase _db;
    public CategoryRepository(IDatabase db) => _db = db;

    public Task<List<Category>> GetAllAsync()
        => _db.QueryAsync<Category>($"SELECT {Cols} FROM Categories ORDER BY SortOrder, Name COLLATE NOCASE");

    public List<Category> GetAll(IDbSession s)
        => s.Query<Category>($"SELECT {Cols} FROM Categories ORDER BY SortOrder, Name COLLATE NOCASE");

    public bool Exists(IDbSession s, string id) => s.Scalar<long>("SELECT COUNT(*) FROM Categories WHERE Id = ?", id) > 0;

    public Category? Get(IDbSession s, string id)
        => s.Query<Category>($"SELECT {Cols} FROM Categories WHERE Id = ?", id).FirstOrDefault();

    public bool NameExists(IDbSession s, string name, string? exceptId)
        => s.Scalar<long>("SELECT COUNT(*) FROM Categories WHERE Name = ? COLLATE NOCASE AND Id <> ?", name, exceptId ?? "") > 0;

    public long UsageCount(IDbSession s, string id) => s.Scalar<long>("SELECT COUNT(*) FROM Expenses WHERE CategoryId = ?", id);

    public void Insert(IDbSession s, Category c)
        => s.Execute($"INSERT INTO Categories ({Cols}) VALUES (?, ?, ?, ?, ?, ?)", c.Id, c.Name, c.Icon, c.IsSystem, c.SortOrder, c.CreatedAt);

    public void Update(IDbSession s, Category c)
        => s.Execute("UPDATE Categories SET Name = ?, Icon = ? WHERE Id = ?", c.Name, c.Icon, c.Id);

    public void Delete(IDbSession s, string id) => s.Execute("DELETE FROM Categories WHERE Id = ?", id);
}

public sealed class ExpenseRepository
{
    private const string Cols = "Id, GroupId, Title, AmountPaisa, CategoryId, ExpenseDate, PaidByFriendId, PaymentSource, SplitMethod, Notes, CreatedAt, UpdatedAt";
    private const string PCols = "Id, ExpenseId, FriendId, ShareAmountPaisa, SharePercentBp";
    private readonly IDatabase _db;
    public ExpenseRepository(IDatabase db) => _db = db;

    public Task<List<Expense>> GetByGroupAsync(string groupId)
        => _db.QueryAsync<Expense>($"SELECT {Cols} FROM Expenses WHERE GroupId = ? ORDER BY ExpenseDate DESC, CreatedAt DESC", groupId);

    public async Task<Expense?> GetAsync(string id)
        => (await _db.QueryAsync<Expense>($"SELECT {Cols} FROM Expenses WHERE Id = ?", id)).FirstOrDefault();

    public Expense? Get(IDbSession s, string id)
        => s.Query<Expense>($"SELECT {Cols} FROM Expenses WHERE Id = ?", id).FirstOrDefault();

    public Task<List<ExpenseParticipant>> GetParticipantsAsync(string expenseId)
        => _db.QueryAsync<ExpenseParticipant>($"SELECT {PCols} FROM ExpenseParticipants WHERE ExpenseId = ?", expenseId);

    public Task<List<ExpenseParticipant>> GetParticipantsByGroupAsync(string groupId)
        => _db.QueryAsync<ExpenseParticipant>($"""
            SELECT ep.Id, ep.ExpenseId, ep.FriendId, ep.ShareAmountPaisa, ep.SharePercentBp
            FROM ExpenseParticipants ep JOIN Expenses e ON e.Id = ep.ExpenseId
            WHERE e.GroupId = ?
            """, groupId);

    public void Insert(IDbSession s, Expense e)
        => s.Execute($"INSERT INTO Expenses ({Cols}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            e.Id, e.GroupId, e.Title, e.AmountPaisa, e.CategoryId, e.ExpenseDate, e.PaidByFriendId,
            e.PaymentSource, e.SplitMethod, e.Notes, e.CreatedAt, e.UpdatedAt);

    public void Update(IDbSession s, Expense e)
        => s.Execute("""
            UPDATE Expenses SET Title = ?, AmountPaisa = ?, CategoryId = ?, ExpenseDate = ?, PaidByFriendId = ?,
                   PaymentSource = ?, SplitMethod = ?, Notes = ?, UpdatedAt = ?
            WHERE Id = ?
            """,
            e.Title, e.AmountPaisa, e.CategoryId, e.ExpenseDate, e.PaidByFriendId,
            e.PaymentSource, e.SplitMethod, e.Notes, e.UpdatedAt, e.Id);

    public void Delete(IDbSession s, string id) => s.Execute("DELETE FROM Expenses WHERE Id = ?", id);

    public void InsertParticipant(IDbSession s, ExpenseParticipant p)
        => s.Execute($"INSERT INTO ExpenseParticipants ({PCols}) VALUES (?, ?, ?, ?, ?)",
            p.Id, p.ExpenseId, p.FriendId, p.ShareAmountPaisa, p.SharePercentBp);

    public void DeleteParticipants(IDbSession s, string expenseId)
        => s.Execute("DELETE FROM ExpenseParticipants WHERE ExpenseId = ?", expenseId);
}

public sealed class FundRepository
{
    private const string CCols = "Id, GroupId, FriendId, AmountPaisa, ContributionDate, Notes, CreatedAt, UpdatedAt";
    private const string TCols = "Id, GroupId, Type, AmountPaisa, TransactionDate, FriendId, ContributionId, ExpenseId, Notes, CreatedAt, UpdatedAt";
    private readonly IDatabase _db;
    public FundRepository(IDatabase db) => _db = db;

    public Task<List<FundContribution>> GetContributionsAsync(string groupId)
        => _db.QueryAsync<FundContribution>($"SELECT {CCols} FROM FundContributions WHERE GroupId = ? ORDER BY ContributionDate DESC, CreatedAt DESC", groupId);

    public async Task<FundContribution?> GetContributionAsync(string id)
        => (await _db.QueryAsync<FundContribution>($"SELECT {CCols} FROM FundContributions WHERE Id = ?", id)).FirstOrDefault();

    public FundContribution? GetContribution(IDbSession s, string id)
        => s.Query<FundContribution>($"SELECT {CCols} FROM FundContributions WHERE Id = ?", id).FirstOrDefault();

    public Task<List<FundTransaction>> GetTransactionsAsync(string groupId)
        => _db.QueryAsync<FundTransaction>($"SELECT {TCols} FROM FundTransactions WHERE GroupId = ? ORDER BY TransactionDate DESC, CreatedAt DESC", groupId);

    public async Task<FundTransaction?> GetTransactionAsync(string id)
        => (await _db.QueryAsync<FundTransaction>($"SELECT {TCols} FROM FundTransactions WHERE Id = ?", id)).FirstOrDefault();

    public FundTransaction? GetTransaction(IDbSession s, string id)
        => s.Query<FundTransaction>($"SELECT {TCols} FROM FundTransactions WHERE Id = ?", id).FirstOrDefault();

    /// <summary>Current fund balance computed from the ledger (never stored).</summary>
    public long Balance(IDbSession s, string groupId)
        => s.Scalar<long>("SELECT COALESCE(SUM(AmountPaisa), 0) FROM FundTransactions WHERE GroupId = ?", groupId);

    public Task<long> BalanceAsync(string groupId)
        => _db.ScalarAsync<long>("SELECT COALESCE(SUM(AmountPaisa), 0) FROM FundTransactions WHERE GroupId = ?", groupId);

    public void InsertContribution(IDbSession s, FundContribution c)
        => s.Execute($"INSERT INTO FundContributions ({CCols}) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            c.Id, c.GroupId, c.FriendId, c.AmountPaisa, c.ContributionDate, c.Notes, c.CreatedAt, c.UpdatedAt);

    public void UpdateContribution(IDbSession s, FundContribution c)
        => s.Execute("UPDATE FundContributions SET FriendId = ?, AmountPaisa = ?, ContributionDate = ?, Notes = ?, UpdatedAt = ? WHERE Id = ?",
            c.FriendId, c.AmountPaisa, c.ContributionDate, c.Notes, c.UpdatedAt, c.Id);

    public void DeleteContribution(IDbSession s, string id) => s.Execute("DELETE FROM FundContributions WHERE Id = ?", id);

    public void InsertTransaction(IDbSession s, FundTransaction t)
        => s.Execute($"INSERT INTO FundTransactions ({TCols}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            t.Id, t.GroupId, t.Type, t.AmountPaisa, t.TransactionDate, t.FriendId, t.ContributionId, t.ExpenseId, t.Notes, t.CreatedAt, t.UpdatedAt);

    public void UpdateTransaction(IDbSession s, FundTransaction t)
        => s.Execute("UPDATE FundTransactions SET AmountPaisa = ?, TransactionDate = ?, FriendId = ?, Notes = ?, UpdatedAt = ? WHERE Id = ?",
            t.AmountPaisa, t.TransactionDate, t.FriendId, t.Notes, t.UpdatedAt, t.Id);

    public void DeleteTransaction(IDbSession s, string id) => s.Execute("DELETE FROM FundTransactions WHERE Id = ?", id);

    public void DeleteTransactionForExpense(IDbSession s, string expenseId)
        => s.Execute("DELETE FROM FundTransactions WHERE ExpenseId = ?", expenseId);

    public void DeleteTransactionForContribution(IDbSession s, string contributionId)
        => s.Execute("DELETE FROM FundTransactions WHERE ContributionId = ?", contributionId);
}

public sealed class SettlementRepository
{
    private const string Cols = "Id, GroupId, FromFriendId, ToFriendId, AmountPaisa, SettlementDate, Notes, CreatedAt, UpdatedAt";
    private readonly IDatabase _db;
    public SettlementRepository(IDatabase db) => _db = db;

    public Task<List<Settlement>> GetByGroupAsync(string groupId)
        => _db.QueryAsync<Settlement>($"SELECT {Cols} FROM Settlements WHERE GroupId = ? ORDER BY SettlementDate DESC, CreatedAt DESC", groupId);

    public async Task<Settlement?> GetAsync(string id)
        => (await _db.QueryAsync<Settlement>($"SELECT {Cols} FROM Settlements WHERE Id = ?", id)).FirstOrDefault();

    public Settlement? Get(IDbSession s, string id)
        => s.Query<Settlement>($"SELECT {Cols} FROM Settlements WHERE Id = ?", id).FirstOrDefault();

    public void Insert(IDbSession s, Settlement x)
        => s.Execute($"INSERT INTO Settlements ({Cols}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            x.Id, x.GroupId, x.FromFriendId, x.ToFriendId, x.AmountPaisa, x.SettlementDate, x.Notes, x.CreatedAt, x.UpdatedAt);

    public void Update(IDbSession s, Settlement x)
        => s.Execute("UPDATE Settlements SET FromFriendId = ?, ToFriendId = ?, AmountPaisa = ?, SettlementDate = ?, Notes = ?, UpdatedAt = ? WHERE Id = ?",
            x.FromFriendId, x.ToFriendId, x.AmountPaisa, x.SettlementDate, x.Notes, x.UpdatedAt, x.Id);

    public void Delete(IDbSession s, string id) => s.Execute("DELETE FROM Settlements WHERE Id = ?", id);
}

/// <summary>Loads a complete <see cref="GroupLedger"/> snapshot for calculations.</summary>
public sealed class LedgerRepository
{
    private readonly FriendRepository _friends;
    private readonly ExpenseRepository _expenses;
    private readonly FundRepository _fund;
    private readonly SettlementRepository _settlements;
    private readonly CategoryRepository _categories;

    public LedgerRepository(FriendRepository friends, ExpenseRepository expenses, FundRepository fund,
        SettlementRepository settlements, CategoryRepository categories)
    {
        _friends = friends;
        _expenses = expenses;
        _fund = fund;
        _settlements = settlements;
        _categories = categories;
    }

    public async Task<GroupLedger> LoadAsync(string groupId) => new()
    {
        GroupId = groupId,
        Members = await _friends.GetMembersAsync(groupId),
        Expenses = await _expenses.GetByGroupAsync(groupId),
        Participants = await _expenses.GetParticipantsByGroupAsync(groupId),
        Contributions = await _fund.GetContributionsAsync(groupId),
        FundTransactions = await _fund.GetTransactionsAsync(groupId),
        Settlements = await _settlements.GetByGroupAsync(groupId),
        Categories = await _categories.GetAllAsync(),
    };
}
