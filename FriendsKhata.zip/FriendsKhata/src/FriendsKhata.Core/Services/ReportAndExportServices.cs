using System.Globalization;
using System.Text;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Repositories;

namespace FriendsKhata.Core.Services;

public sealed class ReportService : IReportService
{
    private readonly LedgerRepository _ledger;
    private readonly GroupRepository _groups;

    public ReportService(LedgerRepository ledger, GroupRepository groups)
    {
        _ledger = ledger;
        _groups = groups;
    }

    public async Task<FinancialReport> GetReportAsync(string groupId, ReportPeriod period)
        => ReportBuilder.Build(await _ledger.LoadAsync(groupId), period);

    public async Task<DashboardData> GetDashboardAsync(string groupId, DateTime today)
    {
        var group = await _groups.GetAsync(groupId);
        return DashboardBuilder.Build(await _ledger.LoadAsync(groupId), group?.Name ?? "", today);
    }

    public async Task<IReadOnlyList<TransactionItem>> GetTransactionsAsync(string groupId, TransactionFilter? filter = null)
    {
        var ledger = await _ledger.LoadAsync(groupId);
        filter ??= new TransactionFilter();
        if (!string.IsNullOrEmpty(filter.FriendId)) ledger = LedgerFilters.ForFriend(ledger, filter.FriendId);

        IEnumerable<TransactionItem> q = TransactionHistoryBuilder.Build(ledger);
        if (filter.From is { } from) q = q.Where(t => t.Date >= from.Date);
        if (filter.To is { } to) q = q.Where(t => t.Date <= to.Date);
        if (filter.Kind is { } kind) q = q.Where(t => t.Kind == kind);
        return q.ToList();
    }
}

/// <summary>CSV export (UTF-8 with BOM so Excel shows "Rs." and Urdu names correctly).</summary>
public sealed class ExportService : IExportService
{
    public string TransactionsToCsv(IEnumerable<TransactionItem> items)
    {
        var sb = new StringBuilder();
        Line(sb, "Date", "Type", "Title", "Amount (Rs)", "Related friend", "Payment source", "Description");
        foreach (var t in items)
            Line(sb, t.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), t.KindText, t.Title,
                Num(t.AmountPaisa), t.RelatedFriend, t.PaymentSource, t.Description ?? "");
        return sb.ToString();
    }

    public string ReportToCsv(FinancialReport r, string groupName)
    {
        var sb = new StringBuilder();
        Line(sb, "Friends Khata report");
        Line(sb, "Group", groupName);
        Line(sb, "Period", r.Period.Title);
        Line(sb, "From", r.Period.Start.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), "To", r.Period.End.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
        sb.AppendLine();

        Line(sb, "Summary", "Amount (Rs)");
        Line(sb, "Total expenses", Num(r.TotalExpensesPaisa));
        Line(sb, "Personal payments", Num(r.PersonalPaymentsPaisa));
        Line(sb, "Fund spending", Num(r.FundSpendingPaisa));
        Line(sb, "Contributions", Num(r.ContributionsPaisa));
        Line(sb, "Fund refunds", Num(r.FundRefundsPaisa));
        Line(sb, "Fund adjustments", Num(r.FundAdjustmentsPaisa));
        Line(sb, "Opening fund balance", Num(r.OpeningFundBalancePaisa));
        Line(sb, "Closing fund balance", Num(r.ClosingFundBalancePaisa));
        Line(sb, "Settlements", Num(r.SettlementsTotalPaisa));
        sb.AppendLine();

        Line(sb, "Friend", "Paid personally", "Personal share", "Fund share", "Total share", "Contributed", "Settlements paid", "Settlements received", "Balance at period end");
        foreach (var f in r.Friends)
            Line(sb, f.Name, Num(f.PaidPersonalPaisa), Num(f.PersonalSharePaisa), Num(f.FundSharePaisa), Num(f.TotalSharePaisa),
                Num(f.ContributedPaisa), Num(f.SettlementsPaidPaisa), Num(f.SettlementsReceivedPaisa), Num(f.OutstandingAtEndPaisa));
        sb.AppendLine();

        Line(sb, "Category", "Expenses", "Amount (Rs)", "Share %");
        foreach (var c in r.Categories)
            Line(sb, c.Name, c.Count.ToString(CultureInfo.InvariantCulture), Num(c.AmountPaisa), (c.Fraction * 100).ToString("0.0", CultureInfo.InvariantCulture));
        sb.AppendLine();

        Line(sb, "Settlement date", "From → To", "Amount (Rs)", "Notes");
        foreach (var s in r.Settlements)
            Line(sb, s.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), s.RelatedFriend, Num(s.AmountPaisa), s.Description ?? "");

        return sb.ToString();
    }

    private static string Num(long paisa) => Money.ToRupees(paisa).ToString("0.00", CultureInfo.InvariantCulture);

    private static void Line(StringBuilder sb, params string[] cells)
        => sb.AppendLine(string.Join(",", cells.Select(Escape)));

    internal static string Escape(string value)
    {
        value ??= "";
        // Prevent CSV/formula injection when opened in Excel.
        if (value.Length > 0 && "=+-@".Contains(value[0]) && !decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out _))
            value = "'" + value;
        return value.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0
            ? "\"" + value.Replace("\"", "\"\"") + "\""
            : value;
    }
}
