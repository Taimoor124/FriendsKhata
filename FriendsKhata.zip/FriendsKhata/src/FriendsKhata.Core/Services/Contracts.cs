using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;

namespace FriendsKhata.Core.Services;

// ---------- Input models (drafts) ----------

public sealed class ExpenseDraft
{
    public string? Id { get; set; }
    public string GroupId { get; set; } = "";
    public string Title { get; set; } = "";
    public long AmountPaisa { get; set; }
    public string CategoryId { get; set; } = "";
    public DateTime Date { get; set; } = DateTime.Today;
    public PaymentSource Source { get; set; } = PaymentSource.Personal;
    public string? PaidByFriendId { get; set; }
    public SplitMethod Split { get; set; } = SplitMethod.Equal;
    public List<SplitInput> Participants { get; set; } = new();
    public string? Notes { get; set; }
}

public sealed class ContributionDraft
{
    public string? Id { get; set; }
    public string GroupId { get; set; } = "";
    public string FriendId { get; set; } = "";
    public long AmountPaisa { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    public string? Notes { get; set; }
}

/// <summary>Refund (fund → friend) or manual adjustment of the fund.</summary>
public sealed class FundEntryDraft
{
    public string? Id { get; set; }
    public string GroupId { get; set; } = "";
    public FundTransactionType Type { get; set; } = FundTransactionType.Refund;
    /// <summary>Always entered positive. For adjustments use <see cref="IsIncrease"/>.</summary>
    public long AmountPaisa { get; set; }
    public bool IsIncrease { get; set; }
    public string? FriendId { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    public string? Notes { get; set; }
}

public sealed class SettlementDraft
{
    public string? Id { get; set; }
    public string GroupId { get; set; } = "";
    public string FromFriendId { get; set; } = "";
    public string ToFriendId { get; set; } = "";
    public long AmountPaisa { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    public string? Notes { get; set; }
}

public sealed class FriendDraft
{
    public string GroupId { get; set; } = "";
    /// <summary>Null when adding a brand new friend.</summary>
    public string? FriendId { get; set; }
    public string Name { get; set; } = "";
    public string? Phone { get; set; }
    public DateTime JoiningDate { get; set; } = DateTime.Today;
    public bool IsActive { get; set; } = true;
}

public sealed class ExpenseFilter
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public string? FriendId { get; set; }
    public string? CategoryId { get; set; }
    public PaymentSource? Source { get; set; }
    public string? Search { get; set; }
}

public sealed class TransactionFilter
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public TransactionKind? Kind { get; set; }
    public string? FriendId { get; set; }
}

// ---------- Output models ----------

public sealed class ExpenseDetails
{
    public required Expense Expense { get; init; }
    public required IReadOnlyList<ExpenseParticipant> Participants { get; init; }
}

public sealed class ExpenseListItem
{
    public required Expense Expense { get; init; }
    public required string CategoryName { get; init; }
    public required string CategoryIcon { get; init; }
    public required string PaidByName { get; init; }
    public required int ParticipantCount { get; init; }
}

public sealed class FriendFinancialSummary
{
    public required Member Member { get; init; }
    public required FriendBalance Balance { get; init; }
    public required FriendFundPosition Fund { get; init; }
    public long TotalShareAllExpensesPaisa { get; init; }
    public int ExpensesPaidCount { get; init; }
    public int ExpensesSharedCount { get; init; }
    public required IReadOnlyList<TransactionItem> RecentActivity { get; init; }
    /// <summary>Suggested payments that involve this friend.</summary>
    public required IReadOnlyList<SettlementSuggestion> Suggestions { get; init; }
}

public sealed class BackupInfo
{
    public required bool IsValid { get; init; }
    public string? Error { get; init; }
    public int SchemaVersion { get; init; }
    public int GroupCount { get; init; }
    public int ExpenseCount { get; init; }
    public long FileSizeBytes { get; init; }
}

// ---------- Service interfaces ----------

public interface IGroupService
{
    Task<IReadOnlyList<FriendGroup>> GetGroupsAsync();
    Task<FriendGroup?> GetGroupAsync(string id);
    Task<FriendGroup> CreateAsync(string name, string? description);
    Task UpdateAsync(string id, string name, string? description);
    Task DeleteAsync(string id);
}

public interface IFriendService
{
    Task<IReadOnlyList<Member>> GetMembersAsync(string groupId, bool includeInactive = true);
    Task<Member?> GetMemberAsync(string groupId, string friendId);
    Task<IReadOnlyList<Friend>> GetFriendsNotInGroupAsync(string groupId);
    /// <summary>Adds a new friend or updates an existing member. Returns the friend id.</summary>
    Task<string> SaveAsync(FriendDraft draft);
    Task AddExistingFriendAsync(string groupId, string friendId, DateTime joiningDate);
    Task SetActiveAsync(string groupId, string friendId, bool active);
    Task<bool> HasFinancialRecordsAsync(string groupId, string friendId);
    /// <summary>Removes the friend from the group. Fails if the friend has financial records (deactivate instead).</summary>
    Task RemoveAsync(string groupId, string friendId);
    Task<FriendFinancialSummary> GetSummaryAsync(string groupId, string friendId);
}

public interface ICategoryService
{
    Task<IReadOnlyList<Category>> GetAllAsync();
    Task<Category> AddAsync(string name, string? icon);
    Task UpdateAsync(string id, string name, string? icon);
    Task DeleteAsync(string id);
}

public interface IExpenseService
{
    Task<IReadOnlyList<ExpenseListItem>> GetExpensesAsync(string groupId, ExpenseFilter? filter = null);
    Task<ExpenseDetails?> GetAsync(string expenseId);
    /// <summary>Validates, calculates shares and saves (insert or update) in one transaction. Returns the expense id.</summary>
    Task<string> SaveAsync(ExpenseDraft draft);
    Task DeleteAsync(string expenseId);
}

public interface IFundService
{
    Task<FundSummary> GetSummaryAsync(string groupId);
    Task<long> GetBalanceAsync(string groupId);
    Task<IReadOnlyList<FundContribution>> GetContributionsAsync(string groupId);
    Task<FundContribution?> GetContributionAsync(string id);
    Task<string> SaveContributionAsync(ContributionDraft draft);
    Task DeleteContributionAsync(string id);
    Task<FundTransaction?> GetFundEntryAsync(string id);
    Task<string> SaveFundEntryAsync(FundEntryDraft draft);
    Task DeleteFundEntryAsync(string id);
    /// <summary>Fund ledger, newest first, with the running balance after each entry.</summary>
    Task<IReadOnlyList<(TransactionItem Item, long SignedAmountPaisa, long BalanceAfterPaisa)>> GetLedgerAsync(string groupId);
}

public interface ISettlementService
{
    Task<IReadOnlyList<FriendBalance>> GetBalancesAsync(string groupId);
    Task<IReadOnlyList<SettlementSuggestion>> GetSuggestionsAsync(string groupId);
    Task<IReadOnlyList<TransactionItem>> GetHistoryAsync(string groupId);
    Task<Settlement?> GetAsync(string id);
    Task<string> SaveAsync(SettlementDraft draft);
    Task DeleteAsync(string id);
}

public interface IReportService
{
    Task<FinancialReport> GetReportAsync(string groupId, ReportPeriod period);
    Task<DashboardData> GetDashboardAsync(string groupId, DateTime today);
    Task<IReadOnlyList<TransactionItem>> GetTransactionsAsync(string groupId, TransactionFilter? filter = null);
}

public interface IExportService
{
    string TransactionsToCsv(IEnumerable<TransactionItem> items);
    string ReportToCsv(FinancialReport report, string groupName);
}

public interface IBackupService
{
    /// <summary>Writes a consistent copy of the database to a new temporary file and returns its path.</summary>
    Task<string> CreateBackupFileAsync();
    Task<BackupInfo> InspectBackupAsync(string backupPath);
    /// <summary>Replaces the current database with the backup (after a safety copy). Caller must confirm with the user first.</summary>
    Task RestoreAsync(string backupPath);
}
