using FriendsKhata.Core.Common;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Repositories;

namespace FriendsKhata.Core.Services;

public sealed class SettlementService : ISettlementService
{
    private readonly IDatabase _db;
    private readonly SettlementRepository _settlements;
    private readonly FriendRepository _friends;
    private readonly LedgerRepository _ledger;

    public SettlementService(IDatabase db, SettlementRepository settlements, FriendRepository friends, LedgerRepository ledger)
    {
        _db = db;
        _settlements = settlements;
        _friends = friends;
        _ledger = ledger;
    }

    public async Task<IReadOnlyList<FriendBalance>> GetBalancesAsync(string groupId)
        => BalanceCalculator.Calculate(await _ledger.LoadAsync(groupId));

    public async Task<IReadOnlyList<SettlementSuggestion>> GetSuggestionsAsync(string groupId)
        => SettlementOptimizer.Suggest(await GetBalancesAsync(groupId));

    public async Task<IReadOnlyList<TransactionItem>> GetHistoryAsync(string groupId)
        => TransactionHistoryBuilder.Build(await _ledger.LoadAsync(groupId))
            .Where(t => t.Kind == TransactionKind.Settlement).ToList();

    public Task<Settlement?> GetAsync(string id) => _settlements.GetAsync(id);

    public async Task<string> SaveAsync(SettlementDraft d)
    {
        Guard.Require(!string.IsNullOrEmpty(d.FromFriendId), "Please select who is paying.");
        Guard.Require(!string.IsNullOrEmpty(d.ToFriendId), "Please select who receives the payment.");
        Guard.Require(d.FromFriendId != d.ToFriendId, "Sender and receiver must be different friends.");
        Guard.Require(d.AmountPaisa > 0, "Amount must be greater than zero.");

        var id = d.Id ?? Ids.New();
        var now = DbDate.Now();

        await _db.RunInTransactionAsync(s =>
        {
            Guard.Require(_friends.GetMember(s, d.GroupId, d.FromFriendId) is not null, "The sender is not a member of this group.");
            Guard.Require(_friends.GetMember(s, d.GroupId, d.ToFriendId) is not null, "The receiver is not a member of this group.");

            Settlement? old = null;
            if (d.Id is not null)
            {
                old = _settlements.Get(s, d.Id) ?? throw new ValidationException("This settlement no longer exists.");
                Guard.Require(old.GroupId == d.GroupId, "Settlement belongs to a different group.");
            }

            var entity = new Settlement
            {
                Id = id, GroupId = d.GroupId, FromFriendId = d.FromFriendId, ToFriendId = d.ToFriendId,
                AmountPaisa = d.AmountPaisa, SettlementDate = DbDate.ToDb(d.Date),
                Notes = string.IsNullOrWhiteSpace(d.Notes) ? null : d.Notes.Trim(),
                CreatedAt = old?.CreatedAt ?? now, UpdatedAt = now
            };
            if (old is null) _settlements.Insert(s, entity);
            else _settlements.Update(s, entity);
        });

        return id;
    }

    public Task DeleteAsync(string id)
        => _db.RunInTransactionAsync(s =>
        {
            Guard.Require(_settlements.Get(s, id) is not null, "This settlement no longer exists.");
            _settlements.Delete(s, id);
        });
}
