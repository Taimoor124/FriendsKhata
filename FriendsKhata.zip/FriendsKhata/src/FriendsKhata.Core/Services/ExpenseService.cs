using FriendsKhata.Core.Common;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Repositories;

namespace FriendsKhata.Core.Services;

public sealed class ExpenseService : IExpenseService
{
    private readonly IDatabase _db;
    private readonly ExpenseRepository _expenses;
    private readonly FriendRepository _friends;
    private readonly CategoryRepository _categories;
    private readonly FundRepository _fund;
    private readonly LedgerRepository _ledger;

    public ExpenseService(IDatabase db, ExpenseRepository expenses, FriendRepository friends,
        CategoryRepository categories, FundRepository fund, LedgerRepository ledger)
    {
        _db = db;
        _expenses = expenses;
        _friends = friends;
        _categories = categories;
        _fund = fund;
        _ledger = ledger;
    }

    public async Task<IReadOnlyList<ExpenseListItem>> GetExpensesAsync(string groupId, ExpenseFilter? filter = null)
    {
        var ledger = await _ledger.LoadAsync(groupId);
        IEnumerable<Expense> q = ledger.Expenses;
        filter ??= new ExpenseFilter();

        if (filter.From is { } from) q = q.Where(e => e.Date >= from.Date);
        if (filter.To is { } to) q = q.Where(e => e.Date <= to.Date);
        if (filter.Source is { } src) q = q.Where(e => e.Source == src);
        if (!string.IsNullOrEmpty(filter.CategoryId)) q = q.Where(e => e.CategoryId == filter.CategoryId);
        if (!string.IsNullOrEmpty(filter.FriendId))
            q = q.Where(e => e.PaidByFriendId == filter.FriendId
                             || ledger.ParticipantsByExpense[e.Id].Any(p => p.FriendId == filter.FriendId));

        var items = q.Select(e =>
        {
            var cat = ledger.Category(e.CategoryId);
            return new ExpenseListItem
            {
                Expense = e,
                CategoryName = cat?.Name ?? "Uncategorised",
                CategoryIcon = cat?.Icon ?? "📦",
                PaidByName = e.IsFundExpense ? "Group Fund" : ledger.FriendName(e.PaidByFriendId),
                ParticipantCount = ledger.ParticipantsByExpense[e.Id].Count()
            };
        });

        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            var term = filter.Search.Trim();
            items = items.Where(i =>
                i.Expense.Title.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                (i.Expense.Notes?.Contains(term, StringComparison.OrdinalIgnoreCase) ?? false) ||
                i.CategoryName.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                i.PaidByName.Contains(term, StringComparison.OrdinalIgnoreCase));
        }

        return items.ToList();
    }

    public async Task<ExpenseDetails?> GetAsync(string expenseId)
    {
        var e = await _expenses.GetAsync(expenseId);
        if (e is null) return null;
        return new ExpenseDetails { Expense = e, Participants = await _expenses.GetParticipantsAsync(expenseId) };
    }

    public async Task<string> SaveAsync(ExpenseDraft d)
    {
        var title = (d.Title ?? "").Trim();
        Guard.Require(title.Length > 0, "Please enter an expense title.");
        Guard.Require(title.Length <= 100, "Title is too long (maximum 100 characters).");
        Guard.Require(d.AmountPaisa > 0, "Amount must be greater than zero.");
        Guard.Require(!string.IsNullOrEmpty(d.CategoryId), "Please select a category.");
        Guard.Require(!string.IsNullOrEmpty(d.GroupId), "No group selected.");
        Guard.Require(d.Source is PaymentSource.Personal or PaymentSource.GroupFund, "Please select the payment source.");
        if (d.Source == PaymentSource.Personal)
            Guard.Require(!string.IsNullOrEmpty(d.PaidByFriendId), "Please select who paid.");

        // Pure calculation first: throws a friendly ValidationException if the split is invalid.
        var shares = SplitCalculator.Calculate(d.AmountPaisa, d.Split, d.Participants);

        var id = d.Id ?? Ids.New();
        var now = DbDate.Now();

        await _db.RunInTransactionAsync(s =>
        {
            Expense? old = null;
            if (d.Id is not null)
            {
                old = _expenses.Get(s, d.Id) ?? throw new ValidationException("This expense no longer exists.");
                Guard.Require(old.GroupId == d.GroupId, "Expense belongs to a different group.");
            }

            Guard.Require(_categories.Exists(s, d.CategoryId), "The selected category no longer exists.");

            var members = _friends.GetMembers(s, d.GroupId).ToDictionary(m => m.FriendId);
            var previousParticipants = old is null
                ? new HashSet<string>()
                : s.Query<ExpenseParticipant>("SELECT FriendId FROM ExpenseParticipants WHERE ExpenseId = ?", old.Id)
                    .Select(p => p.FriendId).ToHashSet();

            if (!string.IsNullOrEmpty(d.PaidByFriendId))
            {
                Guard.Require(members.TryGetValue(d.PaidByFriendId, out var payer), "The selected payer is not a member of this group.");
                Guard.Require(payer!.IsActive || old?.PaidByFriendId == d.PaidByFriendId, $"{payer.Name} is inactive and cannot be selected as payer.");
            }

            foreach (var sh in shares)
            {
                Guard.Require(members.TryGetValue(sh.FriendId, out var m), "A selected friend is not a member of this group.");
                Guard.Require(m!.IsActive || previousParticipants.Contains(sh.FriendId), $"{m.Name} is inactive and cannot be added to new expenses.");
            }

            if (d.Source == PaymentSource.GroupFund)
            {
                // Balance without this expense's previous deduction (if it was a fund expense), so an edit
                // never counts the same expense twice.
                var balance = _fund.Balance(s, d.GroupId);
                if (old is { IsFundExpense: true }) balance += old.AmountPaisa;
                Guard.Require(balance >= d.AmountPaisa,
                    $"Not enough money in the group fund. Available: {Money.Format(balance)}, needed: {Money.Format(d.AmountPaisa)}. " +
                    "Add a contribution first or mark the expense as a personal payment.");
            }

            var entity = new Expense
            {
                Id = id,
                GroupId = d.GroupId,
                Title = title,
                AmountPaisa = d.AmountPaisa,
                CategoryId = d.CategoryId,
                ExpenseDate = DbDate.ToDb(d.Date),
                PaidByFriendId = string.IsNullOrEmpty(d.PaidByFriendId) ? null : d.PaidByFriendId,
                PaymentSource = (long)d.Source,
                SplitMethod = (long)d.Split,
                Notes = string.IsNullOrWhiteSpace(d.Notes) ? null : d.Notes.Trim(),
                CreatedAt = old?.CreatedAt ?? now,
                UpdatedAt = now
            };

            // 1) Reverse the previous financial impact (shares + fund deduction) ...
            if (old is not null)
            {
                _expenses.DeleteParticipants(s, id);
                _fund.DeleteTransactionForExpense(s, id);
                _expenses.Update(s, entity);
            }
            else
            {
                _expenses.Insert(s, entity);
            }

            // 2) ... then apply the new one.
            foreach (var sh in shares)
            {
                _expenses.InsertParticipant(s, new ExpenseParticipant
                {
                    Id = Ids.New(),
                    ExpenseId = id,
                    FriendId = sh.FriendId,
                    ShareAmountPaisa = sh.SharePaisa,
                    SharePercentBp = sh.PercentBp
                });
            }

            if (d.Source == PaymentSource.GroupFund)
            {
                _fund.InsertTransaction(s, new FundTransaction
                {
                    Id = Ids.New(),
                    GroupId = d.GroupId,
                    Type = (long)FundTransactionType.Expense,
                    AmountPaisa = -d.AmountPaisa,
                    TransactionDate = entity.ExpenseDate,
                    FriendId = entity.PaidByFriendId,
                    ExpenseId = id,
                    Notes = title,
                    CreatedAt = now,
                    UpdatedAt = now
                });
            }
        });

        return id;
    }

    public Task DeleteAsync(string expenseId)
        => _db.RunInTransactionAsync(s =>
        {
            var old = _expenses.Get(s, expenseId) ?? throw new ValidationException("This expense no longer exists.");
            _expenses.DeleteParticipants(s, old.Id);
            _fund.DeleteTransactionForExpense(s, old.Id);   // returns the money to the fund balance
            _expenses.Delete(s, old.Id);
        });
}
