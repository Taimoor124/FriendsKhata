using System.Text.RegularExpressions;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Repositories;

namespace FriendsKhata.Core.Services;

public sealed class GroupService : IGroupService
{
    private readonly IDatabase _db;
    private readonly GroupRepository _groups;

    public GroupService(IDatabase db, GroupRepository groups)
    {
        _db = db;
        _groups = groups;
    }

    public async Task<IReadOnlyList<FriendGroup>> GetGroupsAsync() => await _groups.GetAllAsync();

    public Task<FriendGroup?> GetGroupAsync(string id) => _groups.GetAsync(id);

    public async Task<FriendGroup> CreateAsync(string name, string? description)
    {
        var group = new FriendGroup
        {
            Id = Ids.New(),
            Name = ValidateName(name),
            Description = string.IsNullOrWhiteSpace(description) ? null : description.Trim(),
            CreatedAt = DbDate.Now()
        };
        await _db.RunInTransactionAsync(s =>
        {
            Guard.Require(!_groups.NameExists(s, group.Name, null), $"A group named \"{group.Name}\" already exists.");
            _groups.Insert(s, group);
        });
        return group;
    }

    public Task UpdateAsync(string id, string name, string? description)
    {
        var clean = ValidateName(name);
        return _db.RunInTransactionAsync(s =>
        {
            Guard.Require(!_groups.NameExists(s, clean, id), $"A group named \"{clean}\" already exists.");
            var g = s.Query<FriendGroup>("SELECT Id, Name, Description, CreatedAt, IsArchived FROM Groups WHERE Id = ?", id).FirstOrDefault()
                    ?? throw new ValidationException("This group no longer exists.");
            g.Name = clean;
            g.Description = string.IsNullOrWhiteSpace(description) ? null : description.Trim();
            _groups.Update(s, g);
        });
    }

    /// <summary>Deletes the group and ALL its records (cascade). Friends who belong to no other group are removed too.</summary>
    public Task DeleteAsync(string id)
        => _db.RunInTransactionAsync(s =>
        {
            _groups.Delete(s, id);
            s.Execute("""
                DELETE FROM Friends
                WHERE Id NOT IN (SELECT FriendId FROM GroupMembers)
                  AND Id NOT IN (SELECT PaidByFriendId FROM Expenses WHERE PaidByFriendId IS NOT NULL)
                  AND Id NOT IN (SELECT FriendId FROM ExpenseParticipants)
                  AND Id NOT IN (SELECT FriendId FROM FundContributions)
                  AND Id NOT IN (SELECT FriendId FROM FundTransactions WHERE FriendId IS NOT NULL)
                  AND Id NOT IN (SELECT FromFriendId FROM Settlements)
                  AND Id NOT IN (SELECT ToFriendId FROM Settlements)
                """);
        });

    private static string ValidateName(string? name)
    {
        var clean = (name ?? "").Trim();
        Guard.Require(clean.Length > 0, "Please enter a group name.");
        Guard.Require(clean.Length <= 50, "Group name is too long (maximum 50 characters).");
        return clean;
    }
}

public sealed partial class FriendService : IFriendService
{
    private readonly IDatabase _db;
    private readonly FriendRepository _friends;
    private readonly LedgerRepository _ledger;

    public FriendService(IDatabase db, FriendRepository friends, LedgerRepository ledger)
    {
        _db = db;
        _friends = friends;
        _ledger = ledger;
    }

    [GeneratedRegex(@"^\+?[0-9][0-9 \-]{5,19}$")]
    private static partial Regex PhoneRegex();

    public async Task<IReadOnlyList<Member>> GetMembersAsync(string groupId, bool includeInactive = true)
    {
        var all = await _friends.GetMembersAsync(groupId);
        return includeInactive ? all : all.Where(m => m.IsActive).ToList();
    }

    public Task<Member?> GetMemberAsync(string groupId, string friendId) => _friends.GetMemberAsync(groupId, friendId);

    public async Task<IReadOnlyList<Friend>> GetFriendsNotInGroupAsync(string groupId)
        => await _friends.GetFriendsNotInGroupAsync(groupId);

    public async Task<string> SaveAsync(FriendDraft d)
    {
        var name = (d.Name ?? "").Trim();
        Guard.Require(name.Length > 0, "Please enter the friend's name.");
        Guard.Require(name.Length <= 60, "Name is too long (maximum 60 characters).");
        var phone = string.IsNullOrWhiteSpace(d.Phone) ? null : d.Phone.Trim();
        if (phone is not null)
            Guard.Require(PhoneRegex().IsMatch(phone), "Phone number looks invalid. Use digits only, e.g. 03001234567 or +923001234567.");
        Guard.Require(d.JoiningDate.Date <= DateTime.Today.AddDays(1), "Joining date cannot be in the future.");

        var friendId = d.FriendId ?? Ids.New();
        var now = DbDate.Now();

        await _db.RunInTransactionAsync(s =>
        {
            Guard.Require(!_friends.MemberNameExists(s, d.GroupId, name, d.FriendId),
                $"A friend named \"{name}\" is already in this group.");

            if (d.FriendId is null)
            {
                _friends.InsertFriend(s, new Friend { Id = friendId, Name = name, Phone = phone, CreatedAt = now });
                _friends.InsertMember(s, new GroupMember
                {
                    Id = Ids.New(), GroupId = d.GroupId, FriendId = friendId,
                    JoiningDate = DbDate.ToDb(d.JoiningDate),
                    Status = (long)(d.IsActive ? MemberStatus.Active : MemberStatus.Inactive),
                    CreatedAt = now
                });
            }
            else
            {
                var friend = _friends.GetFriend(s, d.FriendId) ?? throw new ValidationException("This friend no longer exists.");
                Guard.Require(_friends.GetMember(s, d.GroupId, d.FriendId) is not null, "This friend is not in the group.");
                friend.Name = name;
                friend.Phone = phone;
                _friends.UpdateFriend(s, friend);
                _friends.UpdateMember(s, d.GroupId, d.FriendId, DbDate.ToDb(d.JoiningDate),
                    (long)(d.IsActive ? MemberStatus.Active : MemberStatus.Inactive));
            }
        });

        return friendId;
    }

    public Task AddExistingFriendAsync(string groupId, string friendId, DateTime joiningDate)
        => _db.RunInTransactionAsync(s =>
        {
            var friend = _friends.GetFriend(s, friendId) ?? throw new ValidationException("This friend no longer exists.");
            Guard.Require(_friends.GetMember(s, groupId, friendId) is null, $"{friend.Name} is already in this group.");
            Guard.Require(!_friends.MemberNameExists(s, groupId, friend.Name, friendId),
                $"A different friend named \"{friend.Name}\" is already in this group.");
            _friends.InsertMember(s, new GroupMember
            {
                Id = Ids.New(), GroupId = groupId, FriendId = friendId, JoiningDate = DbDate.ToDb(joiningDate),
                Status = (long)MemberStatus.Active, CreatedAt = DbDate.Now()
            });
        });

    public Task SetActiveAsync(string groupId, string friendId, bool active)
        => _db.RunInTransactionAsync(s =>
        {
            var m = _friends.GetMember(s, groupId, friendId) ?? throw new ValidationException("This friend is not in the group.");
            _friends.UpdateMember(s, groupId, friendId, m.JoiningDate, (long)(active ? MemberStatus.Active : MemberStatus.Inactive));
        });

    public async Task<bool> HasFinancialRecordsAsync(string groupId, string friendId)
    {
        long count = 0;
        await _db.RunInTransactionAsync(s => count = _friends.CountFinancialRecords(s, groupId, friendId));
        return count > 0;
    }

    public Task RemoveAsync(string groupId, string friendId)
        => _db.RunInTransactionAsync(s =>
        {
            var m = _friends.GetMember(s, groupId, friendId) ?? throw new ValidationException("This friend is not in the group.");
            Guard.Require(_friends.CountFinancialRecords(s, groupId, friendId) == 0,
                $"{m.Name} has expenses, contributions or settlements in this group, so they cannot be deleted " +
                "without breaking the accounts. Mark them as Inactive instead.");
            _friends.DeleteMember(s, groupId, friendId);
            if (_friends.CountMemberships(s, friendId) == 0)
                _friends.DeleteFriend(s, friendId);
        });

    public async Task<FriendFinancialSummary> GetSummaryAsync(string groupId, string friendId)
    {
        var ledger = await _ledger.LoadAsync(groupId);
        var member = ledger.Members.FirstOrDefault(m => m.FriendId == friendId)
                     ?? throw new ValidationException("This friend is not in the group.");

        var balances = BalanceCalculator.Calculate(ledger);
        var fund = FundCalculator.Calculate(ledger);
        var own = LedgerFilters.ForFriend(ledger, friendId);

        return new FriendFinancialSummary
        {
            Member = member,
            Balance = balances.First(b => b.FriendId == friendId),
            Fund = fund.Friends.First(f => f.FriendId == friendId),
            TotalShareAllExpensesPaisa = ledger.Participants.Where(p => p.FriendId == friendId).Sum(p => p.ShareAmountPaisa),
            ExpensesPaidCount = ledger.Expenses.Count(e => e.PaidByFriendId == friendId && !e.IsFundExpense),
            ExpensesSharedCount = ledger.Participants.Count(p => p.FriendId == friendId),
            RecentActivity = TransactionHistoryBuilder.Build(own).Take(30).ToList(),
            Suggestions = SettlementOptimizer.Suggest(balances)
                .Where(x => x.FromFriendId == friendId || x.ToFriendId == friendId).ToList()
        };
    }
}

public static class LedgerFilters
{
    /// <summary>A sub-ledger containing only the records in which the friend is involved.</summary>
    public static GroupLedger ForFriend(GroupLedger ledger, string friendId)
    {
        var expenseIds = ledger.Expenses
            .Where(e => e.PaidByFriendId == friendId || ledger.ParticipantsByExpense[e.Id].Any(p => p.FriendId == friendId))
            .Select(e => e.Id).ToHashSet();

        return new GroupLedger
        {
            GroupId = ledger.GroupId,
            Members = ledger.Members,
            Categories = ledger.Categories,
            Expenses = ledger.Expenses.Where(e => expenseIds.Contains(e.Id)).ToList(),
            Participants = ledger.Participants.Where(p => expenseIds.Contains(p.ExpenseId)).ToList(),
            Contributions = ledger.Contributions.Where(c => c.FriendId == friendId).ToList(),
            FundTransactions = ledger.FundTransactions.Where(t => t.FriendId == friendId
                || (t.ExpenseId != null && expenseIds.Contains(t.ExpenseId))).ToList(),
            Settlements = ledger.Settlements.Where(x => x.FromFriendId == friendId || x.ToFriendId == friendId).ToList(),
        };
    }
}

public sealed class CategoryService : ICategoryService
{
    private readonly IDatabase _db;
    private readonly CategoryRepository _categories;

    public CategoryService(IDatabase db, CategoryRepository categories)
    {
        _db = db;
        _categories = categories;
    }

    public async Task<IReadOnlyList<Category>> GetAllAsync() => await _categories.GetAllAsync();

    public async Task<Category> AddAsync(string name, string? icon)
    {
        var c = new Category
        {
            Id = Ids.New(), Name = Clean(name), Icon = CleanIcon(icon), IsSystem = 0, SortOrder = 50, CreatedAt = DbDate.Now()
        };
        await _db.RunInTransactionAsync(s =>
        {
            Guard.Require(!_categories.NameExists(s, c.Name, null), $"Category \"{c.Name}\" already exists.");
            _categories.Insert(s, c);
        });
        return c;
    }

    public Task UpdateAsync(string id, string name, string? icon)
    {
        var clean = Clean(name);
        return _db.RunInTransactionAsync(s =>
        {
            var c = _categories.Get(s, id) ?? throw new ValidationException("This category no longer exists.");
            Guard.Require(!_categories.NameExists(s, clean, id), $"Category \"{clean}\" already exists.");
            c.Name = clean;
            c.Icon = CleanIcon(icon);
            _categories.Update(s, c);
        });
    }

    public Task DeleteAsync(string id)
        => _db.RunInTransactionAsync(s =>
        {
            var c = _categories.Get(s, id) ?? throw new ValidationException("This category no longer exists.");
            Guard.Require(c.IsSystem == 0, "Built-in categories cannot be deleted, but you can rename them.");
            var used = _categories.UsageCount(s, id);
            Guard.Require(used == 0, $"\"{c.Name}\" is used by {used} expense(s). Change those expenses to another category first.");
            _categories.Delete(s, id);
        });

    private static string Clean(string? name)
    {
        var clean = (name ?? "").Trim();
        Guard.Require(clean.Length > 0, "Please enter a category name.");
        Guard.Require(clean.Length <= 40, "Category name is too long (maximum 40 characters).");
        return clean;
    }

    private static string CleanIcon(string? icon)
    {
        var clean = (icon ?? "").Trim();
        if (clean.Length == 0) return "🏷️";
        return clean.Length > 8 ? clean[..8] : clean;
    }
}
