using FriendsKhata.Core.Common;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Repositories;

namespace FriendsKhata.Core.Services;

public sealed class FundService : IFundService
{
    private readonly IDatabase _db;
    private readonly FundRepository _fund;
    private readonly FriendRepository _friends;
    private readonly LedgerRepository _ledger;

    public FundService(IDatabase db, FundRepository fund, FriendRepository friends, LedgerRepository ledger)
    {
        _db = db;
        _fund = fund;
        _friends = friends;
        _ledger = ledger;
    }

    public async Task<FundSummary> GetSummaryAsync(string groupId)
        => FundCalculator.Calculate(await _ledger.LoadAsync(groupId));

    public Task<long> GetBalanceAsync(string groupId) => _fund.BalanceAsync(groupId);

    public async Task<IReadOnlyList<FundContribution>> GetContributionsAsync(string groupId)
        => await _fund.GetContributionsAsync(groupId);

    public Task<FundContribution?> GetContributionAsync(string id) => _fund.GetContributionAsync(id);

    public async Task<string> SaveContributionAsync(ContributionDraft d)
    {
        Guard.Require(!string.IsNullOrEmpty(d.FriendId), "Please select the contributing friend.");
        Guard.Require(d.AmountPaisa > 0, "Contribution amount must be greater than zero.");

        var id = d.Id ?? Ids.New();
        var now = DbDate.Now();
        var date = DbDate.ToDb(d.Date);
        var notes = string.IsNullOrWhiteSpace(d.Notes) ? null : d.Notes.Trim();

        await _db.RunInTransactionAsync(s =>
        {
            var member = _friends.GetMember(s, d.GroupId, d.FriendId);
            Guard.Require(member is not null, "The selected friend is not a member of this group.");

            if (d.Id is null)
            {
                Guard.Require(member!.IsActive, $"{member.Name} is inactive. Activate the friend first.");
                _fund.InsertContribution(s, new FundContribution
                {
                    Id = id, GroupId = d.GroupId, FriendId = d.FriendId, AmountPaisa = d.AmountPaisa,
                    ContributionDate = date, Notes = notes, CreatedAt = now, UpdatedAt = now
                });
            }
            else
            {
                var old = _fund.GetContribution(s, d.Id) ?? throw new ValidationException("This contribution no longer exists.");
                Guard.Require(old.GroupId == d.GroupId, "Contribution belongs to a different group.");

                var balanceAfter = _fund.Balance(s, d.GroupId) - old.AmountPaisa + d.AmountPaisa;
                Guard.Require(balanceAfter >= 0,
                    $"This change would make the fund balance negative ({Money.Format(balanceAfter)}). The money has already been spent.");

                // Reverse the old ledger row, update the contribution, write the new ledger row.
                _fund.DeleteTransactionForContribution(s, old.Id);
                _fund.UpdateContribution(s, new FundContribution
                {
                    Id = old.Id, GroupId = old.GroupId, FriendId = d.FriendId, AmountPaisa = d.AmountPaisa,
                    ContributionDate = date, Notes = notes, CreatedAt = old.CreatedAt, UpdatedAt = now
                });
            }

            _fund.InsertTransaction(s, new FundTransaction
            {
                Id = Ids.New(), GroupId = d.GroupId, Type = (long)FundTransactionType.Contribution,
                AmountPaisa = d.AmountPaisa, TransactionDate = date, FriendId = d.FriendId,
                ContributionId = id, Notes = notes, CreatedAt = now, UpdatedAt = now
            });
        });

        return id;
    }

    public Task DeleteContributionAsync(string id)
        => _db.RunInTransactionAsync(s =>
        {
            var old = _fund.GetContribution(s, id) ?? throw new ValidationException("This contribution no longer exists.");
            var balanceAfter = _fund.Balance(s, old.GroupId) - old.AmountPaisa;
            Guard.Require(balanceAfter >= 0,
                $"Cannot delete: the fund would become negative ({Money.Format(balanceAfter)}) because this money has already been spent. " +
                "Delete or change the related fund expenses first.");
            _fund.DeleteTransactionForContribution(s, id);
            _fund.DeleteContribution(s, id);
        });

    public Task<FundTransaction?> GetFundEntryAsync(string id) => _fund.GetTransactionAsync(id);

    public async Task<string> SaveFundEntryAsync(FundEntryDraft d)
    {
        Guard.Require(d.Type is FundTransactionType.Refund or FundTransactionType.Adjustment, "Choose refund or adjustment.");
        Guard.Require(d.AmountPaisa > 0, "Amount must be greater than zero.");
        if (d.Type == FundTransactionType.Refund)
            Guard.Require(!string.IsNullOrEmpty(d.FriendId), "Please select the friend who receives the refund.");

        var signed = d.Type == FundTransactionType.Refund || !d.IsIncrease ? -d.AmountPaisa : d.AmountPaisa;
        var id = d.Id ?? Ids.New();
        var now = DbDate.Now();
        var friendId = string.IsNullOrEmpty(d.FriendId) ? null : d.FriendId;

        await _db.RunInTransactionAsync(s =>
        {
            if (friendId is not null)
                Guard.Require(_friends.GetMember(s, d.GroupId, friendId) is not null, "The selected friend is not a member of this group.");

            var balance = _fund.Balance(s, d.GroupId);
            FundTransaction? old = null;
            if (d.Id is not null)
            {
                old = _fund.GetTransaction(s, d.Id) ?? throw new ValidationException("This entry no longer exists.");
                Guard.Require(old.Kind is FundTransactionType.Refund or FundTransactionType.Adjustment,
                    "Only refunds and adjustments can be edited here.");
                Guard.Require(old.Kind == d.Type, "The entry type cannot be changed. Delete it and add a new one.");
                balance -= old.AmountPaisa;
            }

            Guard.Require(balance + signed >= 0,
                $"Not enough money in the group fund. Available: {Money.Format(balance)}.");

            var entity = new FundTransaction
            {
                Id = id, GroupId = d.GroupId, Type = (long)d.Type, AmountPaisa = signed,
                TransactionDate = DbDate.ToDb(d.Date), FriendId = friendId,
                Notes = string.IsNullOrWhiteSpace(d.Notes) ? null : d.Notes.Trim(),
                CreatedAt = old?.CreatedAt ?? now, UpdatedAt = now
            };

            if (old is null) _fund.InsertTransaction(s, entity);
            else _fund.UpdateTransaction(s, entity);
        });

        return id;
    }

    public Task DeleteFundEntryAsync(string id)
        => _db.RunInTransactionAsync(s =>
        {
            var old = _fund.GetTransaction(s, id) ?? throw new ValidationException("This entry no longer exists.");
            Guard.Require(old.Kind is FundTransactionType.Refund or FundTransactionType.Adjustment,
                "Contributions and fund expenses are deleted from their own screens.");
            var balanceAfter = _fund.Balance(s, old.GroupId) - old.AmountPaisa;
            Guard.Require(balanceAfter >= 0, $"Cannot delete: the fund would become negative ({Money.Format(balanceAfter)}).");
            _fund.DeleteTransaction(s, id);
        });

    public async Task<IReadOnlyList<(TransactionItem Item, long SignedAmountPaisa, long BalanceAfterPaisa)>> GetLedgerAsync(string groupId)
    {
        var ledger = await _ledger.LoadAsync(groupId);
        var history = TransactionHistoryBuilder.Build(ledger)
            .Where(t => t.Kind is TransactionKind.Contribution or TransactionKind.FundExpense
                        or TransactionKind.FundRefund or TransactionKind.FundAdjustment)
            .ToList();

        // Signed amount for each history row, taken from the fund ledger itself.
        var byExpense = ledger.FundTransactions.Where(t => t.ExpenseId != null).ToDictionary(t => t.ExpenseId!);
        var byContribution = ledger.FundTransactions.Where(t => t.ContributionId != null).ToDictionary(t => t.ContributionId!);
        var byId = ledger.FundTransactions.ToDictionary(t => t.Id);

        long Signed(TransactionItem i) => i.Kind switch
        {
            TransactionKind.FundExpense => byExpense.TryGetValue(i.SourceId, out var t) ? t.AmountPaisa : -i.AmountPaisa,
            TransactionKind.Contribution => byContribution.TryGetValue(i.SourceId, out var t) ? t.AmountPaisa : i.AmountPaisa,
            _ => byId.TryGetValue(i.SourceId, out var t) ? t.AmountPaisa : 0
        };

        // history is newest-first; running balance is computed oldest-first.
        var result = new List<(TransactionItem, long, long)>(history.Count);
        long running = 0;
        for (var i = history.Count - 1; i >= 0; i--)
        {
            var signed = Signed(history[i]);
            running += signed;
            result.Add((history[i], signed, running));
        }
        result.Reverse();
        return result;
    }
}
