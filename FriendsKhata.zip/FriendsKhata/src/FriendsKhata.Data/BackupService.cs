using System.Globalization;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Services;
using SQLite;

namespace FriendsKhata.Data;

/// <summary>
/// Backup = consistent copy of the database file (VACUUM INTO).
/// Restore = validate the chosen file, make an automatic safety copy of the current data,
/// then replace the database file. Migrations run automatically when it is reopened,
/// so backups from older app versions are upgraded.
/// </summary>
public sealed class BackupService : IBackupService
{
    private static readonly byte[] SqliteHeader = "SQLite format 3\0"u8.ToArray();

    private readonly IDatabase _db;
    private readonly StoragePaths _paths;

    public BackupService(IDatabase db, StoragePaths paths)
    {
        _db = db;
        _paths = paths;
    }

    public async Task<string> CreateBackupFileAsync()
    {
        Directory.CreateDirectory(_paths.TempDirectory);
        var path = Path.Combine(_paths.TempDirectory, BackupFileName());
        await _db.BackupToAsync(path);
        return path;
    }

    public static string BackupFileName()
        => $"FriendsKhata-backup-{DateTime.Now.ToString("yyyy-MM-dd-HHmm", CultureInfo.InvariantCulture)}.db3";

    public Task<BackupInfo> InspectBackupAsync(string backupPath) => Task.Run(() => Inspect(backupPath));

    private static BackupInfo Inspect(string path)
    {
        try
        {
            if (!File.Exists(path)) return Invalid("The selected file could not be found.");
            var size = new FileInfo(path).Length;
            if (size < 512) return Invalid("The selected file is not a Friends Khata backup (file is too small).");

            var header = new byte[16];
            using (var fs = File.OpenRead(path))
            {
                if (fs.Read(header, 0, 16) != 16 || !header.SequenceEqual(SqliteHeader))
                    return Invalid("The selected file is not a Friends Khata backup (not a SQLite database).");
            }

            using var conn = new SQLiteConnection(new SQLiteConnectionString(path, SQLiteOpenFlags.ReadOnly, storeDateTimeAsTicks: false));
            var marker = conn.ExecuteScalar<string>(
                "SELECT Value FROM AppMeta WHERE Key = ?", Migrations.AppMarkerKey);
            if (marker != Migrations.AppMarkerValue)
                return Invalid("The selected database was not created by Friends Khata.");

            var version = conn.ExecuteScalar<long>("SELECT COALESCE(MAX(Version), 0) FROM SchemaVersion");
            if (version > Migrations.LatestVersion)
                return Invalid("This backup was made by a newer version of Friends Khata. Please update the app first.");

            var integrity = conn.ExecuteScalar<string>("PRAGMA integrity_check");
            if (!string.Equals(integrity, "ok", StringComparison.OrdinalIgnoreCase))
                return Invalid("The backup file is damaged and cannot be restored.");

            return new BackupInfo
            {
                IsValid = true,
                SchemaVersion = (int)version,
                GroupCount = conn.ExecuteScalar<int>("SELECT COUNT(*) FROM Groups"),
                ExpenseCount = conn.ExecuteScalar<int>("SELECT COUNT(*) FROM Expenses"),
                FileSizeBytes = size
            };
        }
        catch (Exception ex)
        {
            return Invalid("The selected file could not be read as a Friends Khata backup. " + ex.Message);
        }
    }

    private static BackupInfo Invalid(string message) => new() { IsValid = false, Error = message };

    public async Task RestoreAsync(string backupPath)
    {
        var info = await InspectBackupAsync(backupPath);
        if (!info.IsValid) throw new Core.Common.ValidationException(info.Error ?? "Invalid backup file.");

        // Work on a private copy so the picked file can't change underneath us.
        Directory.CreateDirectory(_paths.TempDirectory);
        var staged = Path.Combine(_paths.TempDirectory, "restore-staging.db3");
        File.Copy(backupPath, staged, overwrite: true);

        // 1) Safety copy of the current data.
        Directory.CreateDirectory(_paths.SafetyBackupDirectory);
        var safety = Path.Combine(_paths.SafetyBackupDirectory,
            $"before-restore-{DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture)}.db3");
        if (File.Exists(_paths.DatabasePath)) await _db.BackupToAsync(safety);

        // 2) Close and replace.
        await _db.CloseAsync();
        try
        {
            DeleteSidecars(_paths.DatabasePath);
            File.Copy(staged, _paths.DatabasePath, overwrite: true);
        }
        catch
        {
            if (File.Exists(safety)) File.Copy(safety, _paths.DatabasePath, overwrite: true);
            throw;
        }
        finally
        {
            File.Delete(staged);
        }

        // 3) Re-open now (runs migrations) so any problem surfaces immediately.
        await _db.ScalarAsync<long>("SELECT COUNT(*) FROM Groups");
        PruneSafetyBackups(keep: 5);
    }

    private static void DeleteSidecars(string dbPath)
    {
        foreach (var suffix in new[] { "-journal", "-wal", "-shm" })
            if (File.Exists(dbPath + suffix)) File.Delete(dbPath + suffix);
    }

    private void PruneSafetyBackups(int keep)
    {
        var files = new DirectoryInfo(_paths.SafetyBackupDirectory).GetFiles("before-restore-*.db3")
            .OrderByDescending(f => f.Name).Skip(keep);
        foreach (var f in files)
        {
            try { f.Delete(); } catch { /* best effort */ }
        }
    }
}
