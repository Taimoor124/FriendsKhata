using FriendsKhata.Core.Data;
using SQLite;

namespace FriendsKhata.Data;

/// <summary>
/// sqlite-net implementation of <see cref="IDatabase"/>.
/// The connection is opened lazily; on first open foreign keys are switched on and
/// pending migrations are applied inside a transaction.
/// </summary>
public sealed class SqliteDatabase : IDatabase
{
    private readonly SemaphoreSlim _openLock = new(1, 1);
    private SQLiteAsyncConnection? _connection;

    public SqliteDatabase(StoragePaths paths)
    {
        DatabasePath = paths.DatabasePath;
    }

    public string DatabasePath { get; }

    private async Task<SQLiteAsyncConnection> ConnectionAsync()
    {
        if (_connection is not null) return _connection;

        await _openLock.WaitAsync().ConfigureAwait(false);
        try
        {
            if (_connection is not null) return _connection;

            var folder = Path.GetDirectoryName(DatabasePath);
            if (!string.IsNullOrEmpty(folder)) Directory.CreateDirectory(folder);

            var conn = new SQLiteAsyncConnection(new SQLiteConnectionString(
                DatabasePath,
                SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.FullMutex,
                storeDateTimeAsTicks: false));

            // Must run outside a transaction, once per connection.
            await conn.ExecuteAsync("PRAGMA foreign_keys = ON").ConfigureAwait(false);
            await conn.RunInTransactionAsync(c => MigrationRunner.Migrate(new Session(c))).ConfigureAwait(false);

            _connection = conn;
            return conn;
        }
        finally
        {
            _openLock.Release();
        }
    }

    public async Task<List<T>> QueryAsync<T>(string sql, params object?[] args) where T : new()
        => await (await ConnectionAsync().ConfigureAwait(false)).QueryAsync<T>(sql, Args(args)).ConfigureAwait(false);

    public async Task<int> ExecuteAsync(string sql, params object?[] args)
        => await (await ConnectionAsync().ConfigureAwait(false)).ExecuteAsync(sql, Args(args)).ConfigureAwait(false);

    public async Task<T> ScalarAsync<T>(string sql, params object?[] args)
        => await (await ConnectionAsync().ConfigureAwait(false)).ExecuteScalarAsync<T>(sql, Args(args)).ConfigureAwait(false);

    public async Task RunInTransactionAsync(Action<IDbSession> work)
    {
        var conn = await ConnectionAsync().ConfigureAwait(false);
        await conn.RunInTransactionAsync(c => work(new Session(c))).ConfigureAwait(false);
    }

    public async Task BackupToAsync(string destinationPath)
    {
        if (File.Exists(destinationPath)) File.Delete(destinationPath);
        var conn = await ConnectionAsync().ConfigureAwait(false);
        // VACUUM INTO produces a consistent, compacted copy even while the app is running.
        await conn.ExecuteAsync("VACUUM INTO ?", destinationPath).ConfigureAwait(false);
    }

    public async Task CloseAsync()
    {
        await _openLock.WaitAsync().ConfigureAwait(false);
        try
        {
            if (_connection is null) return;
            await _connection.CloseAsync().ConfigureAwait(false);
            _connection = null;
        }
        finally
        {
            _openLock.Release();
        }
    }

    // sqlite-net's signature is object[]; nulls are bound as SQL NULL.
    private static object[] Args(object?[] args) => args!;

    private sealed class Session : IDbSession
    {
        private readonly SQLiteConnection _c;
        public Session(SQLiteConnection c) => _c = c;

        public List<T> Query<T>(string sql, params object?[] args) where T : new() => _c.Query<T>(sql, Args(args));

        public int Execute(string sql, params object?[] args) => _c.Execute(sql, Args(args));

        public T Scalar<T>(string sql, params object?[] args) => _c.ExecuteScalar<T>(sql, Args(args));
    }
}
