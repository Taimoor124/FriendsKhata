using FriendsKhata.App.Views;
using FriendsKhata.Presentation.Abstractions;

namespace FriendsKhata.App;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Pages that are pushed on top of a tab.
        Routing.RegisterRoute(Routes.ExpenseEditor, typeof(ExpenseEditorPage));
        Routing.RegisterRoute(Routes.ContributionEditor, typeof(ContributionEditorPage));
        Routing.RegisterRoute(Routes.FundEntryEditor, typeof(FundEntryEditorPage));
        Routing.RegisterRoute(Routes.FriendEditor, typeof(FriendEditorPage));
        Routing.RegisterRoute(Routes.FriendSummary, typeof(FriendSummaryPage));
        Routing.RegisterRoute(Routes.Settlements, typeof(SettlementsPage));
        Routing.RegisterRoute(Routes.SettlementEditor, typeof(SettlementEditorPage));
        Routing.RegisterRoute(Routes.Reports, typeof(ReportsPage));
        Routing.RegisterRoute(Routes.Transactions, typeof(TransactionHistoryPage));
        Routing.RegisterRoute(Routes.Groups, typeof(GroupsPage));
        Routing.RegisterRoute(Routes.Categories, typeof(CategoriesPage));
        Routing.RegisterRoute(Routes.Backup, typeof(BackupPage));
    }
}
