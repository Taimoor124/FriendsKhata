using CommunityToolkit.Maui;
using FriendsKhata.App.Services;
using FriendsKhata.App.Views;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Repositories;
using FriendsKhata.Core.Services;
using FriendsKhata.Data;
using FriendsKhata.Presentation;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.ViewModels;
using Microsoft.Extensions.Logging;

namespace FriendsKhata.App;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        var s = builder.Services;

        // ---- Storage: the database lives in the app's private, persistent data folder
        //      (not the cache, so "Clear cache" never deletes it).
        s.AddSingleton(StoragePaths.ForAppData(FileSystem.AppDataDirectory, FileSystem.CacheDirectory));
        s.AddSingleton<IDatabase, SqliteDatabase>();

        // ---- Repositories
        s.AddSingleton<GroupRepository>();
        s.AddSingleton<FriendRepository>();
        s.AddSingleton<CategoryRepository>();
        s.AddSingleton<ExpenseRepository>();
        s.AddSingleton<FundRepository>();
        s.AddSingleton<SettlementRepository>();
        s.AddSingleton<LedgerRepository>();

        // ---- Services
        s.AddSingleton<IGroupService, GroupService>();
        s.AddSingleton<IFriendService, FriendService>();
        s.AddSingleton<ICategoryService, CategoryService>();
        s.AddSingleton<IExpenseService, ExpenseService>();
        s.AddSingleton<IFundService, FundService>();
        s.AddSingleton<ISettlementService, SettlementService>();
        s.AddSingleton<IReportService, ReportService>();
        s.AddSingleton<IExportService, ExportService>();
        s.AddSingleton<IBackupService, BackupService>();

        // ---- Platform services
        s.AddSingleton<ISettingsStore, PreferencesSettingsStore>();
        s.AddSingleton<INavigationService, ShellNavigationService>();
        s.AddSingleton<IDialogService, DialogService>();
        s.AddSingleton<IFileExchangeService, FileExchangeService>();
        s.AddSingleton<AppState>();
        s.AddSingleton<CsvSaver>();

        // ---- Pages and ViewModels (transient: every navigation gets a fresh instance)
        s.AddTransient<DashboardPage>().AddTransient<DashboardViewModel>();
        s.AddTransient<ExpensesPage>().AddTransient<ExpensesViewModel>();
        s.AddTransient<ExpenseEditorPage>().AddTransient<ExpenseEditorViewModel>();
        s.AddTransient<FundPage>().AddTransient<FundViewModel>();
        s.AddTransient<ContributionEditorPage>().AddTransient<ContributionEditorViewModel>();
        s.AddTransient<FundEntryEditorPage>().AddTransient<FundEntryEditorViewModel>();
        s.AddTransient<FriendsPage>().AddTransient<FriendsViewModel>();
        s.AddTransient<FriendEditorPage>().AddTransient<FriendEditorViewModel>();
        s.AddTransient<FriendSummaryPage>().AddTransient<FriendSummaryViewModel>();
        s.AddTransient<SettlementsPage>().AddTransient<SettlementsViewModel>();
        s.AddTransient<SettlementEditorPage>().AddTransient<SettlementEditorViewModel>();
        s.AddTransient<ReportsPage>().AddTransient<ReportsViewModel>();
        s.AddTransient<TransactionHistoryPage>().AddTransient<TransactionHistoryViewModel>();
        s.AddTransient<GroupsPage>().AddTransient<GroupsViewModel>();
        s.AddTransient<CategoriesPage>().AddTransient<CategoriesViewModel>();
        s.AddTransient<BackupPage>().AddTransient<BackupViewModel>();
        s.AddTransient<MorePage>().AddTransient<MoreViewModel>();

        s.AddSingleton<AppShell>();

        return builder.Build();
    }
}
