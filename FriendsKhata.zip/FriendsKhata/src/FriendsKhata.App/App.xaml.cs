namespace FriendsKhata.App;

public partial class App : Application
{
    public App(AppShell shell)
    {
        InitializeComponent();

        // The design uses a light palette; keep it consistent even when the phone is in dark mode.
        UserAppTheme = AppTheme.Light;

        MainPage = shell;
    }
}
