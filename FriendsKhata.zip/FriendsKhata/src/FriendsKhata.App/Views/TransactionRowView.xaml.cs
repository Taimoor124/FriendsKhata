namespace FriendsKhata.App.Views;

public partial class TransactionRowView : ContentView
{
    public TransactionRowView()
    {
        InitializeComponent();
    }
}
