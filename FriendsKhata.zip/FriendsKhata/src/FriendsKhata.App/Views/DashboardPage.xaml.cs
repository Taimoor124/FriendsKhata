using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class DashboardPage : BasePage
{
    public DashboardPage(DashboardViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
