using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class GroupsPage : BasePage
{
    public GroupsPage(GroupsViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
