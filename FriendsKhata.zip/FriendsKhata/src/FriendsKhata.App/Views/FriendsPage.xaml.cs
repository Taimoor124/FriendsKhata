using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class FriendsPage : BasePage
{
    public FriendsPage(FriendsViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
