using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class CategoriesPage : BasePage
{
    public CategoriesPage(CategoriesViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
