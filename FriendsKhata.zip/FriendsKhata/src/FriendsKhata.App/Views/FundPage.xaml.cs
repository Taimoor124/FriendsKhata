using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class FundPage : BasePage
{
    public FundPage(FundViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
