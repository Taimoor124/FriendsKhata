using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class FriendEditorPage : BasePage
{
    public FriendEditorPage(FriendEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
