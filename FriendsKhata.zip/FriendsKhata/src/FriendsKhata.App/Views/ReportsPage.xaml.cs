using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class ReportsPage : BasePage
{
    public ReportsPage(ReportsViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
