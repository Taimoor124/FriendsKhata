using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class FundEntryEditorPage : BasePage
{
    public FundEntryEditorPage(FundEntryEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
