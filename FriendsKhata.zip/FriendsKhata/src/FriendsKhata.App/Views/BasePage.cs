using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

/// <summary>
/// Base page: forwards Shell navigation parameters to the ViewModel and
/// calls <see cref="BaseViewModel.OnAppearingAsync"/> each time the page appears,
/// so every screen always shows freshly calculated balances.
/// </summary>
public class BasePage : ContentPage, IQueryAttributable
{
    protected BaseViewModel? ViewModel => BindingContext as BaseViewModel;

    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        ViewModel?.ApplyParameters(query);
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (ViewModel is { } vm)
            await vm.OnAppearingAsync();
    }
}
