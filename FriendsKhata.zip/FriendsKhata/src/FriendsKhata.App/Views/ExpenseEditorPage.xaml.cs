using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class ExpenseEditorPage : BasePage
{
    public ExpenseEditorPage(ExpenseEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
