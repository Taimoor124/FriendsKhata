using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class BackupPage : BasePage
{
    public BackupPage(BackupViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
