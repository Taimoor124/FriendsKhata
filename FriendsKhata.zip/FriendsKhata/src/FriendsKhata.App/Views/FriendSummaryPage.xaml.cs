using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class FriendSummaryPage : BasePage
{
    public FriendSummaryPage(FriendSummaryViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
