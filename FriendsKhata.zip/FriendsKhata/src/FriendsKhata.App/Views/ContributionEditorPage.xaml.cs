using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class ContributionEditorPage : BasePage
{
    public ContributionEditorPage(ContributionEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
