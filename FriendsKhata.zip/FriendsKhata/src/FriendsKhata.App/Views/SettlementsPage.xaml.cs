using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class SettlementsPage : BasePage
{
    public SettlementsPage(SettlementsViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
