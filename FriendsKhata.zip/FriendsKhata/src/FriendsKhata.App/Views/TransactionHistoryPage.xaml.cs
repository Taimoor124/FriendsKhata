using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class TransactionHistoryPage : BasePage
{
    public TransactionHistoryPage(TransactionHistoryViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
