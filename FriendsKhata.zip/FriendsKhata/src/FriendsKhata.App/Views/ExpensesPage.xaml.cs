using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class ExpensesPage : BasePage
{
    public ExpensesPage(ExpensesViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
