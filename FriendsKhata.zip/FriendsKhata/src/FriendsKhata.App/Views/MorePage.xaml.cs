using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class MorePage : BasePage
{
    public MorePage(MoreViewModel viewModel)
    {
        InitializeComponent();
        viewModel.Version = $"Version {AppInfo.Current.VersionString} (build {AppInfo.Current.BuildString})";
        BindingContext = viewModel;
    }
}
