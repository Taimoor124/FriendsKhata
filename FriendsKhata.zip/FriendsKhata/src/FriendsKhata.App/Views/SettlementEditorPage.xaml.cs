using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.App.Views;

public partial class SettlementEditorPage : BasePage
{
    public SettlementEditorPage(SettlementEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
