using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Storage;
using FriendsKhata.Core.Data;
using FriendsKhata.Presentation.Abstractions;

namespace FriendsKhata.App.Services;

public sealed class PreferencesSettingsStore : ISettingsStore
{
    public string? Get(string key)
    {
        var value = Preferences.Default.Get<string?>(key, null);
        return string.IsNullOrEmpty(value) ? null : value;
    }

    public void Set(string key, string? value)
    {
        if (value is null) Preferences.Default.Remove(key);
        else Preferences.Default.Set(key, value);
    }
}

public sealed class ShellNavigationService : INavigationService
{
    public Task GoToAsync(string route, IDictionary<string, object>? parameters = null)
        => MainThread.InvokeOnMainThreadAsync(() => parameters is null
            ? Shell.Current.GoToAsync(route)
            : Shell.Current.GoToAsync(route, parameters));

    public Task GoBackAsync() => MainThread.InvokeOnMainThreadAsync(() => Shell.Current.GoToAsync(".."));
}

public sealed class DialogService : IDialogService
{
    private static Page Page => Shell.Current?.CurrentPage ?? Application.Current!.MainPage!;

    public Task AlertAsync(string title, string message, string ok = "OK")
        => MainThread.InvokeOnMainThreadAsync(() => Page.DisplayAlert(title, message, ok));

    public Task<bool> ConfirmAsync(string title, string message, string accept = "Yes", string cancel = "Cancel")
        => MainThread.InvokeOnMainThreadAsync(() => Page.DisplayAlert(title, message, accept, cancel));

    public Task<string?> PromptAsync(string title, string message, string? initialValue = null, string accept = "Save",
        int maxLength = 50, string? placeholder = null)
        => MainThread.InvokeOnMainThreadAsync(async () =>
        {
            string? result = await Page.DisplayPromptAsync(title, message, accept, "Cancel", placeholder, maxLength,
                Keyboard.Text, initialValue ?? "");
            return result;
        });

    public Task<string?> ChooseAsync(string title, params string[] options)
        => MainThread.InvokeOnMainThreadAsync(async () =>
        {
            string? choice = await Page.DisplayActionSheet(title, "Cancel", null, options);
            return choice is null || choice == "Cancel" ? null : choice;
        });

    public Task ToastAsync(string message)
        => MainThread.InvokeOnMainThreadAsync(() => Toast.Make(message, ToastDuration.Short).Show());
}

public sealed class FileExchangeService : IFileExchangeService
{
    private readonly StoragePaths _paths;

    public FileExchangeService(StoragePaths paths) => _paths = paths;

    public async Task<string?> SaveAsync(string suggestedFileName, string sourceFilePath)
    {
        await using var stream = File.OpenRead(sourceFilePath);
        var result = await FileSaver.Default.SaveAsync(suggestedFileName, stream, CancellationToken.None);
        if (result.IsSuccessful) return result.FilePath;

        // The user pressed back/cancel in the system dialog: not an error.
        if (result.Exception is null || result.Exception is OperationCanceledException ||
            result.Exception.Message.Contains("cancel", StringComparison.OrdinalIgnoreCase))
            return null;

        throw new InvalidOperationException("The file could not be saved: " + result.Exception.Message, result.Exception);
    }

    public async Task<string?> PickFileAsync(string title)
    {
        var picked = await MainThread.InvokeOnMainThreadAsync(() => FilePicker.Default.PickAsync(new PickOptions { PickerTitle = title }));
        if (picked is null) return null;

        // Copy to our own temp file: content:// URIs on Android are not always readable by path.
        Directory.CreateDirectory(_paths.TempDirectory);
        var local = Path.Combine(_paths.TempDirectory, "picked-" + Guid.NewGuid().ToString("N") + ".db3");
        await using (var source = await picked.OpenReadAsync())
        await using (var target = File.Create(local))
        {
            await source.CopyToAsync(target);
        }
        return local;
    }
}
