using System.Globalization;
using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Services;

namespace FriendsKhata.Presentation.Items;

// Display-ready rows for CollectionViews. Each row carries the command that should run when it is
// tapped, so XAML item templates never need to reach up to the page's ViewModel.

/// <summary>Option for Pickers (Picker shows ToString()).</summary>
public sealed record PickerOption(string Id, string Name)
{
    public override string ToString() => Name;
}

public enum AmountTone { Neutral, Positive, Negative, Info }

public static class Text
{
    public static string Initials(string name)
    {
        var parts = name.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0) return "?";
        if (parts.Length == 1) return parts[0][..Math.Min(2, parts[0].Length)].ToUpperInvariant();
        return (parts[0][..1] + parts[^1][..1]).ToUpperInvariant();
    }

    public static string Date(DateTime d) => d.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
    public static string ShortDate(DateTime d) => d.ToString("dd MMM", CultureInfo.InvariantCulture);
}

public sealed class BalanceRow
{
    public BalanceRow(FriendBalance b, ICommand? tap = null)
    {
        FriendId = b.FriendId;
        Name = b.Name;
        Initials = Text.Initials(b.Name);
        NetPaisa = b.NetPaisa;
        AmountText = Money.Format(Math.Abs(b.NetPaisa));
        StatusText = b.NetPaisa > 0 ? "gets back" : b.NetPaisa < 0 ? "owes" : "settled up";
        Detail = $"Paid {Money.Format(b.PaidPersonalPaisa)} • Share {Money.Format(b.SharePersonalPaisa)}";
        TapCommand = tap;
    }

    public string FriendId { get; }
    public string Name { get; }
    public string Initials { get; }
    public long NetPaisa { get; }
    public string AmountText { get; }
    public string StatusText { get; }
    public string Detail { get; }
    public bool IsPositive => NetPaisa > 0;
    public bool IsNegative => NetPaisa < 0;
    public bool IsSettled => NetPaisa == 0;
    public ICommand? TapCommand { get; }
}

public sealed class TransactionRow
{
    public TransactionRow(TransactionItem t, ICommand? tap = null)
    {
        Item = t;
        Icon = t.Icon;
        Title = t.Title;
        Subtitle = $"{t.KindText} • {t.RelatedFriend}";
        DateText = Text.Date(t.Date);
        Description = t.Description ?? "";
        HasDescription = !string.IsNullOrWhiteSpace(t.Description);
        Source = t.PaymentSource;
        IsInflow = t.Kind == TransactionKind.Contribution ||
                   (t.Kind == TransactionKind.FundAdjustment && t.PaymentSource.StartsWith("Into", StringComparison.Ordinal));
        IsSettlement = t.Kind == TransactionKind.Settlement;
        IsOutflow = !IsInflow && !IsSettlement;
        AmountText = (IsInflow ? "+ " : IsOutflow ? "− " : "") + Money.Format(t.AmountPaisa);
        TapCommand = tap;
    }

    public TransactionItem Item { get; }
    public string Icon { get; }
    public string Title { get; }
    public string Subtitle { get; }
    public string DateText { get; }
    public string Description { get; }
    public bool HasDescription { get; }
    public string Source { get; }
    public string AmountText { get; }
    public bool IsInflow { get; }
    public bool IsOutflow { get; }
    public bool IsSettlement { get; }
    public ICommand? TapCommand { get; }
}

public sealed class LedgerRow
{
    public LedgerRow(TransactionItem t, long signed, long balanceAfter, ICommand? tap)
    {
        Item = t;
        Icon = t.Icon;
        Title = t.Title;
        Subtitle = $"{Text.Date(t.Date)} • {t.RelatedFriend}";
        IsInflow = signed > 0;
        AmountText = (signed > 0 ? "+ " : "− ") + Money.Format(Math.Abs(signed));
        BalanceText = "Balance " + Money.Format(balanceAfter);
        TapCommand = tap;
    }

    public TransactionItem Item { get; }
    public string Icon { get; }
    public string Title { get; }
    public string Subtitle { get; }
    public string AmountText { get; }
    public string BalanceText { get; }
    public bool IsInflow { get; }
    public bool IsOutflow => !IsInflow;
    public ICommand? TapCommand { get; }
}

public sealed class ExpenseRow
{
    public ExpenseRow(ExpenseListItem i, ICommand? tap)
    {
        Id = i.Expense.Id;
        Icon = i.CategoryIcon;
        Title = i.Expense.Title;
        Subtitle = $"{i.CategoryName} • {(i.Expense.IsFundExpense ? "Group Fund" : "Paid by " + i.PaidByName)}";
        DateText = Text.Date(i.Expense.Date);
        AmountText = Money.Format(i.Expense.AmountPaisa);
        ShareText = $"{i.ParticipantCount} {(i.ParticipantCount == 1 ? "person" : "people")} • {SplitName(i.Expense.Split)}";
        IsFund = i.Expense.IsFundExpense;
        SourceText = IsFund ? "FUND" : "PERSONAL";
        AmountPaisa = i.Expense.AmountPaisa;
        TapCommand = tap;
    }

    public static string SplitName(SplitMethod m) => m switch
    {
        SplitMethod.CustomAmount => "custom amounts",
        SplitMethod.Percentage => "by percentage",
        _ => "split equally"
    };

    public string Id { get; }
    public string Icon { get; }
    public string Title { get; }
    public string Subtitle { get; }
    public string DateText { get; }
    public string AmountText { get; }
    public string ShareText { get; }
    public string SourceText { get; }
    public bool IsFund { get; }
    public bool IsPersonal => !IsFund;
    public long AmountPaisa { get; }
    public ICommand? TapCommand { get; }
}

public sealed class MemberRow
{
    public MemberRow(Member m, long netPaisa, ICommand? tap)
    {
        FriendId = m.FriendId;
        Name = m.Name;
        Initials = Text.Initials(m.Name);
        Phone = string.IsNullOrWhiteSpace(m.Phone) ? "No phone" : m.Phone!;
        Details = $"ID {m.FriendCode} • Joined {Text.Date(m.Joined)}";
        IsActive = m.IsActive;
        StatusText = m.IsActive ? "Active" : "Inactive";
        NetPaisa = netPaisa;
        BalanceText = netPaisa == 0 ? "Settled" : (netPaisa > 0 ? "Gets back " : "Owes ") + Money.Format(Math.Abs(netPaisa));
        TapCommand = tap;
    }

    public string FriendId { get; }
    public string Name { get; }
    public string Initials { get; }
    public string Phone { get; }
    public string Details { get; }
    public bool IsActive { get; }
    public bool IsInactive => !IsActive;
    public string StatusText { get; }
    public long NetPaisa { get; }
    public string BalanceText { get; }
    public bool IsPositive => NetPaisa > 0;
    public bool IsNegative => NetPaisa < 0;
    public bool IsSettled => NetPaisa == 0;
    public ICommand? TapCommand { get; }
}

public sealed class CategoryShareRow
{
    public CategoryShareRow(CategoryRow c)
    {
        Icon = c.Icon;
        Name = c.Name;
        AmountText = Money.Format(c.AmountPaisa);
        Fraction = c.Fraction;
        PercentText = (c.Fraction * 100).ToString("0", CultureInfo.InvariantCulture) + "%";
        CountText = $"{c.Count} expense{(c.Count == 1 ? "" : "s")}";
    }

    public string Icon { get; }
    public string Name { get; }
    public string AmountText { get; }
    public double Fraction { get; }
    public string PercentText { get; }
    public string CountText { get; }
}

public sealed class SuggestionRow
{
    public SuggestionRow(SettlementSuggestion s, ICommand? record)
    {
        Suggestion = s;
        Text = $"{s.FromName} pays {s.ToName}";
        AmountText = Money.Format(s.AmountPaisa);
        RecordCommand = record;
    }

    public SettlementSuggestion Suggestion { get; }
    public string Text { get; }
    public string AmountText { get; }
    public ICommand? RecordCommand { get; }
}

public sealed class FundPositionRow
{
    public FundPositionRow(FriendFundPosition p, ICommand? tap)
    {
        FriendId = p.FriendId;
        Name = p.Name;
        Initials = Items.Text.Initials(p.Name);
        ContributedText = Money.Format(p.ContributedPaisa);
        UsedText = Money.Format(p.FundShareConsumedPaisa);
        RefundText = p.RefundedPaisa == 0 ? "" : "Refunded " + Money.Format(p.RefundedPaisa);
        EquityText = Money.Format(p.EquityPaisa);
        IsNegative = p.EquityPaisa < 0;
        TapCommand = tap;
    }

    public string FriendId { get; }
    public string Name { get; }
    public string Initials { get; }
    public string ContributedText { get; }
    public string UsedText { get; }
    public string RefundText { get; }
    public string EquityText { get; }
    public bool IsNegative { get; }
    public bool IsPositive => !IsNegative;
    public ICommand? TapCommand { get; }
}

public sealed class ReportFriendRow
{
    public ReportFriendRow(FriendPeriodRow r)
    {
        Name = r.Name;
        Initials = Items.Text.Initials(r.Name);
        PaidText = Money.Format(r.PaidPersonalPaisa);
        ShareText = Money.Format(r.TotalSharePaisa);
        ShareDetail = $"Personal {Money.Format(r.PersonalSharePaisa)} • Fund {Money.Format(r.FundSharePaisa)}";
        ContributedText = Money.Format(r.ContributedPaisa);
        SettlementText = $"Paid {Money.Format(r.SettlementsPaidPaisa)} • Received {Money.Format(r.SettlementsReceivedPaisa)}";
        BalanceText = r.OutstandingAtEndPaisa == 0 ? "Settled"
            : (r.OutstandingAtEndPaisa > 0 ? "Gets back " : "Owes ") + Money.Format(Math.Abs(r.OutstandingAtEndPaisa));
        IsPositive = r.OutstandingAtEndPaisa > 0;
        IsNegative = r.OutstandingAtEndPaisa < 0;
    }

    public string Name { get; }
    public string Initials { get; }
    public string PaidText { get; }
    public string ShareText { get; }
    public string ShareDetail { get; }
    public string ContributedText { get; }
    public string SettlementText { get; }
    public string BalanceText { get; }
    public bool IsPositive { get; }
    public bool IsNegative { get; }
}

public sealed class GroupRow
{
    public GroupRow(FriendGroup g, bool isCurrent, ICommand open, ICommand rename, ICommand delete)
    {
        Id = g.Id;
        Name = g.Name;
        Description = string.IsNullOrWhiteSpace(g.Description) ? "No description" : g.Description!;
        IsCurrent = isCurrent;
        Initials = Text.Initials(g.Name);
        OpenCommand = open;
        RenameCommand = rename;
        DeleteCommand = delete;
    }

    public string Id { get; }
    public string Name { get; }
    public string Description { get; }
    public string Initials { get; }
    public bool IsCurrent { get; }
    public ICommand OpenCommand { get; }
    public ICommand RenameCommand { get; }
    public ICommand DeleteCommand { get; }
}

public sealed class CategoryItemRow
{
    public CategoryItemRow(Category c, ICommand edit, ICommand delete)
    {
        Id = c.Id;
        Icon = c.Icon;
        Name = c.Name;
        IsSystem = c.IsSystem == 1;
        KindText = IsSystem ? "Built-in" : "Custom";
        EditCommand = edit;
        DeleteCommand = delete;
    }

    public string Id { get; }
    public string Icon { get; }
    public string Name { get; }
    public bool IsSystem { get; }
    public bool IsCustom => !IsSystem;
    public string KindText { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }
}

/// <summary>Editable participant row on the expense screen.</summary>
public sealed class ParticipantRow : ObservableObject
{
    public ParticipantRow(string friendId, string name, bool isActive)
    {
        FriendId = friendId;
        Name = name;
        Initials = Text.Initials(name);
        IsActive = isActive;
    }

    public string FriendId { get; }
    public string Name { get; }
    public string Initials { get; }
    public bool IsActive { get; }

    private bool _isSelected;
    public bool IsSelected { get => _isSelected; set => SetProperty(ref _isSelected, value); }

    private string _amountText = "";
    public string AmountText { get => _amountText; set => SetProperty(ref _amountText, value); }

    private string _percentText = "";
    public string PercentText { get => _percentText; set => SetProperty(ref _percentText, value); }

    private string _shareText = "";
    /// <summary>Calculated share preview, e.g. "Rs. 600".</summary>
    public string ShareText { get => _shareText; set => SetProperty(ref _shareText, value); }

    private bool _showAmount;
    public bool ShowAmount { get => _showAmount; set => SetProperty(ref _showAmount, value); }

    private bool _showPercent;
    public bool ShowPercent { get => _showPercent; set => SetProperty(ref _showPercent, value); }
}
