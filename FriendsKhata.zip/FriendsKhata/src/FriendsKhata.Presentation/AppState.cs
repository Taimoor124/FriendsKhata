using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;

namespace FriendsKhata.Presentation;

/// <summary>Remembers which group is currently open (persisted between app launches).</summary>
public sealed class AppState
{
    private const string CurrentGroupKey = "current_group_id";
    private readonly ISettingsStore _store;
    private readonly IGroupService _groups;

    public AppState(ISettingsStore store, IGroupService groups)
    {
        _store = store;
        _groups = groups;
    }

    public string? CurrentGroupId
    {
        get => _store.Get(CurrentGroupKey);
        set => _store.Set(CurrentGroupKey, value);
    }

    public string CurrentGroupName { get; private set; } = "";

    /// <summary>
    /// Makes sure the current group still exists. Falls back to the first group, or null when there are none.
    /// </summary>
    public async Task<string?> EnsureGroupAsync()
    {
        var groups = await _groups.GetGroupsAsync();
        var current = groups.FirstOrDefault(g => g.Id == CurrentGroupId) ?? groups.FirstOrDefault();
        CurrentGroupId = current?.Id;
        CurrentGroupName = current?.Name ?? "";
        return current?.Id;
    }
}
