namespace FriendsKhata.Presentation.Abstractions;

public interface INavigationService
{
    /// <summary>Navigate to a registered route (e.g. Routes.ExpenseEditor) or a tab ("//friends").</summary>
    Task GoToAsync(string route, IDictionary<string, object>? parameters = null);
    Task GoBackAsync();
}

public interface IDialogService
{
    Task AlertAsync(string title, string message, string ok = "OK");
    Task<bool> ConfirmAsync(string title, string message, string accept = "Yes", string cancel = "Cancel");
    Task<string?> PromptAsync(string title, string message, string? initialValue = null, string accept = "Save", int maxLength = 50, string? placeholder = null);
    /// <summary>Returns the chosen button text, or null when cancelled.</summary>
    Task<string?> ChooseAsync(string title, params string[] options);
    Task ToastAsync(string message);
}

/// <summary>Lets the user save a file to a location of their choice, or pick an existing file.</summary>
public interface IFileExchangeService
{
    /// <summary>Shows the system "save as" dialog. Returns the saved location, or null when cancelled.</summary>
    Task<string?> SaveAsync(string suggestedFileName, string sourceFilePath);
    /// <summary>Shows the system file picker. Returns a local, readable copy of the picked file, or null.</summary>
    Task<string?> PickFileAsync(string title);
}

/// <summary>Simple persistent key/value storage (MAUI Preferences in the app).</summary>
public interface ISettingsStore
{
    string? Get(string key);
    void Set(string key, string? value);
}

public static class Routes
{
    // Tabs
    public const string DashboardTab = "//dashboard";
    public const string ExpensesTab = "//expenses";
    public const string FundTab = "//fund";
    public const string FriendsTab = "//friends";
    public const string MoreTab = "//more";

    // Pushed pages
    public const string ExpenseEditor = "expenseeditor";
    public const string ContributionEditor = "contributioneditor";
    public const string FundEntryEditor = "fundentryeditor";
    public const string FriendEditor = "friendeditor";
    public const string FriendSummary = "friendsummary";
    public const string Settlements = "settlements";
    public const string SettlementEditor = "settlementeditor";
    public const string Reports = "reports";
    public const string Transactions = "transactions";
    public const string Groups = "groups";
    public const string Categories = "categories";
    public const string Backup = "backup";
}

public static class NavKeys
{
    public const string Id = "id";
    public const string FriendId = "friendId";
    public const string FromId = "fromId";
    public const string ToId = "toId";
    public const string Amount = "amount";
    public const string Type = "type";
}
