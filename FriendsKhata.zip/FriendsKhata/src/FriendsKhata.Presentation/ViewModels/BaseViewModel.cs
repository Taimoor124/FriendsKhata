using System.Globalization;
using CommunityToolkit.Mvvm.ComponentModel;
using FriendsKhata.Core.Common;
using FriendsKhata.Presentation.Abstractions;

namespace FriendsKhata.Presentation.ViewModels;

public abstract class BaseViewModel : ObservableObject
{
    protected BaseViewModel(IDialogService dialogs) => Dialogs = dialogs;

    protected IDialogService Dialogs { get; }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value)) OnPropertyChanged(nameof(IsNotBusy));
        }
    }

    public bool IsNotBusy => !IsBusy;

    private string _title = "";
    public string Title { get => _title; set => SetProperty(ref _title, value); }

    /// <summary>Called by the page every time it appears.</summary>
    public virtual Task OnAppearingAsync() => Task.CompletedTask;

    /// <summary>Navigation parameters (called before the page appears).</summary>
    public virtual void ApplyParameters(IDictionary<string, object> parameters) { }

    /// <summary>
    /// Runs an action with a busy indicator and user-friendly error handling.
    /// Business rule violations show their message; unexpected errors show a generic one.
    /// </summary>
    protected async Task<bool> RunAsync(Func<Task> action, bool showBusy = true)
    {
        try
        {
            if (showBusy) IsBusy = true;
            await action();
            return true;
        }
        catch (ValidationException ex)
        {
            await Dialogs.AlertAsync("Please check", ex.Message);
        }
        catch (Exception ex)
        {
            await Dialogs.AlertAsync("Something went wrong", ex.Message);
        }
        finally
        {
            if (showBusy) IsBusy = false;
        }
        return false;
    }

    protected static string? Param(IDictionary<string, object> parameters, string key)
        => parameters.TryGetValue(key, out var value) ? Convert.ToString(value, CultureInfo.InvariantCulture) : null;
}

/// <summary>Base for screens that show data of the current group.</summary>
public abstract class GroupViewModel : BaseViewModel
{
    protected GroupViewModel(AppState state, INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        State = state;
        Navigation = navigation;
    }

    protected AppState State { get; }
    protected INavigationService Navigation { get; }

    private string? _groupId;
    public string? GroupId
    {
        get => _groupId;
        private set
        {
            if (SetProperty(ref _groupId, value))
            {
                OnPropertyChanged(nameof(HasGroup));
                OnPropertyChanged(nameof(HasNoGroup));
            }
        }
    }

    public bool HasGroup => GroupId is not null;
    public bool HasNoGroup => GroupId is null;

    private string _groupName = "";
    public string GroupName { get => _groupName; private set => SetProperty(ref _groupName, value); }

    public override async Task OnAppearingAsync()
    {
        await RunAsync(async () =>
        {
            GroupId = await State.EnsureGroupAsync();
            GroupName = State.CurrentGroupName;
            if (GroupId is not null) await LoadAsync(GroupId);
            else ClearData();
        });
    }

    protected abstract Task LoadAsync(string groupId);

    protected virtual void ClearData() { }

    /// <summary>Use when a group is required for an action (e.g. "Add expense").</summary>
    protected async Task<string?> RequireGroupAsync()
    {
        if (GroupId is not null) return GroupId;
        await Dialogs.AlertAsync("No group yet", "Create a group first from More → Groups.");
        return null;
    }
}
