using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

public sealed class FriendsViewModel : GroupViewModel
{
    private readonly IFriendService _friends;
    private readonly ISettlementService _settlements;
    private List<MemberRow> _all = new();

    public FriendsViewModel(IFriendService friends, ISettlementService settlements, AppState state, INavigationService navigation, IDialogService dialogs)
        : base(state, navigation, dialogs)
    {
        _friends = friends;
        _settlements = settlements;
        Title = "Friends";
        AddCommand = new AsyncRelayCommand(async () =>
        {
            if (await RequireGroupAsync() is null) return;
            await Navigation.GoToAsync(Routes.FriendEditor);
        });
        OpenCommand = new AsyncRelayCommand<MemberRow>(r => r is null ? Task.CompletedTask
            : Navigation.GoToAsync(Routes.FriendSummary, new Dictionary<string, object> { [NavKeys.FriendId] = r.FriendId }));
        SettlementsCommand = new AsyncRelayCommand(async () =>
        {
            if (await RequireGroupAsync() is null) return;
            await Navigation.GoToAsync(Routes.Settlements);
        });
    }

    public IAsyncRelayCommand AddCommand { get; }
    public IAsyncRelayCommand<MemberRow> OpenCommand { get; }
    public IAsyncRelayCommand SettlementsCommand { get; }
    public ObservableCollection<MemberRow> Members { get; } = new();

    private string _search = "", _summary = "", _emptyText = "";
    public string Search { get => _search; set { if (SetProperty(ref _search, value)) ApplyFilter(); } }
    public string Summary { get => _summary; set => SetProperty(ref _summary, value); }
    public string EmptyText { get => _emptyText; set => SetProperty(ref _emptyText, value); }

    private bool _showInactive = true, _isEmpty;
    public bool ShowInactive { get => _showInactive; set { if (SetProperty(ref _showInactive, value)) ApplyFilter(); } }
    public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

    protected override async Task LoadAsync(string groupId)
    {
        var members = await _friends.GetMembersAsync(groupId);
        var balances = (await _settlements.GetBalancesAsync(groupId)).ToDictionary(b => b.FriendId, b => b.NetPaisa);
        _all = members.Select(m => new MemberRow(m, balances.GetValueOrDefault(m.FriendId), OpenCommand)).ToList();
        var active = members.Count(m => m.IsActive);
        Summary = $"{members.Count} friend{(members.Count == 1 ? "" : "s")} • {active} active";
        ApplyFilter();
    }

    protected override void ClearData()
    {
        _all.Clear();
        Members.Clear();
        Summary = "";
        IsEmpty = true;
        EmptyText = "Create a group first, then add your friends here.";
    }

    private void ApplyFilter()
    {
        var term = Search.Trim();
        var rows = _all.Where(r => (ShowInactive || r.IsActive) &&
                                   (term.Length == 0 || r.Name.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                                    r.Phone.Contains(term, StringComparison.OrdinalIgnoreCase)));
        DashboardViewModel.Replace(Members, rows);
        IsEmpty = Members.Count == 0;
        EmptyText = _all.Count == 0 ? "No friends in this group yet. Tap + to add the first friend." : "No friends match your search.";
    }
}

public sealed class FriendEditorViewModel : BaseViewModel
{
    private readonly IFriendService _friends;
    private readonly AppState _state;
    private readonly INavigationService _navigation;
    private string? _friendId, _groupId;
    private bool _loaded;

    public FriendEditorViewModel(IFriendService friends, AppState state, INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        _friends = friends;
        _state = state;
        _navigation = navigation;
        Title = "Add Friend";
        SaveCommand = new AsyncRelayCommand(SaveAsync);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync);
        AddExistingCommand = new AsyncRelayCommand(AddExistingAsync);
    }

    public IAsyncRelayCommand SaveCommand { get; }
    public IAsyncRelayCommand DeleteCommand { get; }
    public IAsyncRelayCommand AddExistingCommand { get; }
    public ObservableCollection<PickerOption> ExistingFriends { get; } = new();

    private string _name = "", _phone = "", _friendCode = "";
    public string Name { get => _name; set => SetProperty(ref _name, value); }
    public string Phone { get => _phone; set => SetProperty(ref _phone, value); }
    public string FriendCode { get => _friendCode; set => SetProperty(ref _friendCode, value); }

    private DateTime _joiningDate = DateTime.Today;
    public DateTime JoiningDate { get => _joiningDate; set => SetProperty(ref _joiningDate, value); }
    public DateTime MaxDate => DateTime.Today;

    private bool _isActive = true, _isEditing, _hasExisting;
    public bool IsActive { get => _isActive; set => SetProperty(ref _isActive, value); }
    public bool IsEditing
    {
        get => _isEditing;
        set { if (SetProperty(ref _isEditing, value)) OnPropertyChanged(nameof(IsNew)); }
    }
    public bool IsNew => !IsEditing;
    public bool HasExisting { get => _hasExisting; set => SetProperty(ref _hasExisting, value); }

    private PickerOption? _selectedExisting;
    public PickerOption? SelectedExisting { get => _selectedExisting; set => SetProperty(ref _selectedExisting, value); }

    public override void ApplyParameters(IDictionary<string, object> parameters) => _friendId = Param(parameters, NavKeys.FriendId);

    public override async Task OnAppearingAsync()
    {
        if (_loaded) return;
        await RunAsync(async () =>
        {
            _groupId = await _state.EnsureGroupAsync() ?? throw new ValidationException("Create a group first.");
            if (_friendId is not null)
            {
                var m = await _friends.GetMemberAsync(_groupId, _friendId) ?? throw new ValidationException("This friend is not in the group.");
                Name = m.Name;
                Phone = m.Phone ?? "";
                JoiningDate = m.Joined;
                IsActive = m.IsActive;
                FriendCode = "Friend ID: " + m.FriendCode;
                IsEditing = true;
                Title = "Edit Friend";
            }
            else
            {
                foreach (var f in await _friends.GetFriendsNotInGroupAsync(_groupId))
                    ExistingFriends.Add(new PickerOption(f.Id, f.Name + (string.IsNullOrWhiteSpace(f.Phone) ? "" : $" ({f.Phone})")));
                HasExisting = ExistingFriends.Count > 0;
            }
            _loaded = true;
        });
    }

    private async Task SaveAsync()
    {
        if (_groupId is null) return;
        if (IsEditing && !IsActive && !await Dialogs.ConfirmAsync("Mark as inactive?",
                $"{Name} will stay in all past records and balances but cannot be added to new expenses.", "Mark inactive", "Cancel"))
            return;

        var draft = new FriendDraft { GroupId = _groupId, FriendId = _friendId, Name = Name, Phone = Phone, JoiningDate = JoiningDate, IsActive = IsActive };
        if (await RunAsync(() => _friends.SaveAsync(draft)))
        {
            await Dialogs.ToastAsync(IsEditing ? "Friend updated" : $"{Name.Trim()} added to the group");
            await _navigation.GoBackAsync();
        }
    }

    private async Task AddExistingAsync()
    {
        if (_groupId is null) return;
        if (SelectedExisting is null) { await Dialogs.AlertAsync("Please check", "Select a friend from your other groups."); return; }
        if (await RunAsync(() => _friends.AddExistingFriendAsync(_groupId, SelectedExisting.Id, JoiningDate)))
        {
            await Dialogs.ToastAsync("Friend added to the group");
            await _navigation.GoBackAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (_groupId is null || _friendId is null) return;
        var hasRecords = false;
        if (!await RunAsync(async () => hasRecords = await _friends.HasFinancialRecordsAsync(_groupId, _friendId), showBusy: false)) return;

        if (hasRecords)
        {
            if (await Dialogs.ConfirmAsync("Cannot delete",
                    $"{Name} has expenses, contributions or settlements in this group. Deleting would break the accounts.\n\nMark {Name} as inactive instead?",
                    "Mark inactive", "Cancel")
                && await RunAsync(() => _friends.SetActiveAsync(_groupId, _friendId, false)))
            {
                await Dialogs.ToastAsync($"{Name} is now inactive");
                await _navigation.GoToAsync("../.."); // close editor and the summary page underneath
            }
            return;
        }

        if (!await Dialogs.ConfirmAsync("Delete friend?", $"Remove {Name} from this group permanently?", "Delete", "Cancel")) return;
        if (await RunAsync(() => _friends.RemoveAsync(_groupId, _friendId)))
        {
            await Dialogs.ToastAsync("Friend removed");
            await _navigation.GoToAsync("../.."); // close editor and the summary page underneath
        }
    }
}

public sealed class FriendSummaryViewModel : BaseViewModel
{
    private readonly IFriendService _friends;
    private readonly AppState _state;
    private readonly INavigationService _navigation;
    private string? _friendId;

    public FriendSummaryViewModel(IFriendService friends, AppState state, INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        _friends = friends;
        _state = state;
        _navigation = navigation;
        Title = "Friend";
        EditCommand = new AsyncRelayCommand(() => _friendId is null ? Task.CompletedTask
            : _navigation.GoToAsync(Routes.FriendEditor, new Dictionary<string, object> { [NavKeys.FriendId] = _friendId }));
        ContributeCommand = new AsyncRelayCommand(() => _friendId is null ? Task.CompletedTask
            : _navigation.GoToAsync(Routes.ContributionEditor, new Dictionary<string, object> { [NavKeys.FriendId] = _friendId }));
        SettleCommand = new AsyncRelayCommand(() => _friendId is null ? Task.CompletedTask
            : _navigation.GoToAsync(Routes.SettlementEditor, new Dictionary<string, object> { [NavKeys.FromId] = _friendId }));
        OpenTransactionCommand = new AsyncRelayCommand<TransactionRow>(r => r is null ? Task.CompletedTask : TransactionNavigator.OpenAsync(_navigation, r.Item));
        RecordSuggestionCommand = new AsyncRelayCommand<SuggestionRow>(r => r is null ? Task.CompletedTask
            : SettlementsViewModel.OpenSuggestionAsync(_navigation, r));
    }

    public IAsyncRelayCommand EditCommand { get; }
    public IAsyncRelayCommand ContributeCommand { get; }
    public IAsyncRelayCommand SettleCommand { get; }
    public IAsyncRelayCommand<TransactionRow> OpenTransactionCommand { get; }
    public IAsyncRelayCommand<SuggestionRow> RecordSuggestionCommand { get; }
    public ObservableCollection<TransactionRow> Activity { get; } = new();
    public ObservableCollection<SuggestionRow> Suggestions { get; } = new();

    private string _name = "", _initials = "", _details = "", _balanceText = "", _balanceStatus = "",
        _paid = "", _share = "", _settlementsPaid = "", _settlementsReceived = "",
        _contributed = "", _fundUsed = "", _fundEquity = "", _totalShare = "", _counts = "";
    private bool _isPositive, _isNegative, _isInactive, _hasActivity, _hasSuggestions;

    public string Name { get => _name; set => SetProperty(ref _name, value); }
    public string Initials { get => _initials; set => SetProperty(ref _initials, value); }
    public string Details { get => _details; set => SetProperty(ref _details, value); }
    public string BalanceText { get => _balanceText; set => SetProperty(ref _balanceText, value); }
    public string BalanceStatus { get => _balanceStatus; set => SetProperty(ref _balanceStatus, value); }
    public string Paid { get => _paid; set => SetProperty(ref _paid, value); }
    public string Share { get => _share; set => SetProperty(ref _share, value); }
    public string SettlementsPaid { get => _settlementsPaid; set => SetProperty(ref _settlementsPaid, value); }
    public string SettlementsReceived { get => _settlementsReceived; set => SetProperty(ref _settlementsReceived, value); }
    public string Contributed { get => _contributed; set => SetProperty(ref _contributed, value); }
    public string FundUsed { get => _fundUsed; set => SetProperty(ref _fundUsed, value); }
    public string FundEquity { get => _fundEquity; set => SetProperty(ref _fundEquity, value); }
    public string TotalShare { get => _totalShare; set => SetProperty(ref _totalShare, value); }
    public string Counts { get => _counts; set => SetProperty(ref _counts, value); }
    public bool IsPositive { get => _isPositive; set => SetProperty(ref _isPositive, value); }
    public bool IsNegative { get => _isNegative; set => SetProperty(ref _isNegative, value); }
    public bool IsInactive { get => _isInactive; set => SetProperty(ref _isInactive, value); }
    public bool HasActivity { get => _hasActivity; set => SetProperty(ref _hasActivity, value); }
    public bool HasSuggestions { get => _hasSuggestions; set => SetProperty(ref _hasSuggestions, value); }

    public override void ApplyParameters(IDictionary<string, object> parameters) => _friendId = Param(parameters, NavKeys.FriendId);

    public override Task OnAppearingAsync() => RunAsync(async () =>
    {
        var groupId = await _state.EnsureGroupAsync() ?? throw new ValidationException("Create a group first.");
        if (_friendId is null) return;
        var s = await _friends.GetSummaryAsync(groupId, _friendId);

        Name = s.Member.Name;
        Title = s.Member.Name;
        Initials = Text.Initials(s.Member.Name);
        IsInactive = !s.Member.IsActive;
        Details = $"ID {s.Member.FriendCode} • Joined {Text.Date(s.Member.Joined)}" +
                  (string.IsNullOrWhiteSpace(s.Member.Phone) ? "" : $" • {s.Member.Phone}");

        var net = s.Balance.NetPaisa;
        IsPositive = net > 0;
        IsNegative = net < 0;
        BalanceText = Money.Format(Math.Abs(net));
        BalanceStatus = net > 0 ? "will get back from the group" : net < 0 ? "owes to the group" : "is fully settled";
        Paid = Money.Format(s.Balance.PaidPersonalPaisa);
        Share = Money.Format(s.Balance.SharePersonalPaisa);
        SettlementsPaid = Money.Format(s.Balance.SettlementsPaidPaisa);
        SettlementsReceived = Money.Format(s.Balance.SettlementsReceivedPaisa);
        Contributed = Money.Format(s.Fund.ContributedPaisa);
        FundUsed = Money.Format(s.Fund.FundShareConsumedPaisa);
        FundEquity = Money.Format(s.Fund.EquityPaisa);
        TotalShare = Money.Format(s.TotalShareAllExpensesPaisa);
        Counts = $"Paid {s.ExpensesPaidCount} expense(s) personally • shared in {s.ExpensesSharedCount}";

        DashboardViewModel.Replace(Activity, s.RecentActivity.Select(t => new TransactionRow(t, OpenTransactionCommand)));
        DashboardViewModel.Replace(Suggestions, s.Suggestions.Select(x => new SuggestionRow(x, RecordSuggestionCommand)));
        HasActivity = Activity.Count > 0;
        HasSuggestions = Suggestions.Count > 0;
    });
}
