using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

/// <summary>Opens the right editor for any transaction in a list.</summary>
public static class TransactionNavigator
{
    public static Task OpenAsync(INavigationService nav, TransactionItem t)
    {
        var p = new Dictionary<string, object> { [NavKeys.Id] = t.SourceId };
        return t.Kind switch
        {
            TransactionKind.PersonalExpense or TransactionKind.FundExpense => nav.GoToAsync(Routes.ExpenseEditor, p),
            TransactionKind.Contribution => nav.GoToAsync(Routes.ContributionEditor, p),
            TransactionKind.Settlement => nav.GoToAsync(Routes.SettlementEditor, p),
            _ => nav.GoToAsync(Routes.FundEntryEditor, p)
        };
    }
}

public sealed class DashboardViewModel : GroupViewModel
{
    private readonly IReportService _reports;

    public DashboardViewModel(IReportService reports, AppState state, INavigationService navigation, IDialogService dialogs)
        : base(state, navigation, dialogs)
    {
        _reports = reports;
        Title = "Friends Khata";

        AddExpenseCommand = new AsyncRelayCommand(() => GoIfGroup(Routes.ExpenseEditor));
        AddContributionCommand = new AsyncRelayCommand(() => GoIfGroup(Routes.ContributionEditor));
        AddSettlementCommand = new AsyncRelayCommand(() => GoIfGroup(Routes.SettlementEditor));
        ViewReportsCommand = new AsyncRelayCommand(() => GoIfGroup(Routes.Reports));
        ManageFriendsCommand = new AsyncRelayCommand(() => Navigation.GoToAsync(Routes.FriendsTab));
        SwitchGroupCommand = new AsyncRelayCommand(() => Navigation.GoToAsync(Routes.Groups));
        ViewAllTransactionsCommand = new AsyncRelayCommand(() => GoIfGroup(Routes.Transactions));
        ViewSettlementsCommand = new AsyncRelayCommand(() => GoIfGroup(Routes.Settlements));
        OpenTransactionCommand = new AsyncRelayCommand<TransactionRow>(r => r is null ? Task.CompletedTask : TransactionNavigator.OpenAsync(Navigation, r.Item));
        OpenFriendCommand = new AsyncRelayCommand<BalanceRow>(r => r is null ? Task.CompletedTask
            : Navigation.GoToAsync(Routes.FriendSummary, new Dictionary<string, object> { [NavKeys.FriendId] = r.FriendId }));
    }

    public IAsyncRelayCommand AddExpenseCommand { get; }
    public IAsyncRelayCommand AddContributionCommand { get; }
    public IAsyncRelayCommand AddSettlementCommand { get; }
    public IAsyncRelayCommand ViewReportsCommand { get; }
    public IAsyncRelayCommand ManageFriendsCommand { get; }
    public IAsyncRelayCommand SwitchGroupCommand { get; }
    public IAsyncRelayCommand ViewAllTransactionsCommand { get; }
    public IAsyncRelayCommand ViewSettlementsCommand { get; }
    public IAsyncRelayCommand<TransactionRow> OpenTransactionCommand { get; }
    public IAsyncRelayCommand<BalanceRow> OpenFriendCommand { get; }

    public ObservableCollection<TransactionRow> RecentTransactions { get; } = new();
    public ObservableCollection<TransactionRow> RecentExpenses { get; } = new();
    public ObservableCollection<BalanceRow> Balances { get; } = new();
    public ObservableCollection<CategoryShareRow> Categories { get; } = new();

    private string _totalExpenses = "", _personalPayments = "", _fundExpenses = "", _contributions = "",
        _fundBalance = "", _outstanding = "", _monthExpenses = "", _weekExpenses = "", _memberSummary = "", _monthName = "";
    private bool _hasMembers, _hasTransactions, _hasCategories;

    public string TotalExpenses { get => _totalExpenses; set => SetProperty(ref _totalExpenses, value); }
    public string PersonalPayments { get => _personalPayments; set => SetProperty(ref _personalPayments, value); }
    public string FundExpenses { get => _fundExpenses; set => SetProperty(ref _fundExpenses, value); }
    public string Contributions { get => _contributions; set => SetProperty(ref _contributions, value); }
    public string FundBalance { get => _fundBalance; set => SetProperty(ref _fundBalance, value); }
    public string Outstanding { get => _outstanding; set => SetProperty(ref _outstanding, value); }
    public string MonthExpenses { get => _monthExpenses; set => SetProperty(ref _monthExpenses, value); }
    public string WeekExpenses { get => _weekExpenses; set => SetProperty(ref _weekExpenses, value); }
    public string MemberSummary { get => _memberSummary; set => SetProperty(ref _memberSummary, value); }
    public string MonthName { get => _monthName; set => SetProperty(ref _monthName, value); }

    public bool HasMembers
    {
        get => _hasMembers;
        set { if (SetProperty(ref _hasMembers, value)) OnPropertyChanged(nameof(NeedsMembers)); }
    }
    public bool NeedsMembers => HasGroup && !HasMembers;
    public bool HasTransactions
    {
        get => _hasTransactions;
        set { if (SetProperty(ref _hasTransactions, value)) OnPropertyChanged(nameof(HasNoTransactions)); }
    }
    public bool HasNoTransactions => !HasTransactions;
    public bool HasCategories
    {
        get => _hasCategories;
        set { if (SetProperty(ref _hasCategories, value)) OnPropertyChanged(nameof(HasNoCategories)); }
    }
    public bool HasNoCategories => !HasCategories;

    protected override async Task LoadAsync(string groupId)
    {
        var today = DateTime.Today;
        var d = await _reports.GetDashboardAsync(groupId, today);

        TotalExpenses = Money.Format(d.TotalExpensesPaisa);
        PersonalPayments = Money.Format(d.TotalPersonalPaymentsPaisa);
        FundExpenses = Money.Format(d.TotalFundExpensesPaisa);
        Contributions = Money.Format(d.TotalContributionsPaisa);
        FundBalance = Money.Format(d.FundBalancePaisa);
        Outstanding = Money.Format(d.OutstandingPaisa);
        MonthExpenses = Money.Format(d.CurrentMonthExpensesPaisa);
        WeekExpenses = Money.Format(d.CurrentWeekExpensesPaisa);
        MonthName = ReportPeriod.MonthOf(today).Title;
        MemberSummary = $"{d.MemberCount} active member{(d.MemberCount == 1 ? "" : "s")}";
        HasMembers = d.MemberCount > 0;

        Replace(RecentTransactions, d.RecentTransactions.Select(t => new TransactionRow(t, OpenTransactionCommand)));
        Replace(RecentExpenses, d.RecentExpenses.Select(t => new TransactionRow(t, OpenTransactionCommand)));
        Replace(Balances, d.Balances.Select(b => new BalanceRow(b, OpenFriendCommand)));
        Replace(Categories, d.CategoryBreakdown.Take(6).Select(c => new CategoryShareRow(c)));
        HasTransactions = RecentTransactions.Count > 0;
        HasCategories = Categories.Count > 0;
        OnPropertyChanged(nameof(NeedsMembers));
    }

    protected override void ClearData()
    {
        RecentTransactions.Clear();
        RecentExpenses.Clear();
        Balances.Clear();
        Categories.Clear();
        HasMembers = false;
        HasTransactions = false;
        HasCategories = false;
        OnPropertyChanged(nameof(NeedsMembers));
    }

    private async Task GoIfGroup(string route)
    {
        if (await RequireGroupAsync() is null) return;
        if (!HasMembers && route != Routes.Reports && route != Routes.Transactions)
        {
            await Dialogs.AlertAsync("Add friends first", "Add the friends of this group before recording money.");
            await Navigation.GoToAsync(Routes.FriendEditor);
            return;
        }
        await Navigation.GoToAsync(route);
    }

    internal static void Replace<T>(ObservableCollection<T> target, IEnumerable<T> items)
    {
        target.Clear();
        foreach (var i in items) target.Add(i);
    }
}
