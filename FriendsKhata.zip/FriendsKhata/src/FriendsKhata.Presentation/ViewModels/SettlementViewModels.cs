using System.Collections.ObjectModel;
using System.Globalization;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

public sealed class SettlementsViewModel : GroupViewModel
{
    private readonly ISettlementService _settlements;

    public SettlementsViewModel(ISettlementService settlements, AppState state, INavigationService navigation, IDialogService dialogs)
        : base(state, navigation, dialogs)
    {
        _settlements = settlements;
        Title = "Balances & Settlements";
        AddCommand = new AsyncRelayCommand(() => Navigation.GoToAsync(Routes.SettlementEditor));
        RecordSuggestionCommand = new AsyncRelayCommand<SuggestionRow>(r => r is null ? Task.CompletedTask : OpenSuggestionAsync(Navigation, r));
        OpenHistoryCommand = new AsyncRelayCommand<TransactionRow>(r => r is null ? Task.CompletedTask : TransactionNavigator.OpenAsync(Navigation, r.Item));
        OpenFriendCommand = new AsyncRelayCommand<BalanceRow>(r => r is null ? Task.CompletedTask
            : Navigation.GoToAsync(Routes.FriendSummary, new Dictionary<string, object> { [NavKeys.FriendId] = r.FriendId }));
    }

    public IAsyncRelayCommand AddCommand { get; }
    public IAsyncRelayCommand<SuggestionRow> RecordSuggestionCommand { get; }
    public IAsyncRelayCommand<TransactionRow> OpenHistoryCommand { get; }
    public IAsyncRelayCommand<BalanceRow> OpenFriendCommand { get; }

    public ObservableCollection<BalanceRow> Balances { get; } = new();
    public ObservableCollection<SuggestionRow> Suggestions { get; } = new();
    public ObservableCollection<TransactionRow> History { get; } = new();

    private string _outstanding = "", _suggestionSummary = "";
    private bool _allSettled, _hasHistory;
    public string Outstanding { get => _outstanding; set => SetProperty(ref _outstanding, value); }
    public string SuggestionSummary { get => _suggestionSummary; set => SetProperty(ref _suggestionSummary, value); }
    public bool AllSettled
    {
        get => _allSettled;
        set { if (SetProperty(ref _allSettled, value)) OnPropertyChanged(nameof(HasSuggestions)); }
    }
    public bool HasSuggestions => !AllSettled;
    public bool HasHistory
    {
        get => _hasHistory;
        set { if (SetProperty(ref _hasHistory, value)) OnPropertyChanged(nameof(HasNoHistory)); }
    }
    public bool HasNoHistory => !HasHistory;

    protected override async Task LoadAsync(string groupId)
    {
        var balances = await _settlements.GetBalancesAsync(groupId);
        var suggestions = SettlementOptimizer.Suggest(balances);
        var history = await _settlements.GetHistoryAsync(groupId);

        DashboardViewModel.Replace(Balances, balances.Where(b => b.IsActive || b.NetPaisa != 0).Select(b => new BalanceRow(b, OpenFriendCommand)));
        DashboardViewModel.Replace(Suggestions, suggestions.Select(s => new SuggestionRow(s, RecordSuggestionCommand)));
        DashboardViewModel.Replace(History, history.Select(h => new TransactionRow(h, OpenHistoryCommand)));

        Outstanding = Money.Format(balances.Where(b => b.NetPaisa > 0).Sum(b => b.NetPaisa));
        AllSettled = suggestions.Count == 0;
        SuggestionSummary = AllSettled
            ? "Everyone is settled up. 🎉"
            : $"{suggestions.Count} payment{(suggestions.Count == 1 ? "" : "s")} will settle all balances";
        HasHistory = History.Count > 0;
    }

    public static Task OpenSuggestionAsync(INavigationService nav, SuggestionRow r)
        => nav.GoToAsync(Routes.SettlementEditor, new Dictionary<string, object>
        {
            [NavKeys.FromId] = r.Suggestion.FromFriendId,
            [NavKeys.ToId] = r.Suggestion.ToFriendId,
            [NavKeys.Amount] = r.Suggestion.AmountPaisa.ToString(CultureInfo.InvariantCulture)
        });
}

public sealed class SettlementEditorViewModel : BaseViewModel
{
    private readonly ISettlementService _settlements;
    private readonly IFriendService _friends;
    private readonly AppState _state;
    private readonly INavigationService _navigation;
    private string? _id, _groupId, _prefillFrom, _prefillTo;
    private long? _prefillAmount;
    private Dictionary<string, long> _balances = new();
    private bool _loaded;

    public SettlementEditorViewModel(ISettlementService settlements, IFriendService friends, AppState state,
        INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        _settlements = settlements;
        _friends = friends;
        _state = state;
        _navigation = navigation;
        Title = "Record Settlement";
        SaveCommand = new AsyncRelayCommand(SaveAsync);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync);
        SwapCommand = new RelayCommand(() => (SelectedFrom, SelectedTo) = (SelectedTo, SelectedFrom));
    }

    public IAsyncRelayCommand SaveCommand { get; }
    public IAsyncRelayCommand DeleteCommand { get; }
    public IRelayCommand SwapCommand { get; }
    public ObservableCollection<PickerOption> FriendOptions { get; } = new();

    private PickerOption? _from, _to;
    public PickerOption? SelectedFrom { get => _from; set { if (SetProperty(ref _from, value)) UpdateHint(); } }
    public PickerOption? SelectedTo { get => _to; set { if (SetProperty(ref _to, value)) UpdateHint(); } }

    private string _amountText = "", _notes = "", _hint = "";
    public string AmountText { get => _amountText; set => SetProperty(ref _amountText, value); }
    public string Notes { get => _notes; set => SetProperty(ref _notes, value); }
    public string Hint { get => _hint; set => SetProperty(ref _hint, value); }

    private DateTime _date = DateTime.Today;
    public DateTime Date { get => _date; set => SetProperty(ref _date, value); }

    private bool _isEditing;
    public bool IsEditing { get => _isEditing; set => SetProperty(ref _isEditing, value); }

    public override void ApplyParameters(IDictionary<string, object> parameters)
    {
        _id = Param(parameters, NavKeys.Id);
        _prefillFrom = Param(parameters, NavKeys.FromId);
        _prefillTo = Param(parameters, NavKeys.ToId);
        if (long.TryParse(Param(parameters, NavKeys.Amount), NumberStyles.Integer, CultureInfo.InvariantCulture, out var a)) _prefillAmount = a;
    }

    public override async Task OnAppearingAsync()
    {
        if (_loaded) return;
        await RunAsync(async () =>
        {
            _groupId = await _state.EnsureGroupAsync() ?? throw new ValidationException("Create a group first.");
            Core.Models.Settlement? existing = null;
            if (_id is not null)
            {
                existing = await _settlements.GetAsync(_id) ?? throw new ValidationException("This settlement no longer exists.");
                _groupId = existing.GroupId;
                IsEditing = true;
                Title = "Edit Settlement";
            }

            foreach (var m in await _friends.GetMembersAsync(_groupId))
                FriendOptions.Add(new PickerOption(m.FriendId, m.IsActive ? m.Name : m.Name + " (inactive)"));
            _balances = (await _settlements.GetBalancesAsync(_groupId)).ToDictionary(b => b.FriendId, b => b.NetPaisa);

            SelectedFrom = FriendOptions.FirstOrDefault(f => f.Id == (existing?.FromFriendId ?? _prefillFrom));
            SelectedTo = FriendOptions.FirstOrDefault(f => f.Id == (existing?.ToFriendId ?? _prefillTo));
            if (existing is not null)
            {
                AmountText = Money.ToInput(existing.AmountPaisa);
                Date = existing.Date;
                Notes = existing.Notes ?? "";
            }
            else if (_prefillAmount is { } amount)
            {
                AmountText = Money.ToInput(amount);
            }
            _loaded = true;
            UpdateHint();
        });
    }

    private void UpdateHint()
    {
        string Describe(PickerOption? o)
        {
            if (o is null) return "";
            var net = _balances.GetValueOrDefault(o.Id);
            return net > 0 ? $"{o.Name} gets back {Money.Format(net)}"
                : net < 0 ? $"{o.Name} owes {Money.Format(-net)}"
                : $"{o.Name} is settled";
        }

        var parts = new[] { Describe(SelectedFrom), Describe(SelectedTo) }.Where(s => s.Length > 0).ToList();
        Hint = parts.Count == 0 ? "Select who pays and who receives." : "Current balances: " + string.Join(" • ", parts);
        if (IsEditing) Hint += " (includes this settlement)";
    }

    private async Task SaveAsync()
    {
        if (_groupId is null) return;
        if (SelectedFrom is null || SelectedTo is null) { await Dialogs.AlertAsync("Please check", "Select both the payer and the receiver."); return; }
        if (!Money.TryParse(AmountText, out var amount, out var err)) { await Dialogs.AlertAsync("Please check", err!); return; }

        var draft = new SettlementDraft
        {
            Id = _id, GroupId = _groupId, FromFriendId = SelectedFrom.Id, ToFriendId = SelectedTo.Id,
            AmountPaisa = amount, Date = Date, Notes = Notes
        };
        if (await RunAsync(() => _settlements.SaveAsync(draft)))
        {
            await Dialogs.ToastAsync(IsEditing ? "Settlement updated" : "Settlement recorded");
            await _navigation.GoBackAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (_id is null) return;
        if (!await Dialogs.ConfirmAsync("Delete settlement?", "This payment record will be permanently deleted and balances recalculated.", "Delete", "Cancel")) return;
        if (await RunAsync(() => _settlements.DeleteAsync(_id)))
        {
            await Dialogs.ToastAsync("Settlement deleted");
            await _navigation.GoBackAsync();
        }
    }
}
