using System.Collections.ObjectModel;
using System.Globalization;
using System.Text;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

/// <summary>Writes CSV text to a temp file and lets the user save it where they want.</summary>
public sealed class CsvSaver
{
    private readonly StoragePaths _paths;
    private readonly IFileExchangeService _files;

    public CsvSaver(StoragePaths paths, IFileExchangeService files)
    {
        _paths = paths;
        _files = files;
    }

    public async Task<string?> SaveAsync(string fileName, string csv)
    {
        Directory.CreateDirectory(_paths.TempDirectory);
        var path = Path.Combine(_paths.TempDirectory, fileName);
        await File.WriteAllTextAsync(path, csv, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
        return await _files.SaveAsync(fileName, path);
    }

    public static string SafeName(string text)
    {
        var sb = new StringBuilder();
        foreach (var ch in text) sb.Append(char.IsLetterOrDigit(ch) ? ch : '-');
        return sb.ToString().Trim('-');
    }
}

public sealed class ReportsViewModel : GroupViewModel
{
    private readonly IReportService _reports;
    private readonly IExportService _export;
    private readonly CsvSaver _csv;
    private FinancialReport? _report;

    public ReportsViewModel(IReportService reports, IExportService export, CsvSaver csv,
        AppState state, INavigationService navigation, IDialogService dialogs) : base(state, navigation, dialogs)
    {
        _reports = reports;
        _export = export;
        _csv = csv;
        Title = "Reports";
        Period = ReportPeriod.WeekOf(DateTime.Today);

        PreviousCommand = new AsyncRelayCommand(() => ChangePeriodAsync(Period.Previous()));
        NextCommand = new AsyncRelayCommand(() => ChangePeriodAsync(Period.Next()));
        TodayCommand = new AsyncRelayCommand(() => ChangePeriodAsync(ModeIndex == 1 ? ReportPeriod.MonthOf(DateTime.Today) : ReportPeriod.WeekOf(DateTime.Today)));
        ApplyCustomCommand = new AsyncRelayCommand(ApplyCustomAsync);
        ExportCommand = new AsyncRelayCommand(ExportAsync);
    }

    public IAsyncRelayCommand PreviousCommand { get; }
    public IAsyncRelayCommand NextCommand { get; }
    public IAsyncRelayCommand TodayCommand { get; }
    public IAsyncRelayCommand ApplyCustomCommand { get; }
    public IAsyncRelayCommand ExportCommand { get; }

    public IReadOnlyList<string> ModeOptions { get; } = new[] { "Weekly", "Monthly", "Custom range" };
    public ObservableCollection<ReportFriendRow> Friends { get; } = new();
    public ObservableCollection<CategoryShareRow> Categories { get; } = new();
    public ObservableCollection<TransactionRow> Settlements { get; } = new();
    public ObservableCollection<BalanceRow> Outstanding { get; } = new();

    private ReportPeriod _period = ReportPeriod.WeekOf(DateTime.Today);
    public ReportPeriod Period
    {
        get => _period;
        private set { _period = value; OnPropertyChanged(); OnPropertyChanged(nameof(PeriodTitle)); OnPropertyChanged(nameof(PeriodRange)); }
    }
    public string PeriodTitle => Period.Title;
    public string PeriodRange => $"{Text.Date(Period.Start)} → {Text.Date(Period.End)} ({Period.Days} days)";

    private int _modeIndex;
    public int ModeIndex
    {
        get => _modeIndex;
        set
        {
            if (!SetProperty(ref _modeIndex, value < 0 ? 0 : value)) return;
            OnPropertyChanged(nameof(IsCustom));
            OnPropertyChanged(nameof(IsStepper));
            if (_modeIndex == 0) _ = ChangePeriodAsync(ReportPeriod.WeekOf(DateTime.Today));
            else if (_modeIndex == 1) _ = ChangePeriodAsync(ReportPeriod.MonthOf(DateTime.Today));
        }
    }
    public bool IsCustom => ModeIndex == 2;
    public bool IsStepper => !IsCustom;

    private DateTime _customFrom = DateTime.Today.AddDays(-30), _customTo = DateTime.Today;
    public DateTime CustomFrom { get => _customFrom; set => SetProperty(ref _customFrom, value); }
    public DateTime CustomTo { get => _customTo; set => SetProperty(ref _customTo, value); }

    private string _totalExpenses = "", _personal = "", _fundSpending = "", _contributions = "", _refunds = "",
        _opening = "", _closing = "", _adjustments = "", _settlementTotal = "", _expenseCount = "", _outstandingTotal = "";
    private bool _hasData, _hasCategories, _hasSettlements;

    public string TotalExpenses { get => _totalExpenses; set => SetProperty(ref _totalExpenses, value); }
    public string Personal { get => _personal; set => SetProperty(ref _personal, value); }
    public string FundSpending { get => _fundSpending; set => SetProperty(ref _fundSpending, value); }
    public string Contributions { get => _contributions; set => SetProperty(ref _contributions, value); }
    public string Refunds { get => _refunds; set => SetProperty(ref _refunds, value); }
    public string Adjustments { get => _adjustments; set => SetProperty(ref _adjustments, value); }
    public string Opening { get => _opening; set => SetProperty(ref _opening, value); }
    public string Closing { get => _closing; set => SetProperty(ref _closing, value); }
    public string SettlementTotal { get => _settlementTotal; set => SetProperty(ref _settlementTotal, value); }
    public string ExpenseCount { get => _expenseCount; set => SetProperty(ref _expenseCount, value); }
    public string OutstandingTotal { get => _outstandingTotal; set => SetProperty(ref _outstandingTotal, value); }
    public bool HasData { get => _hasData; set { if (SetProperty(ref _hasData, value)) OnPropertyChanged(nameof(HasNoData)); } }
    public bool HasNoData => !HasData;
    public bool HasCategories { get => _hasCategories; set => SetProperty(ref _hasCategories, value); }
    public bool HasSettlements { get => _hasSettlements; set { if (SetProperty(ref _hasSettlements, value)) OnPropertyChanged(nameof(HasNoSettlements)); } }
    public bool HasNoSettlements => !HasSettlements;

    protected override async Task LoadAsync(string groupId)
    {
        var r = await _reports.GetReportAsync(groupId, Period);
        _report = r;
        TotalExpenses = Money.Format(r.TotalExpensesPaisa);
        Personal = Money.Format(r.PersonalPaymentsPaisa);
        FundSpending = Money.Format(r.FundSpendingPaisa);
        Contributions = Money.Format(r.ContributionsPaisa);
        Refunds = Money.Format(r.FundRefundsPaisa);
        Adjustments = (r.FundAdjustmentsPaisa > 0 ? "+" : "") + Money.Format(r.FundAdjustmentsPaisa);
        Opening = Money.Format(r.OpeningFundBalancePaisa);
        Closing = Money.Format(r.ClosingFundBalancePaisa);
        SettlementTotal = $"{Money.Format(r.SettlementsTotalPaisa)} in {r.SettlementCount} payment{(r.SettlementCount == 1 ? "" : "s")}";
        ExpenseCount = $"{r.ExpenseCount} expense{(r.ExpenseCount == 1 ? "" : "s")}";
        OutstandingTotal = Money.Format(r.TotalOutstandingAtEndPaisa);

        DashboardViewModel.Replace(Friends, r.Friends.Select(f => new ReportFriendRow(f)));
        DashboardViewModel.Replace(Categories, r.Categories.Select(c => new CategoryShareRow(c)));
        DashboardViewModel.Replace(Settlements, r.Settlements.Select(s => new TransactionRow(s)));
        DashboardViewModel.Replace(Outstanding, r.OutstandingAtEnd.Where(b => b.NetPaisa != 0).Select(b => new BalanceRow(b)));
        HasData = r.ExpenseCount > 0 || r.ContributionsPaisa > 0 || r.SettlementCount > 0 || r.FundRefundsPaisa != 0 || r.FundAdjustmentsPaisa != 0;
        HasCategories = Categories.Count > 0;
        HasSettlements = Settlements.Count > 0;
    }

    private async Task ChangePeriodAsync(ReportPeriod period)
    {
        Period = period;
        if (GroupId is not null) await RunAsync(() => LoadAsync(GroupId));
    }

    private Task ApplyCustomAsync() => RunAsync(async () =>
    {
        Period = ReportPeriod.Custom(CustomFrom, CustomTo);
        if (GroupId is not null) await LoadAsync(GroupId);
    });

    private async Task ExportAsync()
    {
        if (_report is null || GroupId is null) return;
        await RunAsync(async () =>
        {
            var csv = _export.ReportToCsv(_report, GroupName);
            var name = $"FriendsKhata-{CsvSaver.SafeName(GroupName)}-{_report.Period.Start:yyyyMMdd}-{_report.Period.End:yyyyMMdd}.csv";
            var saved = await _csv.SaveAsync(name, csv);
            if (saved is not null) await Dialogs.ToastAsync("Report exported");
        });
    }
}

public sealed class TransactionHistoryViewModel : GroupViewModel
{
    private readonly IReportService _reports;
    private readonly IExportService _export;
    private readonly CsvSaver _csv;
    private List<TransactionItem> _current = new();

    public TransactionHistoryViewModel(IReportService reports, IExportService export, CsvSaver csv,
        AppState state, INavigationService navigation, IDialogService dialogs) : base(state, navigation, dialogs)
    {
        _reports = reports;
        _export = export;
        _csv = csv;
        Title = "Transaction History";
        OpenCommand = new AsyncRelayCommand<TransactionRow>(r => r is null ? Task.CompletedTask : TransactionNavigator.OpenAsync(Navigation, r.Item));
        ApplyCommand = new AsyncRelayCommand(() => GroupId is null ? Task.CompletedTask : RunAsync(() => LoadAsync(GroupId)));
        ExportCommand = new AsyncRelayCommand(ExportAsync);
        Range.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(DateRangeFilter.SelectedIndex) && !Range.IsCustom && GroupId is not null)
                _ = RunAsync(() => LoadAsync(GroupId), showBusy: false);
        };
    }

    public IAsyncRelayCommand<TransactionRow> OpenCommand { get; }
    public IAsyncRelayCommand ApplyCommand { get; }
    public IAsyncRelayCommand ExportCommand { get; }
    public DateRangeFilter Range { get; } = new();
    public ObservableCollection<TransactionRow> Transactions { get; } = new();

    public IReadOnlyList<string> KindOptions { get; } = new[]
    {
        "All types", "Personal expenses", "Group fund expenses", "Fund contributions", "Settlements", "Fund refunds", "Fund adjustments"
    };

    private int _kindIndex;
    public int KindIndex
    {
        get => _kindIndex;
        set { if (SetProperty(ref _kindIndex, value < 0 ? 0 : value) && GroupId is not null) _ = RunAsync(() => LoadAsync(GroupId), showBusy: false); }
    }

    private string _summary = "";
    private bool _isEmpty;
    public string Summary { get => _summary; set => SetProperty(ref _summary, value); }
    public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

    private TransactionKind? Kind => KindIndex switch
    {
        1 => TransactionKind.PersonalExpense,
        2 => TransactionKind.FundExpense,
        3 => TransactionKind.Contribution,
        4 => TransactionKind.Settlement,
        5 => TransactionKind.FundRefund,
        6 => TransactionKind.FundAdjustment,
        _ => null
    };

    protected override async Task LoadAsync(string groupId)
    {
        var (from, to) = Range.Resolve(DateTime.Today);
        _current = (await _reports.GetTransactionsAsync(groupId, new TransactionFilter { From = from, To = to, Kind = Kind })).ToList();
        DashboardViewModel.Replace(Transactions, _current.Select(t => new TransactionRow(t, OpenCommand)));
        Summary = $"{_current.Count} transaction{(_current.Count == 1 ? "" : "s")}";
        IsEmpty = _current.Count == 0;
    }

    private Task ExportAsync() => RunAsync(async () =>
    {
        if (_current.Count == 0) { await Dialogs.AlertAsync("Nothing to export", "There are no transactions for these filters."); return; }
        var name = $"FriendsKhata-transactions-{CsvSaver.SafeName(GroupName)}-{DateTime.Now.ToString("yyyyMMdd-HHmm", CultureInfo.InvariantCulture)}.csv";
        if (await _csv.SaveAsync(name, _export.TransactionsToCsv(_current)) is not null)
            await Dialogs.ToastAsync("Transactions exported");
    });
}
