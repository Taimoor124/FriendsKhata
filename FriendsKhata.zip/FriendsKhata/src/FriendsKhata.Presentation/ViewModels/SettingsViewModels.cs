using System.Collections.ObjectModel;
using System.Globalization;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

public sealed class GroupsViewModel : BaseViewModel
{
    private readonly IGroupService _groups;
    private readonly AppState _state;
    private readonly INavigationService _navigation;

    public GroupsViewModel(IGroupService groups, AppState state, INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        _groups = groups;
        _state = state;
        _navigation = navigation;
        Title = "Groups";
        CreateCommand = new AsyncRelayCommand(CreateAsync);
        OpenCommand = new AsyncRelayCommand<GroupRow>(OpenAsync);
        RenameCommand = new AsyncRelayCommand<GroupRow>(RenameAsync);
        DeleteCommand = new AsyncRelayCommand<GroupRow>(DeleteAsync);
    }

    public IAsyncRelayCommand CreateCommand { get; }
    public IAsyncRelayCommand<GroupRow> OpenCommand { get; }
    public IAsyncRelayCommand<GroupRow> RenameCommand { get; }
    public IAsyncRelayCommand<GroupRow> DeleteCommand { get; }
    public ObservableCollection<GroupRow> Groups { get; } = new();

    private bool _isEmpty;
    public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

    public override Task OnAppearingAsync() => RunAsync(LoadAsync);

    private async Task LoadAsync()
    {
        var current = await _state.EnsureGroupAsync();
        var list = await _groups.GetGroupsAsync();
        DashboardViewModel.Replace(Groups, list.Select(g => new GroupRow(g, g.Id == current, OpenCommand, RenameCommand, DeleteCommand)));
        IsEmpty = Groups.Count == 0;
    }

    private async Task CreateAsync()
    {
        var name = await Dialogs.PromptAsync("New group", "Group name (e.g. University Friends, Office Friends)", accept: "Create", placeholder: "Group name");
        if (string.IsNullOrWhiteSpace(name)) return;
        FriendGroup? created = null;
        if (await RunAsync(async () => created = await _groups.CreateAsync(name, null)) && created is not null)
        {
            _state.CurrentGroupId = created.Id;
            await Dialogs.ToastAsync($"\"{created.Name}\" created. Now add your friends.");
            await _navigation.GoToAsync(Routes.FriendsTab);
        }
    }

    private async Task OpenAsync(GroupRow? row)
    {
        if (row is null) return;
        _state.CurrentGroupId = row.Id;
        await Dialogs.ToastAsync($"Switched to {row.Name}");
        await _navigation.GoToAsync(Routes.DashboardTab);
    }

    private async Task RenameAsync(GroupRow? row)
    {
        if (row is null) return;
        var name = await Dialogs.PromptAsync("Rename group", "New name", row.Name, "Save");
        if (string.IsNullOrWhiteSpace(name) || name.Trim() == row.Name) return;
        if (await RunAsync(() => _groups.UpdateAsync(row.Id, name, row.Description == "No description" ? null : row.Description)))
            await LoadAsync();
    }

    private async Task DeleteAsync(GroupRow? row)
    {
        if (row is null) return;
        if (!await Dialogs.ConfirmAsync("Delete group?",
                $"Delete \"{row.Name}\" and ALL of its expenses, fund records and settlements? This cannot be undone.\n\nTip: export a backup first (More → Backup & Restore).",
                "Continue", "Cancel")) return;
        var typed = await Dialogs.PromptAsync("Confirm delete", $"Type DELETE to permanently delete \"{row.Name}\".", accept: "Delete", placeholder: "DELETE");
        if (!string.Equals(typed?.Trim(), "DELETE", StringComparison.Ordinal))
        {
            await Dialogs.ToastAsync("Group not deleted");
            return;
        }
        if (await RunAsync(() => _groups.DeleteAsync(row.Id)))
        {
            await Dialogs.ToastAsync("Group deleted");
            await LoadAsync();
        }
    }
}

public sealed class CategoriesViewModel : BaseViewModel
{
    private readonly ICategoryService _categories;

    public CategoriesViewModel(ICategoryService categories, IDialogService dialogs) : base(dialogs)
    {
        _categories = categories;
        Title = "Categories";
        AddCommand = new AsyncRelayCommand(AddAsync);
        EditCommand = new AsyncRelayCommand<CategoryItemRow>(EditAsync);
        DeleteCommand = new AsyncRelayCommand<CategoryItemRow>(DeleteAsync);
    }

    public IAsyncRelayCommand AddCommand { get; }
    public IAsyncRelayCommand<CategoryItemRow> EditCommand { get; }
    public IAsyncRelayCommand<CategoryItemRow> DeleteCommand { get; }
    public ObservableCollection<CategoryItemRow> Categories { get; } = new();

    public override Task OnAppearingAsync() => RunAsync(LoadAsync);

    private async Task LoadAsync()
        => DashboardViewModel.Replace(Categories, (await _categories.GetAllAsync()).Select(c => new CategoryItemRow(c, EditCommand, DeleteCommand)));

    private async Task AddAsync()
    {
        var name = await Dialogs.PromptAsync("New category", "Category name", accept: "Next", maxLength: 40, placeholder: "e.g. Gym");
        if (string.IsNullOrWhiteSpace(name)) return;
        var icon = await Dialogs.PromptAsync("Icon (optional)", "Type or paste one emoji, e.g. 🏋️", accept: "Save", maxLength: 8, placeholder: "🏷️");
        if (await RunAsync(() => _categories.AddAsync(name, icon))) await LoadAsync();
    }

    private async Task EditAsync(CategoryItemRow? row)
    {
        if (row is null) return;
        var name = await Dialogs.PromptAsync("Edit category", "Category name", row.Name, "Next", 40);
        if (string.IsNullOrWhiteSpace(name)) return;
        var icon = await Dialogs.PromptAsync("Icon", "Type or paste one emoji", row.Icon, "Save", 8);
        if (await RunAsync(() => _categories.UpdateAsync(row.Id, name, icon ?? row.Icon))) await LoadAsync();
    }

    private async Task DeleteAsync(CategoryItemRow? row)
    {
        if (row is null) return;
        if (!await Dialogs.ConfirmAsync("Delete category?", $"Delete \"{row.Name}\"?", "Delete", "Cancel")) return;
        if (await RunAsync(() => _categories.DeleteAsync(row.Id))) await LoadAsync();
    }
}

public sealed class BackupViewModel : BaseViewModel
{
    private readonly IBackupService _backup;
    private readonly IFileExchangeService _files;
    private readonly AppState _state;
    private readonly INavigationService _navigation;

    public BackupViewModel(IBackupService backup, IFileExchangeService files, StoragePaths paths, AppState state,
        INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        _backup = backup;
        _files = files;
        _state = state;
        _navigation = navigation;
        Title = "Backup & Restore";
        DatabaseLocation = paths.DatabasePath;
        ExportCommand = new AsyncRelayCommand(ExportAsync);
        RestoreCommand = new AsyncRelayCommand(RestoreAsync);
    }

    public IAsyncRelayCommand ExportCommand { get; }
    public IAsyncRelayCommand RestoreCommand { get; }
    public string DatabaseLocation { get; }

    private string _status = "";
    public string Status { get => _status; set => SetProperty(ref _status, value); }

    private Task ExportAsync() => RunAsync(async () =>
    {
        var temp = await _backup.CreateBackupFileAsync();
        var saved = await _files.SaveAsync(Path.GetFileName(temp), temp);
        Status = saved is null ? "Backup cancelled." : $"Backup saved: {saved}";
        if (saved is not null) await Dialogs.ToastAsync("Backup saved");
    });

    private async Task RestoreAsync()
    {
        string? picked = null;
        if (!await RunAsync(async () => picked = await _files.PickFileAsync("Select a Friends Khata backup (.db3)"), showBusy: false) || picked is null)
            return;

        BackupInfo? info = null;
        await RunAsync(async () => info = await _backup.InspectBackupAsync(picked));
        if (info is null) return;
        if (!info.IsValid)
        {
            await Dialogs.AlertAsync("Invalid backup", info.Error ?? "This file cannot be restored.");
            return;
        }

        var size = (info.FileSizeBytes / 1024.0).ToString("0.#", CultureInfo.InvariantCulture);
        var ok = await Dialogs.ConfirmAsync("Replace all current data?",
            $"The backup contains {info.GroupCount} group(s) and {info.ExpenseCount} expense(s) ({size} KB).\n\n" +
            "ALL data currently in the app will be replaced by this backup. " +
            "A safety copy of the current data is kept on the device automatically.",
            "Restore", "Cancel");
        if (!ok) return;

        if (await RunAsync(() => _backup.RestoreAsync(picked)))
        {
            _state.CurrentGroupId = null;
            await _state.EnsureGroupAsync();
            Status = $"Restored on {DateTime.Now.ToString("dd MMM yyyy HH:mm", CultureInfo.InvariantCulture)}.";
            await Dialogs.AlertAsync("Restore complete", "Your data has been restored from the backup.");
            await _navigation.GoToAsync(Routes.DashboardTab);
        }
    }
}

public sealed class MoreViewModel : GroupViewModel
{
    public MoreViewModel(AppState state, INavigationService navigation, IDialogService dialogs) : base(state, navigation, dialogs)
    {
        Title = "More";
        GoCommand = new AsyncRelayCommand<string>(async route =>
        {
            if (string.IsNullOrEmpty(route)) return;
            if (route is Routes.Reports or Routes.Transactions or Routes.Settlements && await RequireGroupAsync() is null) return;
            await Navigation.GoToAsync(route);
        });
    }

    public IAsyncRelayCommand<string> GoCommand { get; }

    public string Version { get; set; } = "";

    protected override Task LoadAsync(string groupId) => Task.CompletedTask;
}
