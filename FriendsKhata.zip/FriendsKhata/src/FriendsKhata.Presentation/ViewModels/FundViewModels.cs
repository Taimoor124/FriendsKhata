using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

public sealed class FundViewModel : GroupViewModel
{
    private readonly IFundService _fund;
    private readonly IFriendService _friends;

    public FundViewModel(IFundService fund, IFriendService friends, AppState state, INavigationService navigation, IDialogService dialogs)
        : base(state, navigation, dialogs)
    {
        _fund = fund;
        _friends = friends;
        Title = "Group Fund";

        AddContributionCommand = new AsyncRelayCommand(() => GoAsync(Routes.ContributionEditor, null));
        AddRefundCommand = new AsyncRelayCommand(() => GoAsync(Routes.FundEntryEditor,
            new Dictionary<string, object> { [NavKeys.Type] = ((int)FundTransactionType.Refund).ToString() }));
        AddAdjustmentCommand = new AsyncRelayCommand(() => GoAsync(Routes.FundEntryEditor,
            new Dictionary<string, object> { [NavKeys.Type] = ((int)FundTransactionType.Adjustment).ToString() }));
        MoreActionsCommand = new AsyncRelayCommand(MoreActionsAsync);
        OpenLedgerCommand = new AsyncRelayCommand<LedgerRow>(r => r is null ? Task.CompletedTask : TransactionNavigator.OpenAsync(Navigation, r.Item));
        ContributeForCommand = new AsyncRelayCommand<FundPositionRow>(r => r is null ? Task.CompletedTask
            : GoAsync(Routes.ContributionEditor, new Dictionary<string, object> { [NavKeys.FriendId] = r.FriendId }));
    }

    public IAsyncRelayCommand AddContributionCommand { get; }
    public IAsyncRelayCommand AddRefundCommand { get; }
    public IAsyncRelayCommand AddAdjustmentCommand { get; }
    public IAsyncRelayCommand MoreActionsCommand { get; }
    public IAsyncRelayCommand<LedgerRow> OpenLedgerCommand { get; }
    public IAsyncRelayCommand<FundPositionRow> ContributeForCommand { get; }

    public ObservableCollection<FundPositionRow> Positions { get; } = new();
    public ObservableCollection<LedgerRow> Ledger { get; } = new();

    private string _balance = "", _collected = "", _spent = "", _refunded = "", _counts = "", _unallocated = "";
    private bool _hasLedger, _hasUnallocated;
    public string Balance { get => _balance; set => SetProperty(ref _balance, value); }
    public string Collected { get => _collected; set => SetProperty(ref _collected, value); }
    public string Spent { get => _spent; set => SetProperty(ref _spent, value); }
    public string Refunded { get => _refunded; set => SetProperty(ref _refunded, value); }
    public string Counts { get => _counts; set => SetProperty(ref _counts, value); }
    public string Unallocated { get => _unallocated; set => SetProperty(ref _unallocated, value); }
    public bool HasUnallocated { get => _hasUnallocated; set => SetProperty(ref _hasUnallocated, value); }
    public bool HasLedger
    {
        get => _hasLedger;
        set { if (SetProperty(ref _hasLedger, value)) OnPropertyChanged(nameof(HasNoLedger)); }
    }
    public bool HasNoLedger => !HasLedger;

    protected override async Task LoadAsync(string groupId)
    {
        var s = await _fund.GetSummaryAsync(groupId);
        Balance = Money.Format(s.BalancePaisa);
        Collected = Money.Format(s.TotalCollectedPaisa);
        Spent = Money.Format(s.TotalSpentPaisa);
        Refunded = Money.Format(s.TotalRefundedPaisa);
        Counts = $"{s.ContributionCount} contribution{(s.ContributionCount == 1 ? "" : "s")} • {s.FundExpenseCount} fund expense{(s.FundExpenseCount == 1 ? "" : "s")}";
        HasUnallocated = s.UnallocatedAdjustmentsPaisa != 0;
        Unallocated = $"Adjustments not linked to a friend: {Money.Format(s.UnallocatedAdjustmentsPaisa)}";

        DashboardViewModel.Replace(Positions, s.Friends.Select(f => new FundPositionRow(f, ContributeForCommand)));
        var ledger = await _fund.GetLedgerAsync(groupId);
        DashboardViewModel.Replace(Ledger, ledger.Select(l => new LedgerRow(l.Item, l.SignedAmountPaisa, l.BalanceAfterPaisa, OpenLedgerCommand)));
        HasLedger = Ledger.Count > 0;
    }

    protected override void ClearData()
    {
        Positions.Clear();
        Ledger.Clear();
        HasLedger = false;
    }

    private async Task MoreActionsAsync()
    {
        var choice = await Dialogs.ChooseAsync("Group fund", "Add contribution", "Refund money to a friend", "Adjust fund balance");
        if (choice == "Add contribution") await AddContributionCommand.ExecuteAsync(null);
        else if (choice == "Refund money to a friend") await AddRefundCommand.ExecuteAsync(null);
        else if (choice == "Adjust fund balance") await AddAdjustmentCommand.ExecuteAsync(null);
    }

    private async Task GoAsync(string route, IDictionary<string, object>? p)
    {
        var groupId = await RequireGroupAsync();
        if (groupId is null) return;
        if ((await _friends.GetMembersAsync(groupId, includeInactive: false)).Count == 0)
        {
            await Dialogs.AlertAsync("Add friends first", "Add the friends of this group before recording fund money.");
            return;
        }
        await Navigation.GoToAsync(route, p);
    }
}

public sealed class ContributionEditorViewModel : BaseViewModel
{
    private readonly IFundService _fund;
    private readonly IFriendService _friends;
    private readonly AppState _state;
    private readonly INavigationService _navigation;
    private string? _id, _prefillFriend, _groupId;
    private bool _loaded;

    public ContributionEditorViewModel(IFundService fund, IFriendService friends, AppState state, INavigationService navigation, IDialogService dialogs)
        : base(dialogs)
    {
        _fund = fund;
        _friends = friends;
        _state = state;
        _navigation = navigation;
        Title = "Add Contribution";
        SaveCommand = new AsyncRelayCommand(SaveAsync);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync);
    }

    public IAsyncRelayCommand SaveCommand { get; }
    public IAsyncRelayCommand DeleteCommand { get; }
    public ObservableCollection<PickerOption> FriendOptions { get; } = new();

    private PickerOption? _selectedFriend;
    public PickerOption? SelectedFriend { get => _selectedFriend; set => SetProperty(ref _selectedFriend, value); }

    private string _amountText = "", _notes = "", _balanceInfo = "";
    public string AmountText { get => _amountText; set => SetProperty(ref _amountText, value); }
    public string Notes { get => _notes; set => SetProperty(ref _notes, value); }
    public string BalanceInfo { get => _balanceInfo; set => SetProperty(ref _balanceInfo, value); }

    private DateTime _date = DateTime.Today;
    public DateTime Date { get => _date; set => SetProperty(ref _date, value); }

    private bool _isEditing;
    public bool IsEditing { get => _isEditing; set => SetProperty(ref _isEditing, value); }

    public override void ApplyParameters(IDictionary<string, object> parameters)
    {
        _id = Param(parameters, NavKeys.Id);
        _prefillFriend = Param(parameters, NavKeys.FriendId);
    }

    public override async Task OnAppearingAsync()
    {
        if (_loaded) return;
        await RunAsync(async () =>
        {
            _groupId = await _state.EnsureGroupAsync() ?? throw new ValidationException("Create a group first.");
            FundContribution? existing = null;
            if (_id is not null)
            {
                existing = await _fund.GetContributionAsync(_id) ?? throw new ValidationException("This contribution no longer exists.");
                _groupId = existing.GroupId;
                IsEditing = true;
                Title = "Edit Contribution";
            }

            foreach (var m in await _friends.GetMembersAsync(_groupId))
                if (m.IsActive || m.FriendId == existing?.FriendId)
                    FriendOptions.Add(new PickerOption(m.FriendId, m.Name));

            var friendId = existing?.FriendId ?? _prefillFriend;
            SelectedFriend = FriendOptions.FirstOrDefault(f => f.Id == friendId);
            if (existing is not null)
            {
                AmountText = Money.ToInput(existing.AmountPaisa);
                Date = existing.Date;
                Notes = existing.Notes ?? "";
            }
            BalanceInfo = "Current fund balance: " + Money.Format(await _fund.GetBalanceAsync(_groupId));
            _loaded = true;
        });
    }

    private async Task SaveAsync()
    {
        if (_groupId is null) return;
        if (SelectedFriend is null) { await Dialogs.AlertAsync("Please check", "Select the contributing friend."); return; }
        if (!Money.TryParse(AmountText, out var amount, out var err)) { await Dialogs.AlertAsync("Please check", err!); return; }

        var draft = new ContributionDraft { Id = _id, GroupId = _groupId, FriendId = SelectedFriend.Id, AmountPaisa = amount, Date = Date, Notes = Notes };
        if (await RunAsync(() => _fund.SaveContributionAsync(draft)))
        {
            await Dialogs.ToastAsync(IsEditing ? "Contribution updated" : "Contribution added to the fund");
            await _navigation.GoBackAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (_id is null) return;
        if (!await Dialogs.ConfirmAsync("Delete contribution?",
                "This contribution will be permanently removed and the fund balance reduced.", "Delete", "Cancel")) return;
        if (await RunAsync(() => _fund.DeleteContributionAsync(_id)))
        {
            await Dialogs.ToastAsync("Contribution deleted");
            await _navigation.GoBackAsync();
        }
    }
}

/// <summary>Refund (fund → friend) or manual adjustment.</summary>
public sealed class FundEntryEditorViewModel : BaseViewModel
{
    private readonly IFundService _fund;
    private readonly IFriendService _friends;
    private readonly AppState _state;
    private readonly INavigationService _navigation;
    private string? _id, _groupId;
    private bool _loaded;

    public FundEntryEditorViewModel(IFundService fund, IFriendService friends, AppState state, INavigationService navigation, IDialogService dialogs)
        : base(dialogs)
    {
        _fund = fund;
        _friends = friends;
        _state = state;
        _navigation = navigation;
        SaveCommand = new AsyncRelayCommand(SaveAsync);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync);
        Type = FundTransactionType.Refund;
    }

    public IAsyncRelayCommand SaveCommand { get; }
    public IAsyncRelayCommand DeleteCommand { get; }
    public ObservableCollection<PickerOption> FriendOptions { get; } = new();
    public IReadOnlyList<string> DirectionOptions { get; } = new[] { "Decrease fund (money out)", "Increase fund (money in)" };

    private FundTransactionType _type;
    public FundTransactionType Type
    {
        get => _type;
        private set
        {
            _type = value;
            Title = value == FundTransactionType.Refund ? "Refund from Fund" : "Fund Adjustment";
            OnPropertyChanged(nameof(IsRefund));
            OnPropertyChanged(nameof(IsAdjustment));
            OnPropertyChanged(nameof(FriendLabel));
            OnPropertyChanged(nameof(HelpText));
        }
    }

    public bool IsRefund => Type == FundTransactionType.Refund;
    public bool IsAdjustment => Type == FundTransactionType.Adjustment;
    public string FriendLabel => IsRefund ? "Refund to" : "Related friend (optional)";
    public string HelpText => IsRefund
        ? "Use a refund when money is paid back from the group fund to a friend (for example, leftover fund returned)."
        : "Use an adjustment to correct the fund balance, e.g. a cash count difference or bank charges. It is not an expense.";

    private PickerOption? _selectedFriend;
    public PickerOption? SelectedFriend { get => _selectedFriend; set => SetProperty(ref _selectedFriend, value); }

    private int _directionIndex;
    public int DirectionIndex { get => _directionIndex; set => SetProperty(ref _directionIndex, value < 0 ? 0 : value); }

    private string _amountText = "", _notes = "", _balanceInfo = "";
    public string AmountText { get => _amountText; set => SetProperty(ref _amountText, value); }
    public string Notes { get => _notes; set => SetProperty(ref _notes, value); }
    public string BalanceInfo { get => _balanceInfo; set => SetProperty(ref _balanceInfo, value); }

    private DateTime _date = DateTime.Today;
    public DateTime Date { get => _date; set => SetProperty(ref _date, value); }

    private bool _isEditing;
    public bool IsEditing { get => _isEditing; set => SetProperty(ref _isEditing, value); }

    public override void ApplyParameters(IDictionary<string, object> parameters)
    {
        _id = Param(parameters, NavKeys.Id);
        if (int.TryParse(Param(parameters, NavKeys.Type), out var t) && Enum.IsDefined(typeof(FundTransactionType), t))
            Type = (FundTransactionType)t;
    }

    public override async Task OnAppearingAsync()
    {
        if (_loaded) return;
        await RunAsync(async () =>
        {
            _groupId = await _state.EnsureGroupAsync() ?? throw new ValidationException("Create a group first.");
            FundTransaction? existing = null;
            if (_id is not null)
            {
                existing = await _fund.GetFundEntryAsync(_id) ?? throw new ValidationException("This entry no longer exists.");
                if (existing.Kind is not (FundTransactionType.Refund or FundTransactionType.Adjustment))
                    throw new ValidationException("Open contributions and fund expenses from their own screens.");
                _groupId = existing.GroupId;
                Type = existing.Kind;
                IsEditing = true;
            }

            if (IsAdjustment) FriendOptions.Add(new PickerOption("", "— None —"));
            foreach (var m in await _friends.GetMembersAsync(_groupId))
                if (m.IsActive || m.FriendId == existing?.FriendId)
                    FriendOptions.Add(new PickerOption(m.FriendId, m.Name));

            if (existing is not null)
            {
                SelectedFriend = FriendOptions.FirstOrDefault(f => f.Id == (existing.FriendId ?? ""));
                AmountText = Money.ToInput(Math.Abs(existing.AmountPaisa));
                DirectionIndex = existing.AmountPaisa > 0 ? 1 : 0;
                Date = existing.Date;
                Notes = existing.Notes ?? "";
            }
            else if (IsAdjustment)
            {
                SelectedFriend = FriendOptions.FirstOrDefault();
            }
            BalanceInfo = "Current fund balance: " + Money.Format(await _fund.GetBalanceAsync(_groupId));
            _loaded = true;
        });
    }

    private async Task SaveAsync()
    {
        if (_groupId is null) return;
        if (!Money.TryParse(AmountText, out var amount, out var err)) { await Dialogs.AlertAsync("Please check", err!); return; }
        if (IsRefund && SelectedFriend is null) { await Dialogs.AlertAsync("Please check", "Select who receives the refund."); return; }

        var draft = new FundEntryDraft
        {
            Id = _id,
            GroupId = _groupId,
            Type = Type,
            AmountPaisa = amount,
            IsIncrease = IsAdjustment && DirectionIndex == 1,
            FriendId = string.IsNullOrEmpty(SelectedFriend?.Id) ? null : SelectedFriend!.Id,
            Date = Date,
            Notes = Notes
        };
        if (await RunAsync(() => _fund.SaveFundEntryAsync(draft)))
        {
            await Dialogs.ToastAsync("Saved");
            await _navigation.GoBackAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (_id is null) return;
        if (!await Dialogs.ConfirmAsync("Delete entry?", "This entry will be permanently deleted and the fund balance recalculated.", "Delete", "Cancel")) return;
        if (await RunAsync(() => _fund.DeleteFundEntryAsync(_id)))
        {
            await Dialogs.ToastAsync("Entry deleted");
            await _navigation.GoBackAsync();
        }
    }
}
