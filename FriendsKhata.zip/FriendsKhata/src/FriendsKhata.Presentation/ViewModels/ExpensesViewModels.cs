using System.Collections.ObjectModel;
using System.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using FriendsKhata.Core.Common;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Services;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.Items;

namespace FriendsKhata.Presentation.ViewModels;

/// <summary>Reusable date filter: All / This week / This month / Last month / Custom.</summary>
public sealed class DateRangeFilter : ObservableObject
{
    public IReadOnlyList<string> Options { get; } = new[] { "All dates", "This week", "This month", "Last month", "Custom range" };

    private int _selectedIndex;
    public int SelectedIndex
    {
        get => _selectedIndex;
        set { if (SetProperty(ref _selectedIndex, value < 0 ? 0 : value)) OnPropertyChanged(nameof(IsCustom)); }
    }

    public bool IsCustom => SelectedIndex == 4;

    private DateTime _from = DateTime.Today.AddDays(-30);
    public DateTime From { get => _from; set => SetProperty(ref _from, value); }

    private DateTime _to = DateTime.Today;
    public DateTime To { get => _to; set => SetProperty(ref _to, value); }

    public (DateTime? From, DateTime? To) Resolve(DateTime today)
    {
        switch (SelectedIndex)
        {
            case 1: { var p = ReportPeriod.WeekOf(today); return (p.Start, p.End); }
            case 2: { var p = ReportPeriod.MonthOf(today); return (p.Start, p.End); }
            case 3: { var p = ReportPeriod.MonthOf(today).Previous(); return (p.Start, p.End); }
            case 4:
                Guard.Require(From.Date <= To.Date, "The start date must be on or before the end date.");
                return (From.Date, To.Date);
            default: return (null, null);
        }
    }
}

public sealed class ExpensesViewModel : GroupViewModel
{
    private readonly IExpenseService _expenses;
    private readonly IFriendService _friends;
    private readonly ICategoryService _categories;
    private bool _loadingFilters;

    public ExpensesViewModel(IExpenseService expenses, IFriendService friends, ICategoryService categories,
        AppState state, INavigationService navigation, IDialogService dialogs) : base(state, navigation, dialogs)
    {
        _expenses = expenses;
        _friends = friends;
        _categories = categories;
        Title = "Expenses";

        AddCommand = new AsyncRelayCommand(AddAsync);
        OpenCommand = new AsyncRelayCommand<ExpenseRow>(r => r is null ? Task.CompletedTask
            : Navigation.GoToAsync(Routes.ExpenseEditor, new Dictionary<string, object> { [NavKeys.Id] = r.Id }));
        ApplyFiltersCommand = new AsyncRelayCommand(() => RunAsync(ReloadListAsync));
        ClearFiltersCommand = new AsyncRelayCommand(ClearFiltersAsync);
        ToggleFiltersCommand = new RelayCommand(() => ShowFilters = !ShowFilters);
        RefreshCommand = new AsyncRelayCommand(async () => { await OnAppearingAsync(); IsRefreshing = false; });

        Range.PropertyChanged += OnFilterChanged;
    }

    public IAsyncRelayCommand AddCommand { get; }
    public IAsyncRelayCommand<ExpenseRow> OpenCommand { get; }
    public IAsyncRelayCommand ApplyFiltersCommand { get; }
    public IAsyncRelayCommand ClearFiltersCommand { get; }
    public IRelayCommand ToggleFiltersCommand { get; }
    public IAsyncRelayCommand RefreshCommand { get; }

    public DateRangeFilter Range { get; } = new();
    public ObservableCollection<ExpenseRow> Expenses { get; } = new();
    public ObservableCollection<PickerOption> FriendOptions { get; } = new();
    public ObservableCollection<PickerOption> CategoryOptions { get; } = new();
    public IReadOnlyList<string> SourceOptions { get; } = new[] { "All sources", "Personal payments", "Group fund" };

    private string _search = "";
    public string Search
    {
        get => _search;
        set { if (SetProperty(ref _search, value)) _ = RunAsync(ReloadListAsync, showBusy: false); }
    }

    private PickerOption? _selectedFriend, _selectedCategory;
    public PickerOption? SelectedFriend
    {
        get => _selectedFriend;
        set { if (SetProperty(ref _selectedFriend, value) && !_loadingFilters) _ = RunAsync(ReloadListAsync, showBusy: false); }
    }
    public PickerOption? SelectedCategory
    {
        get => _selectedCategory;
        set { if (SetProperty(ref _selectedCategory, value) && !_loadingFilters) _ = RunAsync(ReloadListAsync, showBusy: false); }
    }

    private int _sourceIndex;
    public int SourceIndex
    {
        get => _sourceIndex;
        set { if (SetProperty(ref _sourceIndex, value < 0 ? 0 : value) && !_loadingFilters) _ = RunAsync(ReloadListAsync, showBusy: false); }
    }

    private bool _showFilters, _isRefreshing, _isEmpty;
    public bool ShowFilters { get => _showFilters; set => SetProperty(ref _showFilters, value); }
    public bool IsRefreshing { get => _isRefreshing; set => SetProperty(ref _isRefreshing, value); }
    public bool IsEmpty { get => _isEmpty; set => SetProperty(ref _isEmpty, value); }

    private string _summary = "", _emptyText = "";
    public string Summary { get => _summary; set => SetProperty(ref _summary, value); }
    public string EmptyText { get => _emptyText; set => SetProperty(ref _emptyText, value); }

    protected override async Task LoadAsync(string groupId)
    {
        _loadingFilters = true;
        try
        {
            var keepFriend = SelectedFriend?.Id;
            var keepCategory = SelectedCategory?.Id;

            FriendOptions.Clear();
            FriendOptions.Add(new PickerOption("", "All friends"));
            foreach (var m in await _friends.GetMembersAsync(groupId)) FriendOptions.Add(new PickerOption(m.FriendId, m.Name));

            CategoryOptions.Clear();
            CategoryOptions.Add(new PickerOption("", "All categories"));
            foreach (var c in await _categories.GetAllAsync()) CategoryOptions.Add(new PickerOption(c.Id, $"{c.Icon} {c.Name}"));

            SelectedFriend = FriendOptions.FirstOrDefault(f => f.Id == keepFriend) ?? FriendOptions[0];
            SelectedCategory = CategoryOptions.FirstOrDefault(c => c.Id == keepCategory) ?? CategoryOptions[0];
        }
        finally
        {
            _loadingFilters = false;
        }
        await ReloadListAsync();
    }

    protected override void ClearData()
    {
        Expenses.Clear();
        IsEmpty = true;
        EmptyText = "Create a group to start recording expenses.";
        Summary = "";
    }

    private async Task ReloadListAsync()
    {
        if (GroupId is null) return;
        var (from, to) = Range.Resolve(DateTime.Today);
        var filter = new ExpenseFilter
        {
            From = from,
            To = to,
            Search = Search,
            FriendId = string.IsNullOrEmpty(SelectedFriend?.Id) ? null : SelectedFriend!.Id,
            CategoryId = string.IsNullOrEmpty(SelectedCategory?.Id) ? null : SelectedCategory!.Id,
            Source = SourceIndex switch { 1 => PaymentSource.Personal, 2 => PaymentSource.GroupFund, _ => null }
        };

        var items = await _expenses.GetExpensesAsync(GroupId, filter);
        DashboardViewModel.Replace(Expenses, items.Select(i => new ExpenseRow(i, OpenCommand)));

        var total = items.Sum(i => i.Expense.AmountPaisa);
        Summary = $"{items.Count} expense{(items.Count == 1 ? "" : "s")} • Total {Money.Format(total)}";
        IsEmpty = items.Count == 0;
        var filtered = Range.SelectedIndex != 0 || !string.IsNullOrWhiteSpace(Search) || SourceIndex != 0
                       || !string.IsNullOrEmpty(SelectedFriend?.Id) || !string.IsNullOrEmpty(SelectedCategory?.Id);
        EmptyText = filtered ? "No expenses match these filters." : "No expenses yet. Tap + to add the first one.";
    }

    private void OnFilterChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(DateRangeFilter.SelectedIndex) && !Range.IsCustom)
            _ = RunAsync(ReloadListAsync, showBusy: false);
    }

    private async Task ClearFiltersAsync()
    {
        _loadingFilters = true;
        Range.SelectedIndex = 0;
        _search = "";
        OnPropertyChanged(nameof(Search));
        SourceIndex = 0;
        SelectedFriend = FriendOptions.FirstOrDefault();
        SelectedCategory = CategoryOptions.FirstOrDefault();
        _loadingFilters = false;
        await RunAsync(ReloadListAsync);
    }

    private async Task AddAsync()
    {
        if (await RequireGroupAsync() is null) return;
        if (FriendOptions.Count <= 1)
        {
            await Dialogs.AlertAsync("Add friends first", "Add the friends of this group before recording expenses.");
            return;
        }
        await Navigation.GoToAsync(Routes.ExpenseEditor);
    }
}

public sealed class ExpenseEditorViewModel : BaseViewModel
{
    private readonly IExpenseService _expenses;
    private readonly IFriendService _friends;
    private readonly ICategoryService _categories;
    private readonly IFundService _fund;
    private readonly AppState _state;
    private readonly INavigationService _navigation;
    private string? _expenseId;
    private string? _groupId;
    private long _fundAvailablePaisa;
    private bool _loaded;
    private bool _suspendPreview;

    public ExpenseEditorViewModel(IExpenseService expenses, IFriendService friends, ICategoryService categories, IFundService fund,
        AppState state, INavigationService navigation, IDialogService dialogs) : base(dialogs)
    {
        _expenses = expenses;
        _friends = friends;
        _categories = categories;
        _fund = fund;
        _state = state;
        _navigation = navigation;
        Title = "Add Expense";

        SaveCommand = new AsyncRelayCommand(SaveAsync);
        DeleteCommand = new AsyncRelayCommand(DeleteAsync);
        SelectAllCommand = new RelayCommand(() => SetAll(true));
        SelectNoneCommand = new RelayCommand(() => SetAll(false));
        SplitEvenlyCommand = new RelayCommand(FillEvenly);
    }

    public IAsyncRelayCommand SaveCommand { get; }
    public IAsyncRelayCommand DeleteCommand { get; }
    public IRelayCommand SelectAllCommand { get; }
    public IRelayCommand SelectNoneCommand { get; }
    public IRelayCommand SplitEvenlyCommand { get; }

    public ObservableCollection<PickerOption> CategoryOptions { get; } = new();
    public ObservableCollection<PickerOption> PayerOptions { get; } = new();
    public ObservableCollection<ParticipantRow> Participants { get; } = new();
    public IReadOnlyList<string> SourceOptions { get; } = new[] { "Personal money (a friend paid)", "Group fund" };
    public IReadOnlyList<string> SplitOptions { get; } = new[] { "Split equally", "Custom amount per friend", "Custom percentage per friend" };

    private string _expenseTitle = "", _amountText = "", _notes = "", _preview = "", _previewError = "", _fundInfo = "";
    public string ExpenseTitle { get => _expenseTitle; set => SetProperty(ref _expenseTitle, value); }
    public string AmountText { get => _amountText; set { if (SetProperty(ref _amountText, value)) UpdatePreview(); } }
    public string Notes { get => _notes; set => SetProperty(ref _notes, value); }
    public string Preview { get => _preview; set => SetProperty(ref _preview, value); }
    public string PreviewError
    {
        get => _previewError;
        set { if (SetProperty(ref _previewError, value)) OnPropertyChanged(nameof(HasPreviewError)); }
    }
    public bool HasPreviewError => !string.IsNullOrEmpty(PreviewError);
    public string FundInfo { get => _fundInfo; set => SetProperty(ref _fundInfo, value); }

    private DateTime _date = DateTime.Today;
    public DateTime Date { get => _date; set => SetProperty(ref _date, value); }

    private PickerOption? _selectedCategory, _selectedPayer;
    public PickerOption? SelectedCategory { get => _selectedCategory; set => SetProperty(ref _selectedCategory, value); }
    public PickerOption? SelectedPayer { get => _selectedPayer; set { if (SetProperty(ref _selectedPayer, value)) UpdatePreview(); } }

    private int _sourceIndex;
    public int SourceIndex
    {
        get => _sourceIndex;
        set
        {
            if (!SetProperty(ref _sourceIndex, value < 0 ? 0 : value)) return;
            OnPropertyChanged(nameof(IsPersonal));
            OnPropertyChanged(nameof(IsFund));
            OnPropertyChanged(nameof(PayerLabel));
            UpdatePreview();
        }
    }

    public bool IsPersonal => SourceIndex == 0;
    public bool IsFund => SourceIndex == 1;
    public string PayerLabel => IsPersonal ? "Paid by" : "Handled by (optional)";

    private int _splitIndex;
    public int SplitIndex
    {
        get => _splitIndex;
        set
        {
            if (!SetProperty(ref _splitIndex, value < 0 ? 0 : value)) return;
            OnPropertyChanged(nameof(IsEqualSplit));
            foreach (var p in Participants)
            {
                p.ShowAmount = Split == SplitMethod.CustomAmount;
                p.ShowPercent = Split == SplitMethod.Percentage;
            }
            UpdatePreview();
        }
    }

    public SplitMethod Split => SplitIndex switch { 1 => SplitMethod.CustomAmount, 2 => SplitMethod.Percentage, _ => SplitMethod.Equal };
    public bool IsEqualSplit => Split == SplitMethod.Equal;

    private bool _isEditing;
    public bool IsEditing { get => _isEditing; set => SetProperty(ref _isEditing, value); }

    public override void ApplyParameters(IDictionary<string, object> parameters)
        => _expenseId = Param(parameters, NavKeys.Id);

    public override async Task OnAppearingAsync()
    {
        if (_loaded) return;
        await RunAsync(LoadAsync);
    }

    private async Task LoadAsync()
    {
        _groupId = await _state.EnsureGroupAsync() ?? throw new ValidationException("Create a group first.");
        _suspendPreview = true;

        ExpenseDetails? existing = null;
        if (_expenseId is not null)
        {
            existing = await _expenses.GetAsync(_expenseId) ?? throw new ValidationException("This expense no longer exists.");
            _groupId = existing.Expense.GroupId;
            IsEditing = true;
            Title = "Edit Expense";
        }

        var involved = existing is null
            ? new HashSet<string>()
            : existing.Participants.Select(p => p.FriendId).Append(existing.Expense.PaidByFriendId ?? "").ToHashSet();

        // Active members, plus inactive ones that are already part of this expense.
        var members = (await _friends.GetMembersAsync(_groupId)).Where(m => m.IsActive || involved.Contains(m.FriendId)).ToList();

        foreach (var c in await _categories.GetAllAsync()) CategoryOptions.Add(new PickerOption(c.Id, $"{c.Icon}  {c.Name}"));

        PayerOptions.Add(new PickerOption("", "— Not specified —"));
        foreach (var m in members) PayerOptions.Add(new PickerOption(m.FriendId, m.Name));

        foreach (var m in members)
        {
            var row = new ParticipantRow(m.FriendId, m.Name, m.IsActive) { IsSelected = existing is null };
            row.PropertyChanged += OnParticipantChanged;
            Participants.Add(row);
        }

        _fundAvailablePaisa = await _fund.GetBalanceAsync(_groupId);

        if (existing is not null)
        {
            var e = existing.Expense;
            ExpenseTitle = e.Title;
            AmountText = Money.ToInput(e.AmountPaisa);
            Notes = e.Notes ?? "";
            Date = e.Date;
            SelectedCategory = CategoryOptions.FirstOrDefault(c => c.Id == e.CategoryId);
            SourceIndex = e.IsFundExpense ? 1 : 0;
            SelectedPayer = PayerOptions.FirstOrDefault(p => p.Id == (e.PaidByFriendId ?? "")) ?? PayerOptions[0];
            SplitIndex = e.Split switch { SplitMethod.CustomAmount => 1, SplitMethod.Percentage => 2, _ => 0 };
            if (e.IsFundExpense) _fundAvailablePaisa += e.AmountPaisa; // its own deduction is given back while editing

            foreach (var p in existing.Participants)
            {
                var row = Participants.FirstOrDefault(r => r.FriendId == p.FriendId);
                if (row is null) continue;
                row.IsSelected = true;
                row.AmountText = Money.ToInput(p.ShareAmountPaisa);
                row.PercentText = p.SharePercentBp is { } bp ? (bp / 100m).ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) : "";
            }
        }
        else
        {
            SelectedCategory = CategoryOptions.FirstOrDefault();
            SelectedPayer = PayerOptions.Count > 1 ? PayerOptions[1] : PayerOptions[0];
        }

        foreach (var p in Participants)
        {
            p.ShowAmount = Split == SplitMethod.CustomAmount;
            p.ShowPercent = Split == SplitMethod.Percentage;
        }

        _suspendPreview = false;
        _loaded = true;
        UpdatePreview();
    }

    private void OnParticipantChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(ParticipantRow.IsSelected) or nameof(ParticipantRow.AmountText) or nameof(ParticipantRow.PercentText))
            UpdatePreview();
    }

    private void SetAll(bool selected)
    {
        _suspendPreview = true;
        foreach (var p in Participants) p.IsSelected = selected;
        _suspendPreview = false;
        UpdatePreview();
    }

    /// <summary>Fills custom amount / percentage boxes with an even split as a starting point.</summary>
    private void FillEvenly()
    {
        var selected = Participants.Where(p => p.IsSelected).ToList();
        if (selected.Count == 0) return;
        _suspendPreview = true;
        if (Split == SplitMethod.CustomAmount && Money.TryParse(AmountText, out var total, out _) && total > 0)
        {
            var shares = SplitCalculator.Calculate(total, SplitMethod.Equal, selected.Select(s => new SplitInput(s.FriendId)).ToList());
            foreach (var s in shares) selected.First(r => r.FriendId == s.FriendId).AmountText = Money.ToInput(s.SharePaisa);
        }
        else if (Split == SplitMethod.Percentage)
        {
            var bps = SplitCalculator.Calculate(10000, SplitMethod.Equal, selected.Select(s => new SplitInput(s.FriendId)).ToList());
            foreach (var s in bps)
                selected.First(r => r.FriendId == s.FriendId).PercentText = (s.SharePaisa / 100m).ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        }
        _suspendPreview = false;
        UpdatePreview();
    }

    /// <summary>Builds participants for the calculator. Returns null and an error message when input is incomplete.</summary>
    private (List<SplitInput>? Inputs, string? Error) BuildInputs()
    {
        var list = new List<SplitInput>();
        foreach (var p in Participants.Where(p => p.IsSelected))
        {
            switch (Split)
            {
                case SplitMethod.CustomAmount:
                    if (string.IsNullOrWhiteSpace(p.AmountText)) { list.Add(new SplitInput(p.FriendId, 0)); break; }
                    if (!Money.TryParse(p.AmountText, out var paisa, out var err)) return (null, $"{p.Name}: {err}");
                    list.Add(new SplitInput(p.FriendId, paisa));
                    break;
                case SplitMethod.Percentage:
                    if (string.IsNullOrWhiteSpace(p.PercentText)) { list.Add(new SplitInput(p.FriendId, Percent: 0)); break; }
                    if (!decimal.TryParse(p.PercentText.Replace("%", "").Trim(), System.Globalization.NumberStyles.AllowDecimalPoint,
                            System.Globalization.CultureInfo.InvariantCulture, out var pct))
                        return (null, $"{p.Name}: enter a valid percentage.");
                    list.Add(new SplitInput(p.FriendId, Percent: pct));
                    break;
                default:
                    list.Add(new SplitInput(p.FriendId));
                    break;
            }
        }
        return (list, null);
    }

    private void UpdatePreview()
    {
        if (_suspendPreview) return;
        foreach (var p in Participants) p.ShareText = "";
        FundInfo = IsFund ? $"Available in group fund: {Money.Format(_fundAvailablePaisa)}" : "";

        if (!Money.TryParse(AmountText, out var total, out _) || total <= 0)
        {
            Preview = "Enter the amount to see each friend's share.";
            PreviewError = "";
            return;
        }

        var (inputs, error) = BuildInputs();
        if (inputs is null) { Preview = ""; PreviewError = error!; return; }

        try
        {
            var shares = SplitCalculator.Calculate(total, Split, inputs);
            foreach (var s in shares) Participants.First(p => p.FriendId == s.FriendId).ShareText = Money.Format(s.SharePaisa);
            PreviewError = "";

            if (IsFund)
            {
                Preview = $"{Money.Format(total)} will be deducted from the group fund once. Balance after: {Money.Format(_fundAvailablePaisa - total)}.";
                if (total > _fundAvailablePaisa) PreviewError = "The group fund does not have enough money for this expense.";
            }
            else if (!string.IsNullOrEmpty(SelectedPayer?.Id))
            {
                var own = shares.FirstOrDefault(s => s.FriendId == SelectedPayer!.Id)?.SharePaisa ?? 0;
                Preview = $"{SelectedPayer!.Name} paid {Money.Format(total)} • own share {Money.Format(own)} • " +
                          $"recoverable from others {Money.Format(total - own)}";
            }
            else
            {
                Preview = "Select who paid.";
            }
        }
        catch (ValidationException ex)
        {
            Preview = "";
            PreviewError = ex.Message;
        }
    }

    private async Task SaveAsync()
    {
        if (_groupId is null) return;

        if (!Money.TryParse(AmountText, out var amount, out var amountError))
        {
            await Dialogs.AlertAsync("Please check", amountError!);
            return;
        }
        var (inputs, error) = BuildInputs();
        if (inputs is null)
        {
            await Dialogs.AlertAsync("Please check", error!);
            return;
        }

        var draft = new ExpenseDraft
        {
            Id = _expenseId,
            GroupId = _groupId,
            Title = ExpenseTitle,
            AmountPaisa = amount,
            CategoryId = SelectedCategory?.Id ?? "",
            Date = Date,
            Source = IsFund ? PaymentSource.GroupFund : PaymentSource.Personal,
            PaidByFriendId = string.IsNullOrEmpty(SelectedPayer?.Id) ? null : SelectedPayer!.Id,
            Split = Split,
            Participants = inputs,
            Notes = Notes
        };

        if (await RunAsync(() => _expenses.SaveAsync(draft)))
        {
            await Dialogs.ToastAsync(IsEditing ? "Expense updated" : "Expense saved");
            await _navigation.GoBackAsync();
        }
    }

    private async Task DeleteAsync()
    {
        if (_expenseId is null) return;
        var extra = IsFund ? " The amount will be returned to the group fund." : " Balances will be recalculated.";
        if (!await Dialogs.ConfirmAsync("Delete expense?", $"\"{ExpenseTitle}\" will be permanently deleted.{extra}", "Delete", "Cancel"))
            return;
        if (await RunAsync(() => _expenses.DeleteAsync(_expenseId)))
        {
            await Dialogs.ToastAsync("Expense deleted");
            await _navigation.GoBackAsync();
        }
    }
}
