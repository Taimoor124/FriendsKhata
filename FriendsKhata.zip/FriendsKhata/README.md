# Friends Khata – Group Expense & Fund Management (Android, .NET MAUI)

An offline Android app for a group of friends to track shared expenses, a common group fund,
personal payments and settlements. It replaces a manual Notepad khata with automatic
balances, weekly/monthly reports and "who pays whom" suggestions.

* .NET 8 (`net8.0-android`), .NET MAUI, XAML, C#
* MVVM with CommunityToolkit.Mvvm, dependency injection, Repository + Service layers
* SQLite (sqlite-net-pcl), fully offline – no internet permission needed for any feature
* Currency PKR (Rs), English UI

---

## 1. Open and run in Visual Studio 2022

**Prerequisites (one-time)**

1. Visual Studio 2022 **17.8 or newer** with the workload **".NET Multi-platform App UI development"**
   (Visual Studio Installer → Modify → Workloads). This installs the Android SDK, a Java JDK
   and the Android emulator.
2. The **.NET 8 SDK** (installed with the workload; check with `dotnet --list-sdks`).
3. An Android emulator (Tools → Android → Android Device Manager) **or** a phone with
   *Developer options → USB debugging* enabled.

**Run**

1. Open `FriendsKhata.sln`.
2. Right-click **FriendsKhata.App** → *Set as Startup Project* (it is the first project, so it usually already is).
3. Pick your emulator/phone in the run target drop-down and press **F5**.
   The first build downloads the NuGet packages (internet needed once, the app itself never needs it).

**Run the unit tests**

*Test → Test Explorer → Run All* (or `dotnet test tests/FriendsKhata.Tests`). The tests need no
emulator: they use a real SQLite file in a temp folder.

## 2. Build the installable APK

From a *Developer PowerShell* in the solution folder:

```powershell
dotnet publish src\FriendsKhata.App\FriendsKhata.App.csproj -f net8.0-android -c Release
```

or in Visual Studio: switch to **Release**, right-click **FriendsKhata.App → Publish… → Ad hoc**.

The project is configured to produce an `.apk` (not `.aab`) in Release, and a build step copies it to:

```
Output\FriendsKhata.apk
```

Copy that file to the phone and open it (allow "Install unknown apps" for your file manager).
It is signed with the Visual Studio debug key, which is fine for installing on your own phones.
For the Play Store, create your own keystore (Publish → *Distribute* → *Create new signing identity*).

### About the APK (why none is included)

The source was written and verified in a sandbox that **could not build Android**:

| Needed for the APK | Status in that sandbox |
|---|---|
| .NET 8 SDK | ✅ available (Ubuntu package 8.0.134) |
| NuGet packages (`api.nuget.org`) – MAUI, sqlite-net, toolkits | ❌ blocked by the network allow-list (HTTP 403) |
| .NET MAUI / Android workload (`dotnet workload install maui-android`, Microsoft download servers) | ❌ blocked (HTTP 403) |
| Android SDK platform 34 + build-tools (`dl.google.com`, `maven.google.com`) | ❌ blocked (HTTP 403) |

So instead of a fake APK, this delivery has the full source, and the APK is one command away on a
machine with Visual Studio (see above).

## 3. What was verified before delivery

Even without the Android toolchain, everything except the MAUI shell was compiled and run:

* **FriendsKhata.Core** (financial engine, schema, repositories, services) – built with the .NET 8 SDK, 0 warnings.
* **FriendsKhata.Data** – compiled together with the original sqlite-net source against the real SQLite library.
* **FriendsKhata.Presentation** (all ViewModels) – compiled against CommunityToolkit.Mvvm built from its source, 0 warnings.
* **52 tests passed** – every test in `tests/FriendsKhata.Tests` (calculations, real-SQLite service tests,
  backup/restore, CSV, and a full end-to-end scenario through the ViewModels).
* **XAML** – all files well-formed; a static checker validated all 433 `{Binding}` paths against the
  ViewModel types (`x:DataType`), two-way bindings against writable properties, every `StaticResource`
  key, style target types and code-behind classes.

What could **not** be checked there: the MAUI XAML compiler (XamlC), the Android build itself and running on a
device. If Visual Studio reports anything on first build, it will be in `src/FriendsKhata.App` (pages,
`MauiProgram.cs`, `Services/PlatformServices.cs`) – the logic underneath is tested.

## 4. Solution structure

```
FriendsKhata.sln
├─ src/
│  ├─ FriendsKhata.Core/           no dependencies – pure C#
│  │  ├─ Common/                   Money (paisa), dates, validation
│  │  ├─ Models/                   entities + enums
│  │  ├─ Data/                     IDatabase abstraction, Migrations, StoragePaths
│  │  ├─ Finance/                  SplitCalculator, BalanceCalculator, FundCalculator,
│  │  │                            SettlementOptimizer, ReportPeriod, Reports/Dashboard builders
│  │  ├─ Repositories/             all SQL
│  │  └─ Services/                 business rules + transactions (expense, fund, settlement, …)
│  ├─ FriendsKhata.Data/           SQLite implementation (sqlite-net-pcl) + BackupService
│  ├─ FriendsKhata.Presentation/   ViewModels, display rows, navigation/dialog interfaces
│  └─ FriendsKhata.App/            .NET MAUI app: Shell, XAML pages, styles, Android platform
├─ tests/FriendsKhata.Tests/       xUnit tests
└─ Output/                         FriendsKhata.apk is copied here by the Release build
```

ViewModels don't reference MAUI. Navigation, dialogs, file pickers and preferences are small
interfaces (`Presentation/Abstractions`) implemented in `App/Services/PlatformServices.cs`.
That is why the ViewModels can be tested without a phone.

## 5. Database design

The SQLite file is `friendskhata.db3` in `FileSystem.AppDataDirectory` (the app's private data folder,
**not** the cache, so "Clear cache" does not delete it). `PRAGMA foreign_keys = ON` is set on every connection.

| Table | Purpose | Key points |
|---|---|---|
| `Groups` | University Friends, Office Friends… | GUID PK, unique name (case-insensitive) |
| `Friends` | A person | GUID PK; can belong to several groups |
| `GroupMembers` | Friend ↔ group | Joining date + Active/Inactive status per group, `UNIQUE(GroupId, FriendId)` |
| `Categories` | Food, Petrol, Tea… + custom | 10 built-in categories seeded by migration 1 |
| `Expenses` | One bill | Amount, category, date, payer, `PaymentSource` (1 Personal / 2 Group fund), split method; CHECK: personal ⇒ payer required |
| `ExpenseParticipants` | Each friend's share | Share in paisa (+ % for percentage splits), `UNIQUE(ExpenseId, FriendId)`, cascade with expense |
| `FundContributions` | Money given into the fund | Partial/extra contributions are just more rows |
| `FundTransactions` | **The fund ledger** – every fund movement | Signed amount; fund balance = `SUM(AmountPaisa)`. `ContributionId` and `ExpenseId` are **UNIQUE**, so one expense can never be deducted twice. CHECK constraints per type (contribution +, expense −, refund −, adjustment ±) |
| `Settlements` | Friend A paid friend B | CHECK sender ≠ receiver, amount > 0 |
| `SchemaVersion`, `AppMeta` | Migrations + backup identification | |

**Money is stored as INTEGER paisa** (Rs 1,250.75 = 125075), so decimals are exact and nothing is lost to rounding.
Dates are ISO text (`yyyy-MM-dd`), so weekly and monthly ranges compare correctly.

**Migrations.** `Core/Data/Migrations.cs` holds numbered migrations. When the database opens, the runner
applies every migration newer than `SchemaVersion` inside one transaction. To change the schema later,
**add** `new Migration(2, "…", new[] { "ALTER TABLE …" })`. Never edit a migration that has already shipped.
Restored backups from older versions are upgraded automatically.

## 6. Financial rules (how the numbers are calculated)

Balances are **never stored**. Every screen recalculates them from the transactions, so editing or
deleting any record automatically corrects every total.

1. **Two separate ledgers.** *Personal* (who owes whom) uses only personally-paid expenses and settlements.
   *Fund* uses only `FundTransactions`. Contributions are never counted as expenses.
2. **Personal balance** of a friend = paid personally − own share of personal expenses
   + settlements paid − settlements received.
   *Example:* Ali pays Rs 3,000, split equally among 5 → Ali +2,400 (recoverable), each other friend −600.
   The sum of all balances is always exactly 0.
3. **Fund balance** = contributions − fund expenses − refunds ± adjustments. A fund expense can't be saved
   if the fund doesn't have enough money, and a contribution can't be deleted or reduced once that money is spent.
4. **Each friend's share in the fund** = contributed − own share of fund expenses − refunds received.
   The sum of all shares (+ unallocated adjustments) always equals the fund balance.
5. **Splits** (equal among all or selected friends, custom amount, custom %) are calculated in paisa. Leftover paisa
   are distributed so the shares always add up to the exact bill (Rs 100 / 3 = 33.34 + 33.33 + 33.33).
   Custom amounts must equal the total. Percentages must equal exactly 100%.
6. **Editing/deleting** runs in one database transaction: the old shares and fund deduction are removed, then the
   new ones are written. If anything fails, nothing changes.
7. **Settlement suggestions** use an exact minimum-payments algorithm (bitmask dynamic programming for up to 16
   people with a balance, greedy beyond that). It finds independent sub-groups that settle among themselves,
   so it can need fewer payments than the usual "largest debtor pays largest creditor" rule.
8. **Refunds** (fund → friend) and **adjustments** (cash-count difference, bank charges) are separate fund entries,
   shown in history and reports.
9. **Reports:** weeks run Monday–Sunday, months from the 1st to the last day, plus custom ranges, all
   inclusive. Opening fund balance = everything before the start date; closing = everything up to the end date.

## 7. Features by screen

* **Dashboard** – group switcher, available fund, the totals you listed (expenses, personal payments, fund,
  contributions, outstanding, this month, this week), friends' balances, category breakdown for the month,
  recent expenses and transactions, quick actions (Add Expense / Contribution / Settlement, Reports, Friends).
* **Expenses** – search; filters by date (week, month, last month, custom), friend, category and payment source;
  add/edit/delete with live share preview; confirmation before delete.
* **Group Fund** – balance, collected/spent/refunded, each friend's contribution and share, full fund history with
  running balance, contributions (partial allowed), refunds, adjustments.
* **Friends** – search, active/inactive, balances. Add new or existing friends (from other groups) and edit them.
  Delete is only allowed with no records, otherwise the app offers to deactivate. Each friend has a summary page
  with personal, fund, suggestions and activity.
* **More** – Reports (weekly/monthly/custom, CSV export), Balances & settlements (suggestions with one-tap
  "Record"), Transaction history (type + date filters, CSV export), Groups, Categories (custom, emoji icon),
  Backup & restore.

**Backup/restore.** Export uses `VACUUM INTO` (a consistent copy) and the system "Save as" dialog, so you
choose where it goes. Restore checks the file is a valid Friends Khata database (header, marker table, schema version,
integrity check). It shows what the backup contains and asks for confirmation. It also keeps an automatic
safety copy of the current data (last 5) before replacing anything.

**CSV export** is UTF-8 with BOM and opens directly in Excel. Values are escaped, including protection against formula injection.

## 8. NuGet packages

| Project | Package | Version |
|---|---|---|
| App | Microsoft.Maui.Controls | 8.0.100 (last .NET 8 release) |
| App | CommunityToolkit.Maui (FileSaver, Toast) | 9.1.1 |
| App, Presentation | CommunityToolkit.Mvvm | 8.2.2 |
| App, Data | sqlite-net-pcl / SQLitePCLRaw.bundle_green | 1.9.172 / 2.1.10 |
| App | Microsoft.Extensions.Logging.Debug | 8.0.1 |
| Tests | xunit / xunit.runner.visualstudio / Microsoft.NET.Test.Sdk | 2.9.2 / 2.8.2 / 17.11.1 |

> Note: Microsoft ended support for .NET MAUI 8 in May 2025. The project targets .NET 8 as you asked and
> builds fine with the .NET 8 workload. To move to .NET 9 later, change `net8.0-android` → `net9.0-android`,
> `net8.0` → `net9.0`, and update Microsoft.Maui.Controls to 9.x and CommunityToolkit.Maui to 10+/11+.
