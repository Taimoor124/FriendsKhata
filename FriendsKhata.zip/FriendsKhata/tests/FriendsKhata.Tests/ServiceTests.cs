using FriendsKhata.Core.Common;
using FriendsKhata.Core.Data;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;
using FriendsKhata.Core.Repositories;
using FriendsKhata.Core.Services;
using FriendsKhata.Data;

namespace FriendsKhata.Tests;

/// <summary>A real SQLite database in a temp folder, wired exactly like the app does it.</summary>
public sealed class TestEnvironment : IDisposable
{
    public string Folder { get; } = Path.Combine(Path.GetTempPath(), "fk-tests-" + Guid.NewGuid().ToString("N"));
    public StoragePaths Paths { get; }
    public SqliteDatabase Db { get; }
    public IGroupService Groups { get; }
    public IFriendService Friends { get; }
    public ICategoryService Categories { get; }
    public IExpenseService Expenses { get; }
    public IFundService Fund { get; }
    public ISettlementService Settlements { get; }
    public IReportService Reports { get; }
    public IBackupService Backup { get; }

    public TestEnvironment()
    {
        Directory.CreateDirectory(Folder);
        Paths = new StoragePaths
        {
            DatabasePath = Path.Combine(Folder, "data", "friendskhata.db3"),
            TempDirectory = Path.Combine(Folder, "cache"),
            SafetyBackupDirectory = Path.Combine(Folder, "data", "SafetyBackups")
        };
        Db = new SqliteDatabase(Paths);
        var friendRepo = new FriendRepository(Db);
        var expenseRepo = new ExpenseRepository(Db);
        var fundRepo = new FundRepository(Db);
        var settlementRepo = new SettlementRepository(Db);
        var categoryRepo = new CategoryRepository(Db);
        var groupRepo = new GroupRepository(Db);
        var ledger = new LedgerRepository(friendRepo, expenseRepo, fundRepo, settlementRepo, categoryRepo);

        Groups = new GroupService(Db, groupRepo);
        Friends = new FriendService(Db, friendRepo, ledger);
        Categories = new CategoryService(Db, categoryRepo);
        Expenses = new ExpenseService(Db, expenseRepo, friendRepo, categoryRepo, fundRepo, ledger);
        Fund = new FundService(Db, fundRepo, friendRepo, ledger);
        Settlements = new SettlementService(Db, settlementRepo, friendRepo, ledger);
        Reports = new ReportService(ledger, groupRepo);
        Backup = new BackupService(Db, Paths);
    }

    public async Task<(string GroupId, Dictionary<string, string> Ids)> SeedGroupAsync(params string[] names)
    {
        var g = await Groups.CreateAsync("University Friends " + Guid.NewGuid().ToString("N")[..6], null);
        var ids = new Dictionary<string, string>();
        foreach (var n in names)
            ids[n] = await Friends.SaveAsync(new FriendDraft { GroupId = g.Id, Name = n, JoiningDate = new DateTime(2026, 1, 1) });
        return (g.Id, ids);
    }

    public async Task<string> FoodCategoryAsync() => (await Categories.GetAllAsync()).First().Id;

    public void Dispose()
    {
        Db.CloseAsync().GetAwaiter().GetResult();
        try { Directory.Delete(Folder, true); } catch { /* temp folder */ }
    }
}

public class ExpenseAndFundServiceTests : IDisposable
{
    private readonly TestEnvironment _env = new();
    public void Dispose() => _env.Dispose();

    private static List<SplitInput> All(Dictionary<string, string> ids) => ids.Values.Select(v => new SplitInput(v)).ToList();

    private async Task<long> NetAsync(string groupId, string friendId)
        => (await _env.Settlements.GetBalancesAsync(groupId)).First(b => b.FriendId == friendId).NetPaisa;

    [Fact]
    public async Task Personal_expense_creates_recoverable_amounts()
    {
        var (g, ids) = await _env.SeedGroupAsync("Ali", "Bilal", "Hamza", "Usman", "Zain");
        await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "Dinner", AmountPaisa = 300000, CategoryId = await _env.FoodCategoryAsync(),
            Source = PaymentSource.Personal, PaidByFriendId = ids["Ali"], Participants = All(ids)
        });

        Assert.Equal(240000, await NetAsync(g, ids["Ali"]));
        Assert.Equal(-60000, await NetAsync(g, ids["Bilal"]));
        Assert.Equal(0, await _env.Fund.GetBalanceAsync(g));
    }

    [Fact]
    public async Task Fund_expense_is_deducted_exactly_once_even_after_edits()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B", "C", "D", "E");
        foreach (var id in ids.Values)
            await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = id, AmountPaisa = 200000 });
        Assert.Equal(1000000, await _env.Fund.GetBalanceAsync(g));

        var draft = new ExpenseDraft
        {
            GroupId = g, Title = "Groceries", AmountPaisa = 300000, CategoryId = await _env.FoodCategoryAsync(),
            Source = PaymentSource.GroupFund, Participants = All(ids)
        };
        var expenseId = await _env.Expenses.SaveAsync(draft);
        Assert.Equal(700000, await _env.Fund.GetBalanceAsync(g));

        // Edit the same expense several times: the fund must reflect only the latest amount.
        draft.Id = expenseId;
        draft.AmountPaisa = 450000;
        await _env.Expenses.SaveAsync(draft);
        await _env.Expenses.SaveAsync(draft);
        Assert.Equal(550000, await _env.Fund.GetBalanceAsync(g));

        // Switch to personal payment: money goes back to the fund, personal balances appear.
        draft.Source = PaymentSource.Personal;
        draft.PaidByFriendId = ids["A"];
        await _env.Expenses.SaveAsync(draft);
        Assert.Equal(1000000, await _env.Fund.GetBalanceAsync(g));
        Assert.Equal(360000, await NetAsync(g, ids["A"]));

        // Back to fund, then delete: everything returns to the start.
        draft.Source = PaymentSource.GroupFund;
        await _env.Expenses.SaveAsync(draft);
        Assert.Equal(550000, await _env.Fund.GetBalanceAsync(g));
        Assert.Equal(0, await NetAsync(g, ids["A"]));

        await _env.Expenses.DeleteAsync(expenseId);
        Assert.Equal(1000000, await _env.Fund.GetBalanceAsync(g));
        var summary = await _env.Fund.GetSummaryAsync(g);
        Assert.Equal(summary.BalancePaisa, summary.Friends.Sum(f => f.EquityPaisa) + summary.UnallocatedAdjustmentsPaisa);
    }

    [Fact]
    public async Task Fund_cannot_go_negative()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B");
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 50000 });
        var cat = await _env.FoodCategoryAsync();

        var ex = await Assert.ThrowsAsync<ValidationException>(() => _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "Petrol", AmountPaisa = 60000, CategoryId = cat, Source = PaymentSource.GroupFund, Participants = All(ids)
        }));
        Assert.Contains("Not enough money", ex.Message);

        await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "Petrol", AmountPaisa = 40000, CategoryId = cat, Source = PaymentSource.GroupFund, Participants = All(ids)
        });

        // The spent contribution can neither be deleted nor reduced below what was spent.
        var contribution = (await _env.Fund.GetContributionsAsync(g)).Single();
        await Assert.ThrowsAsync<ValidationException>(() => _env.Fund.DeleteContributionAsync(contribution.Id));
        await Assert.ThrowsAsync<ValidationException>(() => _env.Fund.SaveContributionAsync(new ContributionDraft
        {
            Id = contribution.Id, GroupId = g, FriendId = ids["A"], AmountPaisa = 30000
        }));
        await Assert.ThrowsAsync<ValidationException>(() => _env.Fund.SaveFundEntryAsync(new FundEntryDraft
        {
            GroupId = g, Type = FundTransactionType.Refund, FriendId = ids["A"], AmountPaisa = 20000
        }));
        Assert.Equal(10000, await _env.Fund.GetBalanceAsync(g));
    }

    [Fact]
    public async Task Contribution_edit_and_partial_contributions()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B");
        var c1 = await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 100000 });
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 50050 }); // partial
        await _env.Fund.SaveContributionAsync(new ContributionDraft { Id = c1, GroupId = g, FriendId = ids["B"], AmountPaisa = 120000 });

        var s = await _env.Fund.GetSummaryAsync(g);
        Assert.Equal(170050, s.TotalCollectedPaisa);
        Assert.Equal(50050, s.Friends.First(f => f.FriendId == ids["A"]).ContributedPaisa);
        Assert.Equal(120000, s.Friends.First(f => f.FriendId == ids["B"]).ContributedPaisa);

        var ledger = await _env.Fund.GetLedgerAsync(g);
        Assert.Equal(170050, ledger.First().BalanceAfterPaisa);
    }

    [Fact]
    public async Task Refund_and_adjustment_affect_fund_correctly()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B");
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 100000 });
        var refund = await _env.Fund.SaveFundEntryAsync(new FundEntryDraft { GroupId = g, Type = FundTransactionType.Refund, FriendId = ids["A"], AmountPaisa = 30000 });
        await _env.Fund.SaveFundEntryAsync(new FundEntryDraft { GroupId = g, Type = FundTransactionType.Adjustment, IsIncrease = false, AmountPaisa = 500, Notes = "Bank charge" });
        Assert.Equal(69500, await _env.Fund.GetBalanceAsync(g));

        await _env.Fund.SaveFundEntryAsync(new FundEntryDraft { Id = refund, GroupId = g, Type = FundTransactionType.Refund, FriendId = ids["A"], AmountPaisa = 10000 });
        Assert.Equal(89500, await _env.Fund.GetBalanceAsync(g));

        await _env.Fund.DeleteFundEntryAsync(refund);
        Assert.Equal(99500, await _env.Fund.GetBalanceAsync(g));

        var history = await _env.Reports.GetTransactionsAsync(g, new TransactionFilter { Kind = TransactionKind.FundAdjustment });
        Assert.Single(history);
    }

    [Fact]
    public async Task Settlement_reduces_outstanding_and_delete_restores_it()
    {
        var (g, ids) = await _env.SeedGroupAsync("Ali", "Bilal", "Hamza");
        await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "Tea", AmountPaisa = 90000, CategoryId = await _env.FoodCategoryAsync(),
            PaidByFriendId = ids["Ali"], Participants = All(ids)
        });
        var sid = await _env.Settlements.SaveAsync(new SettlementDraft { GroupId = g, FromFriendId = ids["Bilal"], ToFriendId = ids["Ali"], AmountPaisa = 30000 });
        Assert.Equal(0, await NetAsync(g, ids["Bilal"]));
        Assert.Equal(30000, await NetAsync(g, ids["Ali"]));

        var suggestions = await _env.Settlements.GetSuggestionsAsync(g);
        Assert.Single(suggestions);
        Assert.Equal(ids["Hamza"], suggestions[0].FromFriendId);

        await _env.Settlements.DeleteAsync(sid);
        Assert.Equal(-30000, await NetAsync(g, ids["Bilal"]));

        await Assert.ThrowsAsync<ValidationException>(() => _env.Settlements.SaveAsync(
            new SettlementDraft { GroupId = g, FromFriendId = ids["Ali"], ToFriendId = ids["Ali"], AmountPaisa = 100 }));
    }

    [Fact]
    public async Task Custom_and_percentage_splits_are_stored_and_editable()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B", "C");
        var cat = await _env.FoodCategoryAsync();
        var id = await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "Hotel", AmountPaisa = 100000, CategoryId = cat, PaidByFriendId = ids["A"],
            Split = SplitMethod.Percentage,
            Participants = new() { new(ids["A"], Percent: 50), new(ids["B"], Percent: 25), new(ids["C"], Percent: 25) }
        });
        var d = await _env.Expenses.GetAsync(id);
        Assert.Equal(3, d!.Participants.Count);
        Assert.Equal(5000, d.Participants.First(p => p.FriendId == ids["A"]).SharePercentBp);
        Assert.Equal(-25000, await NetAsync(g, ids["B"]));

        await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            Id = id, GroupId = g, Title = "Hotel", AmountPaisa = 100000, CategoryId = cat, PaidByFriendId = ids["A"],
            Split = SplitMethod.CustomAmount,
            Participants = new() { new(ids["B"], 60000), new(ids["C"], 40000) }
        });
        d = await _env.Expenses.GetAsync(id);
        Assert.Equal(2, d!.Participants.Count);
        Assert.Equal(100000, await NetAsync(g, ids["A"]));
    }

    [Fact]
    public async Task Expense_filters_and_search()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B");
        var cats = await _env.Categories.GetAllAsync();
        await _env.Expenses.SaveAsync(new ExpenseDraft { GroupId = g, Title = "Biryani", AmountPaisa = 1000, CategoryId = cats[0].Id, PaidByFriendId = ids["A"], Date = new DateTime(2026, 11, 2), Participants = All(ids) });
        await _env.Expenses.SaveAsync(new ExpenseDraft { GroupId = g, Title = "Petrol", AmountPaisa = 2000, CategoryId = cats[2].Id, PaidByFriendId = ids["B"], Date = new DateTime(2026, 11, 10), Participants = new() { new(ids["B"]) } });

        Assert.Equal(2, (await _env.Expenses.GetExpensesAsync(g)).Count);
        Assert.Single(await _env.Expenses.GetExpensesAsync(g, new ExpenseFilter { Search = "biry" }));
        Assert.Single(await _env.Expenses.GetExpensesAsync(g, new ExpenseFilter { CategoryId = cats[2].Id }));
        Assert.Single(await _env.Expenses.GetExpensesAsync(g, new ExpenseFilter { FriendId = ids["A"] }));
        Assert.Single(await _env.Expenses.GetExpensesAsync(g, new ExpenseFilter { From = new DateTime(2026, 11, 5), To = new DateTime(2026, 11, 30) }));
    }
}

public class GroupFriendAndDataIntegrityTests : IDisposable
{
    private readonly TestEnvironment _env = new();
    public void Dispose() => _env.Dispose();

    [Fact]
    public async Task Duplicate_group_and_friend_names_are_rejected()
    {
        await _env.Groups.CreateAsync("Office Friends", null);
        await Assert.ThrowsAsync<ValidationException>(() => _env.Groups.CreateAsync("office friends", null));

        var (g, _) = await _env.SeedGroupAsync("Ali");
        await Assert.ThrowsAsync<ValidationException>(() => _env.Friends.SaveAsync(new FriendDraft { GroupId = g, Name = "ALI" }));
    }

    [Fact]
    public async Task Friend_with_records_cannot_be_deleted_only_deactivated()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B", "C");
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["B"], AmountPaisa = 1000 });

        await Assert.ThrowsAsync<ValidationException>(() => _env.Friends.RemoveAsync(g, ids["B"]));
        await _env.Friends.SetActiveAsync(g, ids["B"], false);

        // Inactive friends cannot be put on new expenses...
        await Assert.ThrowsAsync<ValidationException>(() => _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "x", AmountPaisa = 100, CategoryId = _env.FoodCategoryAsync().Result,
            PaidByFriendId = ids["A"], Participants = new() { new(ids["A"]), new(ids["B"]) }
        }));

        // ...but a friend without records can be removed completely.
        await _env.Friends.RemoveAsync(g, ids["C"]);
        Assert.Equal(2, (await _env.Friends.GetMembersAsync(g)).Count);
    }

    [Fact]
    public async Task Same_friend_can_be_in_multiple_groups_with_separate_records()
    {
        var (g1, ids) = await _env.SeedGroupAsync("Ali", "Bilal");
        var g2 = (await _env.Groups.CreateAsync("Weekend Group", null)).Id;
        await _env.Friends.AddExistingFriendAsync(g2, ids["Ali"], DateTime.Today);
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g1, FriendId = ids["Ali"], AmountPaisa = 5000 });

        Assert.Equal(5000, await _env.Fund.GetBalanceAsync(g1));
        Assert.Equal(0, await _env.Fund.GetBalanceAsync(g2));
        Assert.Single(await _env.Friends.GetMembersAsync(g2));
    }

    [Fact]
    public async Task Deleting_group_cascades_all_records()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B");
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 5000 });
        await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "x", AmountPaisa = 1000, CategoryId = await _env.FoodCategoryAsync(),
            Source = PaymentSource.GroupFund, Participants = new() { new(ids["A"]), new(ids["B"]) }
        });

        await _env.Groups.DeleteAsync(g);
        Assert.Equal(0L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM Expenses"));
        Assert.Equal(0L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM ExpenseParticipants"));
        Assert.Equal(0L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM FundTransactions"));
        Assert.Equal(0L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM Friends"));
    }

    [Fact]
    public async Task Database_constraints_block_duplicate_fund_deduction()
    {
        var (g, ids) = await _env.SeedGroupAsync("A");
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 5000 });
        var eid = await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "x", AmountPaisa = 1000, CategoryId = await _env.FoodCategoryAsync(),
            Source = PaymentSource.GroupFund, Participants = new() { new(ids["A"]) }
        });

        // A second ledger row for the same expense violates UNIQUE(ExpenseId).
        await Assert.ThrowsAnyAsync<Exception>(() => _env.Db.ExecuteAsync(
            "INSERT INTO FundTransactions (Id, GroupId, Type, AmountPaisa, TransactionDate, ExpenseId, CreatedAt, UpdatedAt) VALUES (?, ?, 2, -1000, '2026-11-20', ?, '', '')",
            Ids.New(), g, eid));
        // Foreign keys are enforced.
        await Assert.ThrowsAnyAsync<Exception>(() => _env.Db.ExecuteAsync(
            "INSERT INTO Settlements (Id, GroupId, FromFriendId, ToFriendId, AmountPaisa, SettlementDate, CreatedAt, UpdatedAt) VALUES (?, ?, 'nobody', ?, 100, '2026-11-20', '', '')",
            Ids.New(), g, ids["A"]));
        Assert.Equal(4000, await _env.Fund.GetBalanceAsync(g));
    }

    [Fact]
    public async Task Failed_transaction_rolls_back_everything()
    {
        var (g, ids) = await _env.SeedGroupAsync("A");
        await Assert.ThrowsAnyAsync<Exception>(() => _env.Db.RunInTransactionAsync(s =>
        {
            s.Execute("INSERT INTO FundContributions (Id, GroupId, FriendId, AmountPaisa, ContributionDate, CreatedAt, UpdatedAt) VALUES ('c1', ?, ?, 100, '2026-11-20', '', '')", g, ids["A"]);
            throw new InvalidOperationException("boom");
        }));
        Assert.Equal(0L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM FundContributions"));
    }

    [Fact]
    public async Task Categories_custom_add_and_protected_delete()
    {
        var c = await _env.Categories.AddAsync("Gym", "🏋️");
        await Assert.ThrowsAsync<ValidationException>(() => _env.Categories.AddAsync("gym", null));
        var system = (await _env.Categories.GetAllAsync()).First(x => x.IsSystem == 1);
        await Assert.ThrowsAsync<ValidationException>(() => _env.Categories.DeleteAsync(system.Id));
        await _env.Categories.DeleteAsync(c.Id);
    }
}

public class BackupAndMigrationTests : IDisposable
{
    private readonly TestEnvironment _env = new();
    public void Dispose() => _env.Dispose();

    [Fact]
    public async Task Backup_then_restore_brings_back_old_data()
    {
        var (g, ids) = await _env.SeedGroupAsync("A", "B");
        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["A"], AmountPaisa = 7000 });

        var backup = await _env.Backup.CreateBackupFileAsync();
        var info = await _env.Backup.InspectBackupAsync(backup);
        Assert.True(info.IsValid);
        Assert.Equal(1, info.GroupCount);

        await _env.Fund.SaveContributionAsync(new ContributionDraft { GroupId = g, FriendId = ids["B"], AmountPaisa = 3000 });
        Assert.Equal(10000, await _env.Fund.GetBalanceAsync(g));

        await _env.Backup.RestoreAsync(backup);
        Assert.Equal(7000, await _env.Fund.GetBalanceAsync(g));
        Assert.Single(Directory.GetFiles(_env.Paths.SafetyBackupDirectory));
    }

    [Fact]
    public async Task Invalid_backup_files_are_rejected()
    {
        Directory.CreateDirectory(_env.Paths.TempDirectory);
        var junk = Path.Combine(_env.Paths.TempDirectory, "notes.txt");
        await File.WriteAllTextAsync(junk, new string('x', 4096));
        var info = await _env.Backup.InspectBackupAsync(junk);
        Assert.False(info.IsValid);
        await Assert.ThrowsAsync<ValidationException>(() => _env.Backup.RestoreAsync(junk));
    }

    [Fact]
    public async Task Reopening_database_does_not_reapply_migrations()
    {
        await _env.SeedGroupAsync("A");
        await _env.Db.CloseAsync();
        Assert.Equal((long)Migrations.LatestVersion, await _env.Db.ScalarAsync<long>("SELECT MAX(Version) FROM SchemaVersion"));
        Assert.Equal(10L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM Categories"));
        Assert.Equal(1L, await _env.Db.ScalarAsync<long>("SELECT COUNT(*) FROM Groups"));
    }

    [Fact]
    public async Task Csv_export_escapes_values()
    {
        var (g, ids) = await _env.SeedGroupAsync("A");
        await _env.Expenses.SaveAsync(new ExpenseDraft
        {
            GroupId = g, Title = "Tea, \"special\"", AmountPaisa = 15050, CategoryId = await _env.FoodCategoryAsync(),
            PaidByFriendId = ids["A"], Participants = new() { new(ids["A"]) }, Notes = "=SUM(A1)"
        });
        var csv = new ExportService().TransactionsToCsv(await _env.Reports.GetTransactionsAsync(g));
        Assert.Contains("\"Tea, \"\"special\"\"\"", csv);
        Assert.Contains("150.50", csv);
        Assert.Contains("'=SUM(A1)", csv);

        var report = await _env.Reports.GetReportAsync(g, ReportPeriod.MonthOf(DateTime.Today));
        Assert.Contains("Closing fund balance", new ExportService().ReportToCsv(report, "G"));
    }
}
