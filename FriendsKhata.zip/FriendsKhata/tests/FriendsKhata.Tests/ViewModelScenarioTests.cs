#nullable disable warnings
using FriendsKhata.Core.Services;
using FriendsKhata.Data;
using FriendsKhata.Presentation;
using FriendsKhata.Presentation.Abstractions;
using FriendsKhata.Presentation.ViewModels;

namespace FriendsKhata.Tests;

/// <summary>
/// End-to-end scenario through the ViewModels (what the screens do), with fake navigation/dialogs
/// and a real SQLite database: create group, add friends, expenses, fund, settlements, reports, backup.
/// </summary>
public class ViewModelScenarioTests : IDisposable
{
    private readonly TestEnvironment _env = new();
    public void Dispose() => _env.Dispose();

    [Fact]
    public async Task Full_weekly_khata_flow_through_viewmodels()
    {
        var paths = _env.Paths; var db = _env.Db;
        var groups = _env.Groups; var friends = _env.Friends; var cats = _env.Categories; var expenses = _env.Expenses;
        var fund = _env.Fund; var settle = _env.Settlements; var reports = _env.Reports;
        var nav = new FakeNav(); var dlg = new FakeDialogs(); var store = new MemStore();
        var state = new AppState(store, groups);
        // 1. Dashboard with no group shows the welcome state
        var dash = new DashboardViewModel(reports, state, nav, dlg);
        await dash.OnAppearingAsync();
        Assert.True(dash.HasNoGroup && !dash.HasGroup, "Dashboard empty state without group");

        // 2. Create group via GroupsViewModel prompt
        dlg.PromptAnswers.Enqueue("University Friends");
        var gvm = new GroupsViewModel(groups, state, nav, dlg);
        await gvm.OnAppearingAsync();
        await gvm.CreateCommand.ExecuteAsync(null);
        Assert.True(state.CurrentGroupId != null && nav.Last == Routes.FriendsTab, "Group created and navigated to Friends");

        // 3. Add 5 friends through FriendEditorViewModel
        foreach (var n in new[] { "Ali", "Bilal", "Hamza", "Usman", "Zain" })
        {
            var fe = new FriendEditorViewModel(friends, state, nav, dlg);
            await fe.OnAppearingAsync();
            fe.Name = n; fe.Phone = "0300123456" + n.Length;
            await fe.SaveCommand.ExecuteAsync(null);
        }
        var fl = new FriendsViewModel(friends, settle, state, nav, dlg);
        await fl.OnAppearingAsync();
        Assert.True(fl.Members.Count == 5 && dlg.Alerts.Count == 0, "Five friends added: " + string.Join(",", dlg.Alerts));

        // 4. Expense editor: Ali pays 3000, equal split, preview text
        var ee = new ExpenseEditorViewModel(expenses, friends, cats, fund, state, nav, dlg);
        ee.ApplyParameters(new Dictionary<string, object>());
        await ee.OnAppearingAsync();
        ee.ExpenseTitle = "Dinner"; ee.AmountText = "3000";
        ee.SelectedPayer = ee.PayerOptions.First(p => p.Name == "Ali");
        Assert.True(ee.Participants.All(p => p.ShareText == "Rs. 600"), "Equal split preview Rs. 600 each");
        Assert.True(ee.Preview.Contains("recoverable from others Rs. 2,400"), "Preview: " + ee.Preview);
        await ee.SaveCommand.ExecuteAsync(null);
        Assert.True(nav.Last == ".." && dlg.Alerts.Count == 0, "Expense saved " + string.Join(",", dlg.Alerts));

        // 5. Custom split with wrong total shows inline error, percentage fill evenly works
        var ee2 = new ExpenseEditorViewModel(expenses, friends, cats, fund, state, nav, dlg);
        await ee2.OnAppearingAsync();
        ee2.ExpenseTitle = "Petrol"; ee2.AmountText = "1000"; ee2.SplitIndex = 1;
        ee2.Participants[0].AmountText = "300";
        Assert.True(ee2.HasPreviewError, "Custom mismatch error: " + ee2.PreviewError);
        ee2.SplitIndex = 2; ee2.SplitEvenlyCommand.Execute(null);
        Assert.True(!ee2.HasPreviewError && ee2.Participants.Sum(p => decimal.Parse(p.PercentText)) == 100m, "Fill evenly percentages total 100");

        // 6. Fund: contributions + fund expense blocked when insufficient
        foreach (var m in fl.Members)
        {
            var ce = new ContributionEditorViewModel(fund, friends, state, nav, dlg);
            ce.ApplyParameters(new Dictionary<string, object> { [NavKeys.FriendId] = m.FriendId });
            await ce.OnAppearingAsync();
            ce.AmountText = "2000";
            await ce.SaveCommand.ExecuteAsync(null);
        }
        var fvm = new FundViewModel(fund, friends, state, nav, dlg);
        await fvm.OnAppearingAsync();
        Assert.True(fvm.Balance == "Rs. 10,000" && fvm.Ledger.Count == 5, "Fund balance Rs. 10,000 with 5 ledger rows");
        var ee3 = new ExpenseEditorViewModel(expenses, friends, cats, fund, state, nav, dlg);
        await ee3.OnAppearingAsync();
        ee3.ExpenseTitle = "Trip"; ee3.AmountText = "12000"; ee3.SourceIndex = 1;
        Assert.True(ee3.HasPreviewError, "Fund shortfall warning in preview");
        int before = dlg.Alerts.Count;
        await ee3.SaveCommand.ExecuteAsync(null);
        Assert.True(dlg.Alerts.Count == before + 1 && dlg.Alerts.Last().Contains("Not enough money"), "Save blocked with message");

        // 7. Edit existing expense loads values
        var list = new ExpensesViewModel(expenses, friends, cats, state, nav, dlg);
        await list.OnAppearingAsync();
        var dinner = list.Expenses.First(e => e.Title == "Dinner");
        var edit = new ExpenseEditorViewModel(expenses, friends, cats, fund, state, nav, dlg);
        edit.ApplyParameters(new Dictionary<string, object> { [NavKeys.Id] = dinner.Id });
        await edit.OnAppearingAsync();
        Assert.True(edit.IsEditing && edit.AmountText == "3000" && edit.SelectedPayer.Name == "Ali" && edit.Participants.All(p => p.IsSelected), "Edit loads existing expense");

        // 8. Settlements: suggestions + record via prefill
        var svm = new SettlementsViewModel(settle, state, nav, dlg);
        await svm.OnAppearingAsync();
        Assert.True(svm.Suggestions.Count == 4 && svm.Outstanding == "Rs. 2,400", "4 suggestions, outstanding Rs. 2,400");
        await svm.RecordSuggestionCommand.ExecuteAsync(svm.Suggestions[0]);
        var se = new SettlementEditorViewModel(settle, friends, state, nav, dlg);
        se.ApplyParameters(nav.LastParams);
        await se.OnAppearingAsync();
        Assert.True(se.AmountText == "600" && se.SelectedTo.Name == "Ali", "Settlement editor prefilled: " + se.Hint);
        await se.SaveCommand.ExecuteAsync(null);
        await svm.OnAppearingAsync();
        Assert.True(svm.Suggestions.Count == 3 && svm.Outstanding == "Rs. 1,800", "After settlement: outstanding Rs. 1,800");

        // 9. Dashboard + reports + history
        await dash.OnAppearingAsync();
        Assert.True(dash.FundBalance == "Rs. 10,000" && dash.TotalExpenses == "Rs. 3,000" && dash.Balances.Count == 5 && dash.RecentTransactions.Count > 0, "Dashboard figures");
        var rvm = new ReportsViewModel(reports, new ExportService(), new CsvSaver(paths, new FakeFiles()), state, nav, dlg);
        await rvm.OnAppearingAsync();
        rvm.ModeIndex = 1; await Task.Delay(200);
        Assert.True(rvm.TotalExpenses == "Rs. 3,000" && rvm.Contributions == "Rs. 10,000" && rvm.Friends.Count == 5, "Monthly report figures: " + rvm.TotalExpenses);
        await rvm.ExportCommand.ExecuteAsync(null);
        Assert.True(FakeFiles.Saved.Any(f => f.EndsWith(".csv")), "Report CSV exported");
        var th = new TransactionHistoryViewModel(reports, new ExportService(), new CsvSaver(paths, new FakeFiles()), state, nav, dlg);
        await th.OnAppearingAsync();
        Assert.True(th.Transactions.Count == 7, "History has 7 items: " + th.Transactions.Count);
        th.KindIndex = 4; await Task.Delay(200);
        Assert.True(th.Transactions.Count == 1, "Filter settlements");

        // 10. Friend with records: delete -> offered deactivation
        var ali = fl.Members.First(m => m.Name == "Ali");
        var fe2 = new FriendEditorViewModel(friends, state, nav, dlg);
        fe2.ApplyParameters(new Dictionary<string, object> { [NavKeys.FriendId] = ali.FriendId });
        await fe2.OnAppearingAsync();
        dlg.ConfirmAnswer = false;
        await fe2.DeleteCommand.ExecuteAsync(null);
        Assert.True(dlg.LastConfirm.Contains("Mark Ali as inactive"), "Delete with records offers deactivation");

        // 11. Friend summary
        var fs = new FriendSummaryViewModel(friends, state, nav, dlg);
        fs.ApplyParameters(new Dictionary<string, object> { [NavKeys.FriendId] = ali.FriendId });
        await fs.OnAppearingAsync();
        Assert.True(fs.BalanceText == "Rs. 1,800" && fs.IsPositive && fs.Contributed == "Rs. 2,000", "Friend summary for Ali");

        // 12. Backup VM export
        var bvm = new BackupViewModel(new BackupService(db, paths), new FakeFiles(), paths, state, nav, dlg);
        await bvm.ExportCommand.ExecuteAsync(null);
        Assert.True(bvm.Status.StartsWith("Backup saved"), bvm.Status);
    }
}


internal sealed class FakeNav : INavigationService
{
    public string Last = ""; public IDictionary<string, object> LastParams = new Dictionary<string, object>();
    public Task GoToAsync(string route, IDictionary<string, object>? p = null) { Last = route; LastParams = p ?? new Dictionary<string, object>(); return Task.CompletedTask; }
    public Task GoBackAsync() { Last = ".."; return Task.CompletedTask; }
}
internal sealed class FakeDialogs : IDialogService
{
    public List<string> Alerts = new(); public Queue<string> PromptAnswers = new(); public bool ConfirmAnswer = true; public string LastConfirm = "";
    public Task AlertAsync(string t, string m, string ok = "OK") { Alerts.Add(m); return Task.CompletedTask; }
    public Task<bool> ConfirmAsync(string t, string m, string a = "Yes", string c = "Cancel") { LastConfirm = m; return Task.FromResult(ConfirmAnswer); }
    public Task<string?> PromptAsync(string t, string m, string? i = null, string a = "Save", int max = 50, string? p = null) => Task.FromResult<string?>(PromptAnswers.Count > 0 ? PromptAnswers.Dequeue() : null);
    public Task<string?> ChooseAsync(string t, params string[] o) => Task.FromResult<string?>(null);
    public Task ToastAsync(string m) => Task.CompletedTask;
}
internal sealed class FakeFiles : IFileExchangeService
{
    public static List<string> Saved = new();
    public Task<string?> SaveAsync(string name, string src) { Saved.Add(name); return Task.FromResult<string?>("/storage/Download/" + name); }
    public Task<string?> PickFileAsync(string t) => Task.FromResult<string?>(null);
}
internal sealed class MemStore : ISettingsStore
{
    private readonly Dictionary<string, string> _d = new();
    public string? Get(string k) => _d.TryGetValue(k, out var v) ? v : null;
    public void Set(string k, string? v) { if (v is null) _d.Remove(k); else _d[k] = v; }
}
