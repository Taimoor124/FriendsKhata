using FriendsKhata.Core.Common;
using FriendsKhata.Core.Finance;
using FriendsKhata.Core.Models;

namespace FriendsKhata.Tests;

public class MoneyTests
{
    [Theory]
    [InlineData("5000", 500000)]
    [InlineData("5,000", 500000)]
    [InlineData("Rs. 1,250.75", 125075)]
    [InlineData("0.5", 50)]
    [InlineData(" 99.99 ", 9999)]
    public void Parses_valid_amounts(string input, long expectedPaisa)
    {
        Assert.True(Money.TryParse(input, out var paisa, out _));
        Assert.Equal(expectedPaisa, paisa);
    }

    [Theory]
    [InlineData("")]
    [InlineData("abc")]
    [InlineData("-50")]
    [InlineData("10.555")]
    public void Rejects_invalid_amounts(string input)
    {
        Assert.False(Money.TryParse(input, out _, out var error));
        Assert.NotNull(error);
    }

    [Fact]
    public void Formats_pkr()
    {
        Assert.Equal("Rs. 5,000", Money.Format(500000));
        Assert.Equal("Rs. 1,250.50", Money.Format(125050));
        Assert.Equal("-Rs. 600", Money.Format(-60000));
        Assert.Equal("Rs. 0", Money.Format(0));
    }
}

public class SplitCalculatorTests
{
    private static List<SplitInput> Friends(params string[] ids) => ids.Select(i => new SplitInput(i)).ToList();

    [Fact]
    public void Equal_split_dinner_5000_among_5()
    {
        var r = SplitCalculator.Calculate(500000, SplitMethod.Equal, Friends("a", "b", "c", "d", "e"));
        Assert.Equal(5, r.Count);
        Assert.True(r.All(x => x.SharePaisa == 100000));
    }

    [Fact]
    public void Equal_split_with_remainder_never_loses_paisa()
    {
        var r = SplitCalculator.Calculate(10000, SplitMethod.Equal, Friends("a", "b", "c")); // Rs 100 / 3
        Assert.Equal(10000, r.Sum(x => x.SharePaisa));
        Assert.Equal(3334, r[0].SharePaisa);
        Assert.Equal(3333, r[1].SharePaisa);
        Assert.Equal(3333, r[2].SharePaisa);
    }

    [Fact]
    public void Equal_split_decimal_amount()
    {
        var r = SplitCalculator.Calculate(125075, SplitMethod.Equal, Friends("a", "b", "c", "d")); // Rs 1250.75 / 4
        Assert.Equal(125075, r.Sum(x => x.SharePaisa));
        Assert.True(r.Max(x => x.SharePaisa) - r.Min(x => x.SharePaisa) <= 1);
    }

    [Fact]
    public void Equal_split_among_selected_friends_only()
    {
        var r = SplitCalculator.Calculate(90000, SplitMethod.Equal, Friends("a", "c"));
        Assert.Equal(2, r.Count);
        Assert.True(r.All(x => x.SharePaisa == 45000));
    }

    [Fact]
    public void Custom_amounts_must_match_total()
    {
        var ok = SplitCalculator.Calculate(300000, SplitMethod.CustomAmount, new List<SplitInput>
        {
            new("a", 100000), new("b", 150000), new("c", 50000)
        });
        Assert.Equal(300000, ok.Sum(x => x.SharePaisa));

        var ex = Assert.Throws<ValidationException>(() => SplitCalculator.Calculate(300000, SplitMethod.CustomAmount,
            new List<SplitInput> { new("a", 100000), new("b", 100000) }));
        Assert.Contains("Difference", ex.Message);
    }

    [Fact]
    public void Custom_amount_zero_means_not_participating()
    {
        var r = SplitCalculator.Calculate(100000, SplitMethod.CustomAmount, new List<SplitInput> { new("a", 100000), new("b", 0) });
        Assert.Single(r);
    }

    [Fact]
    public void Percentage_split_rounds_with_largest_remainder()
    {
        var r = SplitCalculator.Calculate(10001, SplitMethod.Percentage, new List<SplitInput>
        {
            new("a", Percent: 33.33m), new("b", Percent: 33.33m), new("c", Percent: 33.34m)
        });
        Assert.Equal(10001, r.Sum(x => x.SharePaisa));
        Assert.Equal(3333, r.First(x => x.FriendId == "a").PercentBp);
    }

    [Fact]
    public void Percentage_split_must_total_100()
    {
        Assert.Throws<ValidationException>(() => SplitCalculator.Calculate(10000, SplitMethod.Percentage,
            new List<SplitInput> { new("a", Percent: 50m), new("b", Percent: 40m) }));
    }

    [Fact]
    public void Rejects_duplicate_and_empty_participants()
    {
        Assert.Throws<ValidationException>(() => SplitCalculator.Calculate(1000, SplitMethod.Equal, Friends("a", "a")));
        Assert.Throws<ValidationException>(() => SplitCalculator.Calculate(1000, SplitMethod.Equal, Friends()));
        Assert.Throws<ValidationException>(() => SplitCalculator.Calculate(0, SplitMethod.Equal, Friends("a")));
    }

    [Fact]
    public void Randomised_splits_always_sum_to_total()
    {
        var rnd = new Random(42);
        for (var i = 0; i < 2000; i++)
        {
            var total = rnd.NextInt64(1, 10_000_000);
            var n = rnd.Next(1, 9);
            var ids = Enumerable.Range(0, n).Select(x => "f" + x).ToArray();
            var equal = SplitCalculator.Calculate(total, SplitMethod.Equal, Friends(ids));
            Assert.Equal(total, equal.Sum(x => x.SharePaisa));

            // random percentages with 2 decimals that sum to 100
            var bps = new long[n];
            long left = 10000;
            for (var k = 0; k < n - 1; k++) { bps[k] = rnd.NextInt64(0, left + 1); left -= bps[k]; }
            bps[n - 1] = left;
            if (bps.All(b => b == 0)) continue;
            var pct = SplitCalculator.Calculate(total, SplitMethod.Percentage,
                ids.Select((id, k) => new SplitInput(id, Percent: bps[k] / 100m)).ToList());
            Assert.Equal(total, pct.Sum(x => x.SharePaisa));
        }
    }
}

public class ReportPeriodTests
{
    [Fact]
    public void Week_runs_monday_to_sunday()
    {
        var p = ReportPeriod.WeekOf(new DateTime(2026, 11, 20)); // Friday
        Assert.Equal(new DateTime(2026, 11, 16), p.Start);         // Monday
        Assert.Equal(new DateTime(2026, 11, 22), p.End);           // Sunday
        Assert.True(p.Contains(new DateTime(2026, 11, 22, 23, 59, 0)));
        Assert.False(p.Contains(new DateTime(2026, 11, 23)));

        var sunday = ReportPeriod.WeekOf(new DateTime(2026, 11, 22));
        Assert.Equal(new DateTime(2026, 11, 16), sunday.Start);
    }

    [Fact]
    public void Month_handles_leap_february()
    {
        var p = ReportPeriod.MonthOf(new DateTime(2028, 2, 10));
        Assert.Equal(new DateTime(2028, 2, 1), p.Start);
        Assert.Equal(new DateTime(2028, 2, 29), p.End);
        Assert.Equal(new DateTime(2028, 1, 1), p.Previous().Start);
        Assert.Equal(new DateTime(2028, 3, 31), p.Next().End);
    }

    [Fact]
    public void Custom_range_validates_order()
    {
        Assert.Throws<ValidationException>(() => ReportPeriod.Custom(new DateTime(2026, 5, 2), new DateTime(2026, 5, 1)));
        Assert.Equal(1, ReportPeriod.Custom(new DateTime(2026, 5, 1), new DateTime(2026, 5, 1)).Days);
    }
}

public class LedgerCalculationTests
{
    // Builds an in-memory ledger for pure calculation tests.
    private sealed class LedgerBuilder
    {
        private readonly List<Member> _members = new();
        private readonly List<Expense> _expenses = new();
        private readonly List<ExpenseParticipant> _participants = new();
        private readonly List<FundTransaction> _fund = new();
        private readonly List<Settlement> _settlements = new();

        public LedgerBuilder Friends(params string[] names)
        {
            foreach (var n in names)
                _members.Add(new Member { FriendId = n, Name = n, Status = 1, JoiningDate = "2026-01-01" });
            return this;
        }

        public LedgerBuilder Expense(string payer, long amount, PaymentSource src, string date = "2026-11-18", params string[] among)
        {
            var id = Ids.New();
            _expenses.Add(new Expense
            {
                Id = id, Title = "x", AmountPaisa = amount, CategoryId = "c", ExpenseDate = date,
                PaidByFriendId = src == PaymentSource.Personal ? payer : null, PaymentSource = (long)src, SplitMethod = 1
            });
            var people = among.Length == 0 ? _members.Select(m => m.FriendId).ToArray() : among;
            foreach (var s in SplitCalculator.Calculate(amount, SplitMethod.Equal, people.Select(p => new SplitInput(p)).ToList()))
                _participants.Add(new ExpenseParticipant { Id = Ids.New(), ExpenseId = id, FriendId = s.FriendId, ShareAmountPaisa = s.SharePaisa });
            if (src == PaymentSource.GroupFund)
                _fund.Add(new FundTransaction { Id = Ids.New(), Type = 2, AmountPaisa = -amount, ExpenseId = id, TransactionDate = date });
            return this;
        }

        public LedgerBuilder Contribution(string friend, long amount, string date = "2026-11-17")
        {
            _fund.Add(new FundTransaction { Id = Ids.New(), Type = 1, AmountPaisa = amount, FriendId = friend, ContributionId = Ids.New(), TransactionDate = date });
            return this;
        }

        public LedgerBuilder Refund(string friend, long amount, string date = "2026-11-19")
        {
            _fund.Add(new FundTransaction { Id = Ids.New(), Type = 3, AmountPaisa = -amount, FriendId = friend, TransactionDate = date });
            return this;
        }

        public LedgerBuilder Adjust(long signed, string? friend = null, string date = "2026-11-19")
        {
            _fund.Add(new FundTransaction { Id = Ids.New(), Type = 4, AmountPaisa = signed, FriendId = friend, TransactionDate = date });
            return this;
        }

        public LedgerBuilder Pay(string from, string to, long amount, string date = "2026-11-19")
        {
            _settlements.Add(new Settlement { Id = Ids.New(), FromFriendId = from, ToFriendId = to, AmountPaisa = amount, SettlementDate = date });
            return this;
        }

        public GroupLedger Build() => new()
        {
            GroupId = "g", Members = _members, Expenses = _expenses, Participants = _participants,
            Contributions = new List<FundContribution>(), FundTransactions = _fund, Settlements = _settlements,
            Categories = new List<Category> { new() { Id = "c", Name = "Food", Icon = "🍽️" } }
        };
    }

    private static long Net(IReadOnlyList<FriendBalance> b, string id) => b.First(x => x.FriendId == id).NetPaisa;

    [Fact]
    public void Ali_pays_3000_dinner_shared_by_5()
    {
        var ledger = new LedgerBuilder().Friends("Ali", "Bilal", "Hamza", "Usman", "Zain")
            .Expense("Ali", 300000, PaymentSource.Personal).Build();
        var b = BalanceCalculator.Calculate(ledger);

        var ali = b.First(x => x.FriendId == "Ali");
        Assert.Equal(300000, ali.PaidPersonalPaisa);
        Assert.Equal(60000, ali.SharePersonalPaisa);
        Assert.Equal(240000, ali.NetPaisa);                   // recoverable
        Assert.Equal(-60000, Net(b, "Bilal"));
        Assert.Equal(0, b.Sum(x => x.NetPaisa));

        var s = SettlementOptimizer.Suggest(b);
        Assert.Equal(4, s.Count);
        Assert.True(s.All(x => x.ToFriendId == "Ali" && x.AmountPaisa == 60000));
    }

    [Fact]
    public void Settlements_reduce_outstanding()
    {
        var ledger = new LedgerBuilder().Friends("Ali", "Bilal", "Hamza")
            .Expense("Ali", 90000, PaymentSource.Personal)
            .Pay("Bilal", "Ali", 30000)
            .Pay("Hamza", "Ali", 10000).Build();
        var b = BalanceCalculator.Calculate(ledger);
        Assert.Equal(20000, Net(b, "Ali"));
        Assert.Equal(0, Net(b, "Bilal"));
        Assert.Equal(-20000, Net(b, "Hamza"));
    }

    [Fact]
    public void Fund_expenses_and_contributions_do_not_touch_personal_balances()
    {
        var ledger = new LedgerBuilder().Friends("A", "B", "C", "D", "E")
            .Contribution("A", 200000).Contribution("B", 200000).Contribution("C", 200000).Contribution("D", 200000).Contribution("E", 200000)
            .Expense("A", 300000, PaymentSource.GroupFund).Build();

        Assert.True(BalanceCalculator.Calculate(ledger).All(x => x.NetPaisa == 0));

        var fund = FundCalculator.Calculate(ledger);
        Assert.Equal(1000000, fund.TotalCollectedPaisa);
        Assert.Equal(300000, fund.TotalSpentPaisa);
        Assert.Equal(700000, fund.BalancePaisa);
        Assert.True(fund.Friends.All(f => f.EquityPaisa == 140000));
        Assert.Equal(fund.BalancePaisa, fund.Friends.Sum(f => f.EquityPaisa) + fund.UnallocatedAdjustmentsPaisa);
    }

    [Fact]
    public void Fund_equity_invariant_with_refunds_and_adjustments()
    {
        var ledger = new LedgerBuilder().Friends("A", "B", "C")
            .Contribution("A", 300000).Contribution("B", 100000).Contribution("C", 50000)
            .Expense("A", 120000, PaymentSource.GroupFund)
            .Refund("A", 50000)
            .Adjust(-1000)              // bank charge, unallocated
            .Adjust(2500, "B").Build();

        var f = FundCalculator.Calculate(ledger);
        Assert.Equal(450000 - 120000 - 50000 - 1000 + 2500, f.BalancePaisa);
        Assert.Equal(f.BalancePaisa, f.Friends.Sum(x => x.EquityPaisa) + f.UnallocatedAdjustmentsPaisa);
        Assert.Equal(300000 - 40000 - 50000, f.Friends.First(x => x.FriendId == "A").EquityPaisa);
    }

    [Fact]
    public void Mixed_scenario_balances_always_sum_to_zero()
    {
        var ledger = new LedgerBuilder().Friends("A", "B", "C", "D")
            .Expense("A", 500000, PaymentSource.Personal)
            .Expense("B", 120050, PaymentSource.Personal, "2026-11-18", "B", "C")
            .Expense("C", 7777, PaymentSource.Personal, "2026-11-18", "A", "B", "C")
            .Contribution("D", 100000)
            .Expense("D", 40000, PaymentSource.GroupFund)
            .Pay("D", "A", 50000).Build();

        var b = BalanceCalculator.Calculate(ledger);
        Assert.Equal(0, b.Sum(x => x.NetPaisa));

        // Applying the suggestions must clear every balance.
        var nets = b.ToDictionary(x => x.FriendId, x => x.NetPaisa);
        foreach (var s in SettlementOptimizer.Suggest(b))
        {
            nets[s.FromFriendId] += s.AmountPaisa;
            nets[s.ToFriendId] -= s.AmountPaisa;
        }
        Assert.True(nets.Values.All(v => v == 0));
    }

    [Fact]
    public void Report_uses_exact_period_boundaries_and_fund_opening_closing()
    {
        var ledger = new LedgerBuilder().Friends("A", "B")
            .Contribution("A", 100000, "2026-10-31")                       // before November
            .Expense("A", 20000, PaymentSource.GroupFund, "2026-11-01")    // first day
            .Expense("B", 30000, PaymentSource.Personal, "2026-11-30")     // last day
            .Expense("B", 99900, PaymentSource.Personal, "2026-12-01")     // after
            .Build();

        var r = ReportBuilder.Build(ledger, ReportPeriod.MonthOf(new DateTime(2026, 11, 15)));
        Assert.Equal(50000, r.TotalExpensesPaisa);
        Assert.Equal(20000, r.FundSpendingPaisa);
        Assert.Equal(30000, r.PersonalPaymentsPaisa);
        Assert.Equal(0, r.ContributionsPaisa);
        Assert.Equal(100000, r.OpeningFundBalancePaisa);
        Assert.Equal(80000, r.ClosingFundBalancePaisa);
        Assert.Equal(15000, r.Friends.First(f => f.FriendId == "B").OutstandingAtEndPaisa);
        Assert.Equal(15000, r.TotalOutstandingAtEndPaisa);
        Assert.Single(r.Categories);
    }
}

public class SettlementOptimizerTests
{
    private static FriendBalance B(string id, long net)
        => new() { FriendId = id, Name = id, PaidPersonalPaisa = Math.Max(net, 0), SharePersonalPaisa = Math.Max(-net, 0) };

    [Fact]
    public void Finds_independent_pairs_for_minimum_payments()
    {
        var s = SettlementOptimizer.Suggest(new[] { B("A", 1000), B("B", 700), B("C", -1000), B("D", -700) });
        Assert.Equal(2, s.Count);

        // Plain "largest debtor pays largest creditor" needs 5 payments here; the optimum is 4
        // ({-3,+3} settle separately from the rest).
        var hard = SettlementOptimizer.Suggest(new[]
        {
            B("A", -800), B("B", 600), B("C", -200), B("D", 300), B("E", 400), B("F", -300)
        });
        Assert.Equal(4, hard.Count);
    }

    [Fact]
    public void Exact_beats_or_equals_greedy_on_random_cases()
    {
        var rnd = new Random(7);
        for (var round = 0; round < 300; round++)
        {
            var n = rnd.Next(2, 9);
            var nets = Enumerable.Range(0, n - 1).Select(_ => (long)rnd.Next(-50, 51) * 100).ToList();
            nets.Add(-nets.Sum());
            var balances = nets.Select((v, i) => B("p" + i, v)).ToList();

            var s = SettlementOptimizer.Suggest(balances);
            var nonZero = nets.Count(v => v != 0);
            Assert.True(s.Count <= Math.Max(0, nonZero - 1));
            Assert.True(s.All(x => x.AmountPaisa > 0 && x.FromFriendId != x.ToFriendId));

            var remaining = balances.ToDictionary(b => b.FriendId, b => b.NetPaisa);
            foreach (var x in s) { remaining[x.FromFriendId] += x.AmountPaisa; remaining[x.ToFriendId] -= x.AmountPaisa; }
            Assert.True(remaining.Values.All(v => v == 0));
        }
    }

    [Fact]
    public void Nothing_to_settle_returns_empty()
    {
        Assert.Empty(SettlementOptimizer.Suggest(new[] { B("A", 0), B("B", 0) }));
    }
}
