This folder receives the installable Android package.

Build it on your PC with:
    dotnet publish src\FriendsKhata.App\FriendsKhata.App.csproj -f net8.0-android -c Release

The project copies the signed APK here automatically as:
    Output\FriendsKhata.apk

(No APK is included in this delivery: the build environment used to create the source had no
access to the Android SDK or the .NET MAUI workload. See the main README, "About the APK".)
